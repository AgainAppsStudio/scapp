package com.example.data

import android.content.Context
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.io.File

@JsonClass(generateAdapter = true)
data class BackupData(
    val products: List<Product> = emptyList(),
    val customers: List<Customer> = emptyList(),
    val invoices: List<Invoice> = emptyList(),
    val shops: List<Shop> = emptyList(),
    val expenses: List<Expense> = emptyList(),
    val suppliers: List<Supplier> = emptyList(),
    val purchaseOrders: List<PurchaseOrder> = emptyList(),
    val categories: List<Category> = emptyList(),
    val supplierTransactions: List<SupplierTransaction> = emptyList()
)

class AppRepository(private val context: Context, private val db: AppDatabase) {
    private val productDao = db.productDao()
    private val customerDao = db.customerDao()
    private val invoiceDao = db.invoiceDao()
    private val shopDao = db.shopDao()
    private val expenseDao = db.expenseDao()
    private val supplierDao = db.supplierDao()
    private val purchaseOrderDao = db.purchaseOrderDao()
    private val categoryDao = db.categoryDao()
    private val supplierTransactionDao = db.supplierTransactionDao()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    // Shops
    val allShops: Flow<List<Shop>> = shopDao.getAllShops()
    suspend fun insertShop(shop: Shop) = withContext(Dispatchers.IO) {
        shopDao.insertShop(shop)
    }
    suspend fun deleteShop(shop: Shop) = withContext(Dispatchers.IO) {
        shopDao.deleteShop(shop)
    }

    // Expenses
    val allExpenses: Flow<List<Expense>> = expenseDao.getAllExpenses()
    suspend fun insertExpense(expense: Expense) = withContext(Dispatchers.IO) {
        expenseDao.insertExpense(expense)
    }
    suspend fun deleteExpense(expense: Expense) = withContext(Dispatchers.IO) {
        expenseDao.deleteExpense(expense)
    }

    // Suppliers
    val allSuppliers: Flow<List<Supplier>> = supplierDao.getAllSuppliers()
    fun searchSuppliers(query: String): Flow<List<Supplier>> = supplierDao.searchSuppliers(query)
    suspend fun insertSupplier(supplier: Supplier) = withContext(Dispatchers.IO) {
        supplierDao.insertSupplier(supplier)
    }
    suspend fun deleteSupplier(supplier: Supplier) = withContext(Dispatchers.IO) {
        supplierDao.deleteSupplier(supplier)
    }

    // Supplier Transactions (Dual-Ledger)
    val allSupplierTransactions: Flow<List<SupplierTransaction>> = supplierTransactionDao.getAllSupplierTransactions()
    fun getTransactionsForSupplier(supplierId: String): Flow<List<SupplierTransaction>> = supplierTransactionDao.getTransactionsForSupplier(supplierId)
    suspend fun insertSupplierTransaction(tx: SupplierTransaction) = withContext(Dispatchers.IO) {
        supplierTransactionDao.insertTransaction(tx)
    }
    suspend fun deleteSupplierTransaction(tx: SupplierTransaction) = withContext(Dispatchers.IO) {
        supplierTransactionDao.deleteTransaction(tx)
    }

    // Purchase Orders
    val allPurchaseOrders: Flow<List<PurchaseOrder>> = purchaseOrderDao.getAllPurchaseOrders()
    suspend fun insertPurchaseOrder(po: PurchaseOrder) = withContext(Dispatchers.IO) {
        // If received, update product stock counts and cost prices!
        if (po.status == "Received") {
            val items = deserializePurchaseOrderItems(po.itemsJson)
            for (item in items) {
                val product = productDao.getProductById(item.productId)
                if (product != null) {
                    val updatedQty = product.quantity + item.quantity
                    productDao.updateProduct(product.copy(
                        quantity = updatedQty,
                        purchasePrice = item.costPrice
                    ))
                }
            }
            // Auto-record a "BUY" transaction in the supplier dual-ledger
            val tx = SupplierTransaction(
                id = "TX-${(100000..999999).random()}",
                supplierId = po.supplierId,
                type = "BUY",
                amount = po.totalCost,
                date = System.currentTimeMillis(),
                referenceId = po.poNumber,
                notes = "Auto-recorded from received Purchase Order ${po.poNumber}"
            )
            supplierTransactionDao.insertTransaction(tx)
        }
        purchaseOrderDao.insertPurchaseOrder(po)
    }
    suspend fun deletePurchaseOrder(po: PurchaseOrder) = withContext(Dispatchers.IO) {
        purchaseOrderDao.deletePurchaseOrder(po)
    }

    fun serializePurchaseOrderItems(items: List<PurchaseOrderItem>): String {
        val type = Types.newParameterizedType(List::class.java, PurchaseOrderItem::class.java)
        val adapter = moshi.adapter<List<PurchaseOrderItem>>(type)
        return adapter.toJson(items)
    }

    fun deserializePurchaseOrderItems(jsonStr: String): List<PurchaseOrderItem> {
        return try {
            val type = Types.newParameterizedType(List::class.java, PurchaseOrderItem::class.java)
            val adapter = moshi.adapter<List<PurchaseOrderItem>>(type)
            adapter.fromJson(jsonStr) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Categories
    val allCategories: Flow<List<Category>> = categoryDao.getAllCategories()
    suspend fun insertCategory(category: Category) = withContext(Dispatchers.IO) {
        categoryDao.insertCategory(category)
    }
    suspend fun deleteCategory(category: Category) = withContext(Dispatchers.IO) {
        categoryDao.deleteCategory(category)
    }

    // Products
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val lowStockProducts: Flow<List<Product>> = productDao.getLowStockProducts()
    
    fun searchProducts(query: String): Flow<List<Product>> = productDao.searchProducts(query)
    
    suspend fun getProductById(id: String): Product? = withContext(Dispatchers.IO) {
        productDao.getProductById(id)
    }

    suspend fun getProductBySku(sku: String): Product? = withContext(Dispatchers.IO) {
        productDao.getProductBySku(sku)
    }

    suspend fun getProductByBarcode(barcode: String): Product? = withContext(Dispatchers.IO) {
        productDao.getProductByBarcode(barcode)
    }

    suspend fun insertProduct(product: Product) = withContext(Dispatchers.IO) {
        productDao.insertProduct(product)
    }

    suspend fun updateProduct(product: Product) = withContext(Dispatchers.IO) {
        productDao.updateProduct(product)
    }

    suspend fun deleteProduct(product: Product) = withContext(Dispatchers.IO) {
        productDao.deleteProduct(product)
    }

    // Customers
    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    
    fun searchCustomers(query: String): Flow<List<Customer>> = customerDao.searchCustomers(query)
    
    suspend fun getCustomerById(id: String): Customer? = withContext(Dispatchers.IO) {
        customerDao.getCustomerById(id)
    }

    suspend fun insertCustomer(customer: Customer) = withContext(Dispatchers.IO) {
        customerDao.insertCustomer(customer)
    }

    suspend fun updateCustomer(customer: Customer) = withContext(Dispatchers.IO) {
        customerDao.updateCustomer(customer)
    }

    suspend fun deleteCustomer(customer: Customer) = withContext(Dispatchers.IO) {
        customerDao.deleteCustomer(customer)
    }

    // Invoices
    val allInvoices: Flow<List<Invoice>> = invoiceDao.getAllInvoices()
    
    fun searchInvoices(query: String): Flow<List<Invoice>> = invoiceDao.searchInvoices(query)
    
    suspend fun insertInvoice(invoice: Invoice) = withContext(Dispatchers.IO) {
        // First deduct product stock quantities for purchased items!
        val items = deserializeInvoiceItems(invoice.itemsJson)
        for (item in items) {
            val product = productDao.getProductById(item.productId)
            if (product != null) {
                // Deduct inventory
                val updatedQty = (product.quantity - item.quantity).coerceAtLeast(0)
                productDao.updateProduct(product.copy(quantity = updatedQty))
            }
        }
        invoiceDao.insertInvoice(invoice)
    }

    // Invoice Item Serialization / Deserialization helpers using Moshi
    fun serializeInvoiceItems(items: List<InvoiceItem>): String {
        val type = Types.newParameterizedType(List::class.java, InvoiceItem::class.java)
        val adapter = moshi.adapter<List<InvoiceItem>>(type)
        return adapter.toJson(items)
    }

    fun deserializeInvoiceItems(jsonStr: String): List<InvoiceItem> {
        return try {
            val type = Types.newParameterizedType(List::class.java, InvoiceItem::class.java)
            val adapter = moshi.adapter<List<InvoiceItem>>(type)
            adapter.fromJson(jsonStr) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Backup & Restore System
    suspend fun generateBackupJson(): String = withContext(Dispatchers.IO) {
        val productsList = productDao.getAllProducts().collectToList()
        val customersList = customerDao.getAllCustomers().collectToList()
        val invoicesList = invoiceDao.getAllInvoices().collectToList()
        val shopsList = shopDao.getAllShops().collectToList()
        val expensesList = expenseDao.getAllExpenses().collectToList()
        val suppliersList = supplierDao.getAllSuppliers().collectToList()
        val purchaseOrdersList = purchaseOrderDao.getAllPurchaseOrders().collectToList()
        val categoriesList = categoryDao.getAllCategories().collectToList()
        val supplierTransactionsList = supplierTransactionDao.getAllSupplierTransactions().collectToList()
        
        val backup = BackupData(
            products = productsList,
            customers = customersList,
            invoices = invoicesList,
            shops = shopsList,
            expenses = expensesList,
            suppliers = suppliersList,
            purchaseOrders = purchaseOrdersList,
            categories = categoriesList,
            supplierTransactions = supplierTransactionsList
        )
        val adapter = moshi.adapter(BackupData::class.java)
        adapter.toJson(backup)
    }

    suspend fun restoreBackupFromJson(jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val adapter = moshi.adapter(BackupData::class.java)
            val backup = adapter.fromJson(jsonString) ?: return@withContext false
            
            // Core database atomic changes inside database transaction or sequentially safely
            db.runInTransaction {
                // Clear existing
                db.clearAllTables()
            }
            
            for (p in backup.products) {
                productDao.insertProduct(p)
            }
            for (c in backup.customers) {
                customerDao.insertCustomer(c)
            }
            for (inv in backup.invoices) {
                invoiceDao.insertInvoice(inv)
            }
            for (s in backup.shops) {
                shopDao.insertShop(s)
            }
            for (e in backup.expenses) {
                expenseDao.insertExpense(e)
            }
            for (sup in backup.suppliers) {
                supplierDao.insertSupplier(sup)
            }
            for (po in backup.purchaseOrders) {
                purchaseOrderDao.insertPurchaseOrder(po)
            }
            for (cat in backup.categories) {
                categoryDao.insertCategory(cat)
            }
            for (st in backup.supplierTransactions) {
                supplierTransactionDao.insertTransaction(st)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    // Private helper to get all items from a flow sequentially safely
    private suspend fun <T> Flow<List<T>>.collectToList(): List<T> {
        return this.firstOrNull() ?: emptyList()
    }
}
