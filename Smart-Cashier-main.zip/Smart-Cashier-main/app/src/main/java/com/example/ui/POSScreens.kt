package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.example.ui.theme.*
import androidx.lifecycle.viewModelScope
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import android.content.Intent
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.*

sealed class Screen(val title: String) {
    object Dashboard : Screen("Dashboard")
    object CashMemo : Screen("Cash Memo")
    object Products : Screen("Products")
    object Customers : Screen("Customers")
    object Reports : Screen("Reports")
    object Settings : Screen("Settings")
}

// -----------------------------------------------------------------------------
// CUSTOM HIGH-WEIGHT CUSTOM RENDERING COMPONENTS (BARCODE & QR CODES)
// -----------------------------------------------------------------------------

@Composable
fun StylizedBarcode(
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(8.dp))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val cleanValue = value.ifBlank { "000000000000" }
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp)
        ) {
            val barCount = 45
            val widthPerBar = size.width / barCount
            val random = Random(cleanValue.hashCode().toLong())
            
            for (i in 0 until barCount) {
                // Generate high/low bars based on seed
                val isBlackBar = i == 0 || i == barCount - 1 || i == barCount / 2 || random.nextBoolean()
                if (isBlackBar) {
                    val isGuardLine = i == 0 || i == barCount - 1 || i == barCount / 2 || i == 1 || i == barCount - 2
                    val h = if (isGuardLine) size.height else size.height * 0.85f
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(i * widthPerBar, 0f),
                        size = androidx.compose.ui.geometry.Size(widthPerBar * 0.7f, h)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = cleanValue,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = Color.Black,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
    }
}

@Composable
fun StylizedQRCode(
    value: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(140.dp)
            .background(Color.White, RoundedCornerShape(12.dp))
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        val cleanValue = value.ifBlank { "SmartPOS" }
        Canvas(modifier = Modifier.fillMaxSize()) {
            val sizeGrid = 15
            val blockWidth = size.width / sizeGrid
            val blockHeight = size.height / sizeGrid
            val r = Random(cleanValue.hashCode().toLong())

            for (x in 0 until sizeGrid) {
                for (y in 0 until sizeGrid) {
                    // Marker blocks in three corners
                    val isCornerFinder = 
                        (x < 4 && y < 4) || 
                        (x >= sizeGrid - 4 && y < 4) || 
                        (x < 4 && y >= sizeGrid - 4)
                    
                    val isBorderFinder =
                        (x == 0 && y < 4) || (x == 3 && y < 4) || (y == 0 && x < 4) || (y == 3 && x < 4) ||
                        (x == sizeGrid - 1 && y < 4) || (x == sizeGrid - 4 && y < 4) || (y == 0 && x >= sizeGrid - 4) || (y == 3 && x >= sizeGrid - 4) ||
                        (x == 0 && y >= sizeGrid - 4) || (x == 3 && y >= sizeGrid - 4) || (y == sizeGrid - 1 && x < 4) || (y == sizeGrid - 4 && x < 4)

                    val isTargetCenter =
                        (x == 1 && y == 1) || (x == 2 && y == 1) || (x == 1 && y == 2) || (x == 2 && y == 2) ||
                        (x == sizeGrid - 2 && y == 1) || (x == sizeGrid - 3 && y == 1) || (x == sizeGrid - 2 && y == 2) || (x == sizeGrid - 3 && y == 2) ||
                        (x == 1 && y == sizeGrid - 2) || (x == 2 && y == sizeGrid - 2) || (x == 1 && y == sizeGrid - 3) || (x == 2 && y == sizeGrid - 3)

                    if (isCornerFinder) {
                        if (isBorderFinder || isTargetCenter) {
                            drawRect(
                                color = Color.Black,
                                topLeft = Offset(x * blockWidth, y * blockHeight),
                                size = androidx.compose.ui.geometry.Size(blockWidth, blockHeight)
                            )
                        }
                    } else {
                        // Random QR bits for other areas
                        if (r.nextBoolean()) {
                            drawRect(
                                color = Color.Black,
                                topLeft = Offset(x * blockWidth, y * blockHeight),
                                size = androidx.compose.ui.geometry.Size(blockWidth, blockHeight)
                            )
                        }
                    }
                }
            }
        }
    }
}


// -----------------------------------------------------------------------------
// COMPLEX BEAUTIFUL SALES LINE GRAPH (BEZIER PURE COMPOSE CANVAS)
// -----------------------------------------------------------------------------

@Composable
fun BeautifulSalesGraph(
    currency: String,
    modifier: Modifier = Modifier
) {
    val salesData = listOf(450.0, 780.0, 520.0, 1100.0, 890.0, 1400.0, 1250.0)
    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Weekly Revenue Performance",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Real-time trends on total invoices committed",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
                Box(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "+32% This Week",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Canvas drawing
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    
                    val maxVal = salesData.maxOrNull() ?: 1.0
                    val minVal = 0.0
                    val valueRange = maxVal - minVal

                    // Draw grid lines
                    val horizontalLines = 4
                    for (i in 0..horizontalLines) {
                        val y = height - (i * (height / horizontalLines))
                        drawLine(
                            color = Color.LightGray.copy(alpha = 0.3f),
                            start = Offset(0f, y),
                            end = Offset(width, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    // Create Bezier Path
                    val points = salesData.mapIndexed { idx, value ->
                        val x = idx * (width / (salesData.size - 1))
                        val y = height - (((value - minVal) / valueRange) * height).toFloat()
                        Offset(x, y)
                    }

                    val path = Path()
                    val fillPath = Path()

                    if (points.isNotEmpty()) {
                        path.moveTo(points[0].x, points[0].y)
                        fillPath.moveTo(points[0].x, points[0].y)

                        for (i in 1 until points.size) {
                            val prev = points[i - 1]
                            val curr = points[i]
                            val cx = (prev.x + curr.x) / 2
                            
                            // bezier curve interpolation
                            path.quadraticTo(prev.x, prev.y, cx, (prev.y + curr.y) / 2)
                            fillPath.quadraticTo(prev.x, prev.y, cx, (prev.y + curr.y) / 2)
                        }
                        
                        path.lineTo(points.last().x, points.last().y)
                        fillPath.lineTo(points.last().x, points.last().y)
                        
                        // Close fill path
                        fillPath.lineTo(width, height)
                        fillPath.lineTo(0f, height)
                        fillPath.close()
                    }

                    // Draw filled gradient area
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                EmeraldActive.copy(alpha = 0.35f),
                                Color.Transparent
                            )
                        )
                    )

                    // Draw curve line
                    drawPath(
                        path = path,
                        color = EmeraldActive,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw points
                    points.forEachIndexed { i, pt ->
                        drawCircle(
                            color = EmeraldDark,
                            radius = 5.dp.toPx(),
                            center = pt
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 2.5.dp.toPx(),
                            center = pt
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // X-axis text Labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                days.forEach { day ->
                    Text(
                        text = day,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}


// -----------------------------------------------------------------------------
// SCREEN 1: DASHBOARD
// -----------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    viewModel: POSViewModel,
    onNavigate: (Screen) -> Unit
) {
    val context = LocalContext.current
    val lowStockList by viewModel.lowStockProducts.collectAsState()
    val productsList by viewModel.products.collectAsState()
    val customersList by viewModel.customers.collectAsState()
    val invoicesList by viewModel.invoices.collectAsState()
    val stats by viewModel.getSalesStats().collectAsState(initial = Triple(0.0, 0.0, 0.0))
    val currencySymbol by viewModel.multiCurrencySymbol.collectAsState()

    var selectedInvoiceDetail by remember { mutableStateOf<Invoice?>(null) }

    if (selectedInvoiceDetail != null) {
        CommittedInvoiceReceiptDialog(
            invoice = selectedInvoiceDetail!!,
            currency = currencySymbol,
            viewModel = viewModel,
            onDismiss = { selectedInvoiceDetail = null }
        )
    }

    // Dynamic Greetings
    val timeFormat = SimpleDateFormat("H", Locale.getDefault())
    val hour = timeFormat.format(Date()).toIntOrNull() ?: 12
    val greetingText = when {
        hour < 12 -> "Good Morning, Boss! 🌅"
        hour < 17 -> "Good Afternoon, Owner! ☀️"
        else -> "Good Evening, Shop Admin! 🌇"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Theme Header Box matching HTML smart POS
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Smart POS",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color(0xFF10B981), CircleShape)
                        )
                        Text(
                            text = "SYNC ACTIVE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                            letterSpacing = 1.sp
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(
                        onClick = { onNavigate(Screen.Products) },
                        modifier = Modifier
                            .size(40.dp)
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f), CircleShape)
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search Items", tint = MaterialTheme.colorScheme.onBackground)
                    }
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color(0xFF047857), CircleShape)
                            .border(2.dp, Color(0xFFD1FAE5), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "JD",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // Bento Welcome Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = greetingText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Welcome to your point-of-sale cockpit. Beautiful responsive dashboard running on edge.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // 2. Today's Revenue Bento (Large 24.dp Card)
        item {
            val formattedRevenue = String.format("%.2f", stats.first)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF059669)), // emerald-600
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TODAY'S REVENUE",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD1FAE5),
                            letterSpacing = 1.2.sp
                        )
                        Box(
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "+12.5%",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Column {
                        Text(
                            text = "$currencySymbol$formattedRevenue",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            letterSpacing = (-1).sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${invoicesList.size} invoices generated secure",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFA7F3D0)
                        )
                    }
                }
            }
        }

        // 3. Business Summary Portfolio Bento Row (Total Buying, Selling, Available)
        item {
            val purchaseOrdersList by viewModel.purchaseOrders.collectAsState()

            // Total Buying
            val receivedPOs = purchaseOrdersList.filter { it.status == "Received" }
            val poBuyingQty = receivedPOs.sumOf { po ->
                viewModel.deserializePurchaseOrderItems(po.itemsJson).sumOf { it.quantity }
            }
            val poBuyingAmt = receivedPOs.sumOf { it.totalCost }
            val totalBuyingQty = if (poBuyingQty > 0) poBuyingQty else productsList.sumOf { it.quantity }
            val totalBuyingAmt = if (poBuyingAmt > 0.0) poBuyingAmt else productsList.sumOf { it.quantity * it.purchasePrice }

            // Total Selling
            val totalSellingQty = invoicesList.sumOf { inv ->
                viewModel.deserializeInvoiceItems(inv.itemsJson).sumOf { it.quantity }
            }
            val totalSellingAmt = invoicesList.sumOf { it.grandTotal }

            // Total Available
            val totalAvailableQty = productsList.sumOf { it.quantity }
            val totalAvailableAmt = productsList.sumOf { it.quantity * it.sellingPrice }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "PORTFOLIO LEDGER SUMMARY",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Col 1: Total Buying (Investment)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingCart,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Buying", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$currencySymbol${String.format("%.2f", totalBuyingAmt)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "$totalBuyingQty items",
                                fontSize = 9.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Col 2: Total Selling (Sales)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0xFFE6F4EA), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.TrendingUp,
                                    contentDescription = null,
                                    tint = Color(0xFF137333),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Selling", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF137333))
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$currencySymbol${String.format("%.2f", totalSellingAmt)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = Color(0xFF137333),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "$totalSellingQty items",
                                fontSize = 9.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Col 3: Total Available (Stock)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0xFFFEF7E0), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Inventory,
                                    contentDescription = null,
                                    tint = Color(0xFFB06000),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Available", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFFB06000))
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$currencySymbol${String.format("%.2f", totalAvailableAmt)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = Color(0xFFB06000),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "$totalAvailableQty items",
                                fontSize = 9.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Split Bento Grid Row (Low Stock & Customers)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Low Stock Bento (White surface with custom styling)
                Card(
                    modifier = Modifier.weight(1f).clickable {
                        viewModel.filterLowStockInInventory.value = true
                        onNavigate(Screen.Products)
                    },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "LOW STOCK",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = String.format("%02d", lowStockList.size),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (lowStockList.isNotEmpty()) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurface
                            )
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        if (lowStockList.isNotEmpty()) Color(0xFFFEE2E2) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Category,
                                    contentDescription = null,
                                    tint = if (lowStockList.isNotEmpty()) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                // Customers Bento (Slate surface with custom styling)
                Card(
                    modifier = Modifier.weight(1f).clickable {
                        onNavigate(Screen.Customers)
                    },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)), // slate-800
                    border = BorderStroke(1.dp, Color(0xFF334155)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "CUSTOMERS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF94A3B8), // slate-400
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = "${customersList.size}",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color(0xFF334155), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Group,
                                    contentDescription = null,
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Quick Actions Scrollable Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Action 1: New Invoice
                Button(
                    onClick = { onNavigate(Screen.CashMemo) },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFECFDF5),
                        contentColor = Color(0xFF047857)
                    ),
                    border = BorderStroke(1.dp, Color(0xFFD1FAE5)),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddShoppingCart,
                        contentDescription = null,
                        tint = Color(0xFF047857),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("New Invoice", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Action 2: Add Customer
                Button(
                    onClick = { onNavigate(Screen.Customers) },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PersonAdd,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Add Client", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Action 3: Products / Restock
                Button(
                    onClick = { onNavigate(Screen.Products) },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Inventory,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Scan Item", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Beautiful Weekly Revenue Graph
        item {
            BeautifulSalesGraph(currency = currencySymbol, modifier = Modifier.fillMaxWidth())
        }

        // Stock warnings if any
        if (lowStockList.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "STOCK WARNINGS",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error,
                                letterSpacing = 1.sp
                            )
                            TextButton(onClick = { onNavigate(Screen.Products) }) {
                                Text("Reorder Now", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            lowStockList.take(2).forEach { product ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.error.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = product.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text(text = "SKU: ${product.sku}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(MaterialTheme.colorScheme.error, RoundedCornerShape(12.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "${product.quantity} left",
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Cohesive Recent Transactions Bento Box
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RECENT ACTIVITY",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                            letterSpacing = 1.2.sp
                        )
                        TextButton(onClick = { onNavigate(Screen.CashMemo) }) {
                            Text("View Registration", color = Color(0xFF047857), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (invoicesList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No invoices generated yet. Use the register to create invoices.",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            invoicesList.take(3).forEach { invoice ->
                                val dateStr = SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date(invoice.date))
                                val invoicePaid = invoice.paidAmount
                                val invoiceDue = (invoice.grandTotal - invoicePaid).coerceAtLeast(0.0)
                                val statusText = if (invoiceDue <= 0.0) "PAID" else if (invoicePaid > 0.0) "PARTIAL" else "UNPAID"
                                val statusColor = if (invoiceDue <= 0.0) Color(0xFF10B981) else if (invoicePaid > 0.0) Color(0xFFF59E0B) else Color(0xFFEF4444)

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.02f), RoundedCornerShape(16.dp))
                                        .clickable { selectedInvoiceDetail = invoice }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ReceiptLong,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = invoice.invoiceId, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Text(text = "${invoice.customerName} • Paid: $currencySymbol${String.format("%.2f", invoicePaid)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(text = "$currencySymbol${String.format("%.2f", invoice.grandTotal)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(text = statusText, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = statusColor)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Extra spacing at bottom
        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    backgroundColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .background(Color.White.copy(alpha = 0.5f), CircleShape)
                    .size(36.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = textColor, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = title, fontSize = 12.sp, color = textColor.copy(alpha = 0.7f), fontWeight = FontWeight.Medium)
            Text(text = value, fontSize = 20.sp, color = textColor, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun QuickMetric(
    label: String,
    valStr: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isWarning: Boolean = false
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .background(
                    if (isWarning) Color(0xFFFEE2E2) else MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                    CircleShape
                )
                .size(44.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isWarning) Color(0xFFEF4444) else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = valStr, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
    }
}

@Composable
fun Icon(imageName: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Icon(imageVector = icon, contentDescription = imageName, tint = color, modifier = Modifier.size(24.dp))
}


// Shared Invoice Recycler View Item
@Composable
fun InvoiceListItemView(invoice: Invoice, currency: String, onClick: (() -> Unit)? = null) {
    val dateStr = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date(invoice.date))
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = onClick != null) { onClick?.invoke() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = invoice.invoiceId, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = invoice.customerName, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                Text(text = dateStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
            Text(
                text = "$currency${String.format("%.2f", invoice.grandTotal)}",
                fontWeight = FontWeight.Bold,
                color = EmeraldDark,
                fontSize = 15.sp,
                textAlign = TextAlign.End
            )
        }
    }
}


// -----------------------------------------------------------------------------
// SCREEN 2: INVENTORY & PRODUCT MANAGEMENT
// -----------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductsScreen(viewModel: POSViewModel) {
    val productsList by viewModel.products.collectAsState()
    val lowStockList by viewModel.lowStockProducts.collectAsState()
    val searchQuery by viewModel.productSearchQuery.collectAsState()
    val currencySymbol by viewModel.multiCurrencySymbol.collectAsState()
    val filterLowStockInInventory by viewModel.filterLowStockInInventory.collectAsState()
    val context = LocalContext.current

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedProductForEdit by remember { mutableStateOf<Product?>(null) }
    var selectedProductForBarcodeInspect by remember { mutableStateOf<Product?>(null) }
    var productToDelete by remember { mutableStateOf<Product?>(null) }

    var selectedCategoryFilter by remember { mutableStateOf("All") }

    val dbCategories by viewModel.categories.collectAsState()
    val dbSuppliers by viewModel.allSuppliersList.collectAsState()
    val categories = (listOf("All") + dbCategories.map { it.name } + productsList.map { it.category }).distinct()

    val filteredList = if (filterLowStockInInventory) {
        productsList.filter { it.quantity <= 5 }
    } else if (selectedCategoryFilter == "All") {
        productsList
    } else {
        productsList.filter { it.category == selectedCategoryFilter }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Product")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                var showCategoryManager by remember { mutableStateOf(false) }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Inventory Control", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    TextButton(
                        onClick = { showCategoryManager = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(imageVector = Icons.Default.Category, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Categories", fontWeight = FontWeight.Bold)
                    }
                }

                if (showCategoryManager) {
                    CategoryManagerDialog(
                        viewModel = viewModel,
                        onDismiss = { showCategoryManager = false }
                    )
                }
            }

            // Search Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.productSearchQuery.value = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Search by name, SKU or Barcode") },
                        leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.productSearchQuery.value = "" }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Clear Search")
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    IconButton(
                        onClick = {
                            val scanner = GmsBarcodeScanning.getClient(context)
                            scanner.startScan()
                                .addOnSuccessListener { result ->
                                    val sc = result.rawValue ?: ""
                                    if (sc.isNotBlank()) {
                                        viewModel.productSearchQuery.value = sc
                                        Toast.makeText(context, "Scanned: $sc", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(context, "Mobile Scan: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Scan with mobile phone camera",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Category Filter list row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = selectedCategoryFilter == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategoryFilter = cat },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
            }

            // Stock warnings
            if (filterLowStockInInventory) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Viewing ${filteredList.size} low stock products (Qty <= 5)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            TextButton(
                                onClick = { viewModel.filterLowStockInInventory.value = false }
                            ) {
                                Text("Show All", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            } else if (lowStockList.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { viewModel.filterLowStockInInventory.value = true },
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "${lowStockList.size} items are running out of stock! Click here to filter low stock.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Product List
            if (filteredList.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.Inbox, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.Gray)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No Products found", style = MaterialTheme.typography.bodyLarge, color = Color.Gray)
                            Text("Verify clean filters or add some new inventory records using the '+' button.", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
                        }
                    }
                }
            } else {
                items(filteredList) { product ->
                    ProductItemRow(
                        product = product,
                        currency = currencySymbol,
                        allSuppliers = dbSuppliers,
                        onEdit = { selectedProductForEdit = product },
                        onBarcodeInspect = { selectedProductForBarcodeInspect = product },
                        onDelete = { productToDelete = product }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(60.dp))
                }
            }
        }
    }

    // Modal: Add Dialog
    if (showAddDialog) {
        ProductFormDialog(
            product = null,
            categoriesList = dbCategories,
            suppliersList = dbSuppliers,
            viewModel = viewModel,
            onDismiss = { showAddDialog = false },
            onSave = { name, sku, cat, sell, purch, qty, unit, bar, supplierIds ->
                viewModel.saveProduct("", name, sku, cat, sell, purch, qty, unit, bar, "", "default_shop", 0.0, supplierIds) {
                    showAddDialog = false
                }
            }
        )
    }

    // Modal: Edit Dialog
    if (selectedProductForEdit != null) {
        ProductFormDialog(
            product = selectedProductForEdit,
            categoriesList = dbCategories,
            suppliersList = dbSuppliers,
            viewModel = viewModel,
            onDismiss = { selectedProductForEdit = null },
            onSave = { name, sku, cat, sell, purch, qty, unit, bar, supplierIds ->
                viewModel.saveProduct(
                    selectedProductForEdit!!.id,
                    name, sku, cat, sell, purch, qty, unit, bar,
                    selectedProductForEdit!!.imageUrl,
                    selectedProductForEdit!!.shopId,
                    selectedProductForEdit!!.taxRate,
                    supplierIds
                ) {
                    selectedProductForEdit = null
                }
            }
        )
    }

    // Modal: Barcode Display
    if (selectedProductForBarcodeInspect != null) {
        BarcodeInspectDialog(
            product = selectedProductForBarcodeInspect!!,
            onDismiss = { selectedProductForBarcodeInspect = null }
        )
    }

    if (productToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Product",
            message = "Are you sure you want to permanently delete '${productToDelete!!.name}' (SKU: ${productToDelete!!.sku}) from the inventory?",
            onConfirm = { viewModel.deleteProduct(productToDelete!!) },
            onDismiss = { productToDelete = null }
        )
    }
}

@Composable
fun ProductItemRow(
    product: Product,
    currency: String,
    allSuppliers: List<Supplier> = emptyList(),
    onEdit: () -> Unit,
    onBarcodeInspect: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = if (product.quantity <= 5) BorderStroke(1.5.dp, OutOfStockRed.copy(alpha = 0.5f)) else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Visual circle badge with initial of product category
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        if (product.quantity <= 5) OutOfStockRed.copy(alpha = 0.15f) else EmeraldActive.copy(alpha = 0.12f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = product.name.firstOrNull()?.uppercase() ?: "",
                    fontWeight = FontWeight.Bold,
                    color = if (product.quantity <= 5) OutOfStockRed else EmeraldDark
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = product.name,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (product.quantity <= 5) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(OutOfStockRed, RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = if (product.quantity == 0) "OUT" else "LOW",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
                Text(
                    text = "SKU: ${product.sku} | Bar: ${product.barcode}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                val productSupplierIds = product.supplierIds.split(",").filter { it.isNotBlank() }
                if (productSupplierIds.isNotEmpty()) {
                    val names = allSuppliers.filter { it.id in productSupplierIds }.map { it.name }
                    if (names.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Suppliers: ${names.joinToString(", ")}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Sell: $currency${String.format("%.2f", product.sellingPrice)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Cost: $currency${String.format("%.2f", product.purchasePrice)}", fontSize = 11.sp, color = Color.Gray)
                    Text(text = "Qty: ${product.quantity} ${product.unit}", fontSize = 12.sp, color = if (product.quantity <= 5) OutOfStockRed else EmeraldDark, fontWeight = FontWeight.SemiBold)
                }
            }

            // Quick Actions column
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onBarcodeInspect) {
                    Icon(imageVector = Icons.Default.QrCode, contentDescription = "Barcode/QR", tint = InfoBlue)
                }
                IconButton(onClick = onEdit) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Product", tint = WarningOrange)
                }
                IconButton(onClick = onDelete) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = OutOfStockRed)
                }
            }
        }
    }
}

@Composable
fun AddNewSupplierInlineDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, company: String, mobile: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var company by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Quick Add Supplier") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (errorText.isNotBlank()) {
                    Text(errorText, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Supplier Name*") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = company,
                    onValueChange = { company = it },
                    label = { Text("Company Name") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it },
                    label = { Text("Mobile/Phone*") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank() || mobile.isBlank()) {
                        errorText = "Please fill in all mandatory fields."
                    } else {
                        onSave(name, company, mobile)
                    }
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductFormDialog(
    product: Product?,
    categoriesList: List<Category>,
    suppliersList: List<Supplier>,
    viewModel: POSViewModel,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Double, Double, Int, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var sku by remember { mutableStateOf(product?.sku ?: "") }
    var category by remember { mutableStateOf(product?.category ?: (categoriesList.firstOrNull()?.name ?: "Grocery")) }
    var sellingPrice by remember { mutableStateOf(product?.sellingPrice?.toString() ?: "") }
    var purchasePrice by remember { mutableStateOf(product?.purchasePrice?.toString() ?: "") }
    var quantity by remember { mutableStateOf(product?.quantity?.toString() ?: "") }
    var unit by remember { mutableStateOf(product?.unit ?: "pcs") }
    var barcode by remember { mutableStateOf(product?.barcode ?: "") }

    var selectedSupplierIds by remember {
        mutableStateOf(
            product?.supplierIds?.split(",")?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
        )
    }

    var showInlineSupplierAdd by remember { mutableStateOf(false) }

    if (showInlineSupplierAdd) {
        AddNewSupplierInlineDialog(
            onDismiss = { showInlineSupplierAdd = false },
            onSave = { sName, sCompany, sMobile ->
                val newId = "SUP-${(1000..9999).random()}"
                viewModel.saveSupplier(
                    id = newId,
                    name = sName,
                    companyName = sCompany,
                    mobile = sMobile,
                    email = "",
                    address = "",
                    taxNumber = "",
                    notes = "Inline quick-add",
                    outstandingBalance = 0.0
                ) {
                    selectedSupplierIds = selectedSupplierIds + newId
                    showInlineSupplierAdd = false
                }
            }
        )
    }

    var errorText by remember { mutableStateOf("") }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (product == null) "New Inventory Product" else "Modify Product Details") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (errorText.isNotBlank()) {
                    Text(text = errorText, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Product Name*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = { Text("SKU / Code*") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    
                    var expandedCategoryDropdown by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = expandedCategoryDropdown,
                        onExpandedChange = { expandedCategoryDropdown = !expandedCategoryDropdown },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Category") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCategoryDropdown) },
                            modifier = Modifier.menuAnchor(),
                            shape = RoundedCornerShape(4.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expandedCategoryDropdown,
                            onDismissRequest = { expandedCategoryDropdown = false }
                        ) {
                            categoriesList.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.name) },
                                    onClick = {
                                        category = cat.name
                                        expandedCategoryDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Supplier Select Dropdown
                var expandedSupplierDropdown by remember { mutableStateOf(false) }
                val selectedSupplierNamesText = if (selectedSupplierIds.isEmpty()) {
                    "No Supplier Selected"
                } else {
                    suppliersList.filter { it.id in selectedSupplierIds }.map { it.name }.joinToString(", ")
                }

                ExposedDropdownMenuBox(
                    expanded = expandedSupplierDropdown,
                    onExpandedChange = { expandedSupplierDropdown = !expandedSupplierDropdown },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedSupplierNamesText,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Select Suppliers (Multi-Select)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedSupplierDropdown) },
                        modifier = Modifier.fillMaxWidth().menuAnchor(),
                        shape = RoundedCornerShape(4.dp),
                        supportingText = { Text("Associated suppliers for this product.") }
                    )
                    ExposedDropdownMenu(
                        expanded = expandedSupplierDropdown,
                        onDismissRequest = { expandedSupplierDropdown = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        DropdownMenuItem(
                            text = { 
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = EmeraldDark, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add New Supplier Profile...", color = EmeraldDark, fontWeight = FontWeight.Bold)
                                }
                            },
                            onClick = {
                                showInlineSupplierAdd = true
                                expandedSupplierDropdown = false
                            }
                        )
                        
                        if (suppliersList.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("No suppliers registered yet.", style = MaterialTheme.typography.bodySmall, color = Color.Gray) },
                                onClick = {}
                            )
                        } else {
                            suppliersList.forEach { supplier ->
                                val isChecked = supplier.id in selectedSupplierIds
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Checkbox(
                                                checked = isChecked,
                                                onCheckedChange = { checked ->
                                                    selectedSupplierIds = if (checked) {
                                                        selectedSupplierIds + supplier.id
                                                    } else {
                                                        selectedSupplierIds - supplier.id
                                                    }
                                                }
                                            )
                                            Text(text = "${supplier.name} (${supplier.companyName})", fontSize = 14.sp)
                                        }
                                    },
                                    onClick = {
                                        selectedSupplierIds = if (isChecked) {
                                            selectedSupplierIds - supplier.id
                                        } else {
                                            selectedSupplierIds + supplier.id
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sellingPrice,
                        onValueChange = { sellingPrice = it },
                        label = { Text("Selling Price*") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = purchasePrice,
                        onValueChange = { purchasePrice = it },
                        label = { Text("Cost Price") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Qty In Stock*") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unit (e.g. pc, kg)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = barcode,
                    onValueChange = { barcode = it },
                    label = { Text("Barcode Number (12-digit UPC)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    val scanner = GmsBarcodeScanning.getClient(context)
                                    scanner.startScan()
                                        .addOnSuccessListener { result ->
                                            val sc = result.rawValue ?: ""
                                            if (sc.isNotBlank()) {
                                                barcode = sc
                                                Toast.makeText(context, "Captured: $sc", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                        .addOnFailureListener { e ->
                                            Toast.makeText(context, "Mobile scanner failed: ${e.message}", Toast.LENGTH_LONG).show()
                                        }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = "Scan packaging barcode",
                                    tint = EmeraldDark
                                )
                            }
                            IconButton(onClick = { barcode = (100000000000..999999999999).random().toString() }) {
                                Icon(imageVector = Icons.Default.Shuffle, contentDescription = "Auto Barcode")
                            }
                        }
                    }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank() || sku.isBlank() || sellingPrice.toDoubleOrNull() == null || quantity.toIntOrNull() == null) {
                        errorText = "Please fill in all mandatory fields with valid values."
                    } else {
                        onSave(
                            name, sku, category,
                            sellingPrice.toDouble(),
                            purchasePrice.toDoubleOrNull() ?: 0.0,
                            quantity.toInt(),
                            unit,
                            barcode.ifBlank { "000000000000" },
                            selectedSupplierIds.joinToString(",")
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Save Record")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun BarcodeInspectDialog(
    product: Product,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "${product.name} Barcode Details", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(text = "Category: ${product.category} | SKU: ${product.sku}", fontSize = 12.sp, color = Color.Gray)
                
                Text(text = "Adaptive Barcode (Visualizer)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                StylizedBarcode(value = product.barcode, modifier = Modifier.fillMaxWidth())

                Text(text = "Mobile QR Code Scanner", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                StylizedQRCode(value = "product_sku://${product.sku}", modifier = Modifier.size(140.dp))
                
                Text(text = "Place label in front of standard thermal register scanner to test.", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close Viewer")
            }
        }
    )
}


// -----------------------------------------------------------------------------
// SCREEN 3: CUSTOMER CONTROL
// -----------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomersScreen(viewModel: POSViewModel) {
    val customersList by viewModel.customers.collectAsState()
    val invoicesList by viewModel.invoices.collectAsState()
    val searchCustQuery by viewModel.customerSearchQuery.collectAsState()
    val currencySymbol by viewModel.multiCurrencySymbol.collectAsState()

    var showAddCustDialog by remember { mutableStateOf(false) }
    var selectedCustomerForEdit by remember { mutableStateOf<Customer?>(null) }
    var selectedCustomerForHistory by remember { mutableStateOf<Customer?>(null) }
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddCustDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(imageVector = Icons.Default.PersonAdd, contentDescription = "Add Customer")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(text = "Customer CRM Ledger", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }

            // Search box
            item {
                OutlinedTextField(
                    value = searchCustQuery,
                    onValueChange = { viewModel.customerSearchQuery.value = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search by customer name or email/mobile") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            // Users list
            if (customersList.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.Group, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.Gray)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No Customers in Database", style = MaterialTheme.typography.bodyLarge, color = Color.Gray)
                            Text("Create profiles or tap seed defaults in Settings to simulate active customer registries.", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
                        }
                    }
                }
            } else {
                items(customersList) { customer ->
                    val customerInvoices = invoicesList.filter { it.customerId == customer.id }
                    val purchaseCount = customerInvoices.size
                    val purchaseTotal = customerInvoices.sumOf { it.grandTotal }
                    val paidTotal = customerInvoices.sumOf { it.paidAmount }
                    val dueTotal = (purchaseTotal - paidTotal).coerceAtLeast(0.0)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedCustomerForHistory = customer },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Avatar circle
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = customer.name.take(2).uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = customer.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text(text = "☎ ${customer.mobile} | ✉ ${customer.email}", fontSize = 11.sp, color = Color.Gray)
                                Text(text = "📍 ${customer.address}", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    SuggestionChip(onClick = {}, label = { Text("$purchaseCount Orders", fontSize = 9.sp) })
                                    SuggestionChip(onClick = {}, label = { Text("Buy: $currencySymbol${String.format("%.2f", purchaseTotal)}", fontSize = 9.sp) })
                                    SuggestionChip(onClick = {}, label = { Text("Paid: $currencySymbol${String.format("%.2f", paidTotal)}", fontSize = 9.sp) })
                                    if (dueTotal > 0.0) {
                                        SuggestionChip(
                                            onClick = {}, 
                                            label = { Text("Due: $currencySymbol${String.format("%.2f", dueTotal)}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = OutOfStockRed) }
                                        )
                                    }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(onClick = { selectedCustomerForEdit = customer }) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Profile", tint = WarningOrange)
                                }
                                IconButton(onClick = { customerToDelete = customer }) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove Account", tint = OutOfStockRed)
                                }
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(60.dp))
                }
            }
        }
    }

    // Modal: Add Customer
    if (showAddCustDialog) {
        CustomerFormDialog(
            customer = null,
            onDismiss = { showAddCustDialog = false },
            onSave = { name, mob, email, address, notes ->
                viewModel.saveCustomer("", name, mob, email, address, notes) {
                    showAddCustDialog = false
                }
            }
        )
    }

    // Modal: Edit Customer
    if (selectedCustomerForEdit != null) {
        CustomerFormDialog(
            customer = selectedCustomerForEdit,
            onDismiss = { selectedCustomerForEdit = null },
            onSave = { name, mob, email, address, notes ->
                viewModel.saveCustomer(
                    selectedCustomerForEdit!!.id,
                    name, mob, email, address, notes
                ) {
                    selectedCustomerForEdit = null
                }
            }
        )
    }

    // Modal: History Details
    if (selectedCustomerForHistory != null) {
        val liveCustomer = customersList.find { it.id == selectedCustomerForHistory!!.id } ?: selectedCustomerForHistory!!
        CustomerHistoryDetailsDialog(
            customer = liveCustomer,
            invoices = invoicesList,
            currency = currencySymbol,
            viewModel = viewModel,
            onDismiss = { selectedCustomerForHistory = null }
        )
    }

    if (customerToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Customer",
            message = "Are you sure you want to permanently delete customer '${customerToDelete!!.name}'? This will remove their ledger account, profile, and accumulated rewards.",
            onConfirm = { viewModel.deleteCustomer(customerToDelete!!) },
            onDismiss = { customerToDelete = null }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerFormDialog(
    customer: Customer?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf(customer?.name ?: "") }
    var mobile by remember { mutableStateOf(customer?.mobile ?: "") }
    var email by remember { mutableStateOf(customer?.email ?: "") }
    var address by remember { mutableStateOf(customer?.address ?: "") }
    var notes by remember { mutableStateOf(customer?.notes ?: "") }

    var errorMsg by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (customer == null) "Add Customer Portfolio" else "Modify Profile") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (errorMsg.isNotBlank()) {
                    Text(text = errorMsg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Customer Name*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it },
                    label = { Text("Mobile Number*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Street Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Special Ledger Notes") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank() || mobile.isBlank()) {
                        errorMsg = "Name and Mobile indicators are required to register accounts."
                    } else {
                        onSave(name, mobile, email, address, notes)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Confirm Ledger Profile")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun CustomerHistoryDetailsDialog(
    customer: Customer,
    invoices: List<Invoice>,
    currency: String,
    viewModel: POSViewModel,
    onDismiss: () -> Unit
) {
    val filteredInvoices = invoices.filter { it.customerId == customer.id }
    val totalSpent = filteredInvoices.sumOf { it.grandTotal }
    val totalPaid = filteredInvoices.sumOf { it.paidAmount }
    val totalDue = (totalSpent - totalPaid).coerceAtLeast(0.0)

    var selectedInvoiceForDetail by remember { mutableStateOf<Invoice?>(null) }
    var showAdjustDialog by remember { mutableStateOf(false) }

    if (selectedInvoiceForDetail != null) {
        CommittedInvoiceReceiptDialog(
            invoice = selectedInvoiceForDetail!!,
            currency = currency,
            viewModel = viewModel,
            onDismiss = { selectedInvoiceForDetail = null }
        )
    }

    if (showAdjustDialog) {
        var pointsDeltaStr by remember { mutableStateOf("") }
        var creditDeltaStr by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdjustDialog = false },
            title = { Text("Adjust Loyalty & Store Credit", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Directly increment or decrement this client's rewards balance. Use negative values to subtract.", fontSize = 12.sp, color = Color.Gray)
                    OutlinedTextField(
                        value = pointsDeltaStr,
                        onValueChange = { pointsDeltaStr = it },
                        label = { Text("Loyalty Points Delta (e.g. 50 or -20)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = creditDeltaStr,
                        onValueChange = { creditDeltaStr = it },
                        label = { Text("Store Credit Delta (e.g. 25.00 or -10.00)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        leadingIcon = { Text(currency) }
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val pDelta = pointsDeltaStr.toIntOrNull() ?: 0
                    val cDelta = creditDeltaStr.toDoubleOrNull() ?: 0.0
                    viewModel.adjustCustomerLoyaltyAndCredit(customer.id, pDelta, cDelta)
                    showAdjustDialog = false
                }) {
                    Text("Apply Adjustments")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdjustDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.ContactPage, contentDescription = null, tint = EmeraldDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = customer.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp)
            ) {
                Text(text = "CRM Ledger Stats", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = LightGrayBg),
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "Mobile: ${customer.mobile}", fontSize = 12.sp)
                        Text(text = "Email: ${customer.email}", fontSize = 12.sp)
                        Text(text = "Invoice Counts: ${filteredInvoices.size} records", fontSize = 12.sp)

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "Loyalty Points: ${customer.loyaltyPoints} pts", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DarkBlue)
                                Text(text = "Store Credit Balance: $currency${String.format("%.2f", customer.storeCredit)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                            }
                            IconButton(
                                onClick = { showAdjustDialog = true },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Edit, contentDescription = "Adjust", tint = DarkBlue, modifier = Modifier.size(18.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))

                        Text(text = "Total Buy Amount: $currency${String.format("%.2f", totalSpent)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DarkBlue)
                        Text(text = "Total Paid Amount: $currency${String.format("%.2f", totalPaid)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                        Text(text = "Total Due Balance: $currency${String.format("%.2f", totalDue)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (totalDue > 0.0) OutOfStockRed else Color.Gray)
                        if (customer.notes.isNotBlank()) {
                            Text(text = "Notes: ${customer.notes}", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(text = "Recent Cash Memos (${filteredInvoices.size}) - Click to view detail", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                if (filteredInvoices.isEmpty()) {
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text("No Transactions Committed.", fontSize = 11.sp, color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredInvoices) { inv ->
                            InvoiceListItemView(
                                invoice = inv,
                                currency = currency,
                                onClick = { selectedInvoiceForDetail = inv }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Dismiss Ledger")
            }
        }
    )
}

@Composable
fun SupplierLedgerDetailsDialog(
    supplier: Supplier,
    viewModel: POSViewModel,
    currencySymbol: String,
    onDismiss: () -> Unit
) {
    val transactionsFlow = remember(supplier.id) { viewModel.getTransactionsForSupplier(supplier.id) }
    val transactions by transactionsFlow.collectAsState(initial = emptyList())

    val totalBuys = transactions.filter { it.type == "BUY" }.sumOf { it.amount }
    val totalPaid = transactions.filter { it.type == "PAYMENT" }.sumOf { it.amount }
    val outstandingDue = (totalBuys - totalPaid).coerceAtLeast(0.0)

    var showRecordTransactionForm by remember { mutableStateOf(false) }
    var txType by remember { mutableStateOf("BUY") } // "BUY" or "PAYMENT"
    var txAmount by remember { mutableStateOf("") }
    var txNotes by remember { mutableStateOf("") }
    var txRef by remember { mutableStateOf("") }
    var transactionToDelete by remember { mutableStateOf<SupplierTransaction?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Assessment, contentDescription = null, tint = EmeraldDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Supplier Dual-Ledger: ${supplier.name}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = LightGrayBg)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Company: ${supplier.companyName}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Contact: ${supplier.mobile} • ${supplier.email}", fontSize = 11.sp)
                        Divider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray)
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Buys (Purchases):", fontSize = 11.sp)
                            Text("$currencySymbol${String.format("%.2f", totalBuys)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DarkBlue)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Payments (Paid):", fontSize = 11.sp)
                            Text("$currencySymbol${String.format("%.2f", totalPaid)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Outstanding Due:", fontSize = 11.sp)
                            Text("$currencySymbol${String.format("%.2f", outstandingDue)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (outstandingDue > 0.0) OutOfStockRed else Color.Gray)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Ledger History (${transactions.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Button(
                        onClick = { showRecordTransactionForm = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Record", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (showRecordTransactionForm) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("New Ledger Entry", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                FilterChip(
                                    selected = txType == "BUY",
                                    onClick = { txType = "BUY" },
                                    label = { Text("Buy / Bill Amount", fontSize = 10.sp) }
                                )
                                FilterChip(
                                    selected = txType == "PAYMENT",
                                    onClick = { txType = "PAYMENT" },
                                    label = { Text("Payment / Paid Amount", fontSize = 10.sp) }
                                )
                            }

                            OutlinedTextField(
                                value = txAmount,
                                onValueChange = { txAmount = it },
                                label = { Text("Amount ($currencySymbol)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = txRef,
                                onValueChange = { txRef = it },
                                label = { Text("Reference # (Optional)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = txNotes,
                                onValueChange = { txNotes = it },
                                label = { Text("Notes") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { showRecordTransactionForm = false }) {
                                    Text("Cancel", fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Button(
                                    onClick = {
                                        val amt = txAmount.toDoubleOrNull() ?: 0.0
                                        if (amt > 0.0) {
                                            viewModel.recordSupplierTransaction(
                                                supplierId = supplier.id,
                                                type = txType,
                                                amount = amt,
                                                notes = txNotes.ifBlank { if (txType == "BUY") "Purchase order/Bill" else "Account Payment" },
                                                referenceId = txRef
                                            )
                                            txAmount = ""
                                            txNotes = ""
                                            txRef = ""
                                            showRecordTransactionForm = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark)
                                ) {
                                    Text("Record Entry", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                if (transactions.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                        Text("No ledger transactions recorded.", fontSize = 11.sp, color = Color.Gray, fontStyle = FontStyle.Italic)
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        transactions.forEach { tx ->
                            val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(tx.date))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White, RoundedCornerShape(8.dp))
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Surface(
                                            color = (if (tx.type == "BUY") Color(0xFFFEE2E2) else Color(0xFFD1FAE5)),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = tx.type,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (tx.type == "BUY") Color.Red else Color(0xFF047857),
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                        Text(text = dateStr, fontSize = 9.sp, color = Color.Gray)
                                    }
                                    Text(text = tx.notes, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                    if (tx.referenceId.isNotBlank()) {
                                        Text(text = "Ref: ${tx.referenceId}", fontSize = 10.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${if (tx.type == "BUY") "-" else "+"}$currencySymbol${String.format("%.2f", tx.amount)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (tx.type == "BUY") OutOfStockRed else EmeraldDark
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { transactionToDelete = tx },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = OutOfStockRed, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Dismiss Ledger")
            }
        }
    )

    if (transactionToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Transaction Record",
            message = "Are you sure you want to delete this ${transactionToDelete!!.type} ledger entry of amount $currencySymbol${String.format("%.2f", transactionToDelete!!.amount)}?",
            onConfirm = { viewModel.deleteSupplierTransaction(transactionToDelete!!) },
            onDismiss = { transactionToDelete = null }
        )
    }
}

// -----------------------------------------------------------------------------
// SCREEN 4: INTENSIVE CASH MEMO / POS CART SYSTEM
// -----------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun CashMemoScreen(
    viewModel: POSViewModel
) {
    val context = LocalContext.current
    val cartItems by viewModel.cartItems.collectAsState()
    val customersList by viewModel.customers.collectAsState()
    val productsList by viewModel.products.collectAsState()
    
    val selectedCustomer by viewModel.selectedCustomerForInvoice.collectAsState()
    val discountAmt by viewModel.discountAmount.collectAsState()
    val discountPct by viewModel.discountPercentage.collectAsState()
    val subtotalVal by viewModel.subtotal.collectAsState()
    val taxVal by viewModel.taxAmount.collectAsState()
    val grandTotalVal by viewModel.grandTotal.collectAsState()
    val invoiceIdSecret by viewModel.currentInvoiceId.collectAsState()
    
    val currencySymbol by viewModel.multiCurrencySymbol.collectAsState()
    val isTaxEnabled by viewModel.isTaxEnabled.collectAsState()
    val defaultTaxPercentage by viewModel.defaultTaxPercentage.collectAsState()

    var productSearchQuery by remember { mutableStateOf("") }
    var matchingProducts = if (productSearchQuery.isBlank()) {
        productsList
    } else {
        productsList.filter { 
            it.name.contains(productSearchQuery, ignoreCase = true) || 
            it.sku.contains(productSearchQuery, ignoreCase = true) ||
            it.barcode.contains(productSearchQuery, ignoreCase = true)
        }
    }

    var selectedBarcodeScannerSim by remember { mutableStateOf(false) }
    var showCustomerPickerDropdown by remember { mutableStateOf(false) }
    var committedInvoiceIdForVisualDialog by remember { mutableStateOf<Invoice?>(null) }

    // Settlement States
    var isPaidSelected by remember { mutableStateOf(true) }
    var enteredPaidAmountStr by remember { mutableStateOf("") }
    
    val actualPaidAmount = if (isPaidSelected) {
        enteredPaidAmountStr.toDoubleOrNull() ?: grandTotalVal
    } else {
        0.0
    }
    val dueAmount = (grandTotalVal - actualPaidAmount).coerceAtLeast(0.0)

    LaunchedEffect(grandTotalVal, isPaidSelected) {
        if (isPaidSelected) {
            enteredPaidAmountStr = String.format(Locale.US, "%.2f", grandTotalVal)
        } else {
            enteredPaidAmountStr = "0.00"
        }
    }

    // States for custom ad-hoc line item addition
    var showCustomItemForm by remember { mutableStateOf(false) }
    var customItemName by remember { mutableStateOf("") }
    var customItemPrice by remember { mutableStateOf("") }
    var customItemQty by remember { mutableStateOf("1") }
    var customItemUnit by remember { mutableStateOf("pcs") }

    // State for editing any active item in the cart
    var activeCartItemForEditing by remember { mutableStateOf<InvoiceItem?>(null) }

    // Responsive configuration
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isWide = configuration.screenWidthDp >= 800 || configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    var selectedMobileTab by remember { mutableStateOf(0) } // 0 = Builder, 1 = Preview

    // Main checkout trigger block
    val handleCheckout = {
        val ptsRedeemed = viewModel.pointsToRedeem.value
        val creditApplied = viewModel.storeCreditToApply.value
        viewModel.commitInvoice(
            paidAmount = actualPaidAmount,
            pointsRedeemed = ptsRedeemed,
            storeCreditApplied = creditApplied,
            onSuccess = { invoice ->
                committedInvoiceIdForVisualDialog = invoice
            },
            onError = { err ->
                Toast.makeText(context, "Commit error: $err", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // -------------------------------------------------------------------------
    // DIALOGS & SHEET HELPERS
    // -------------------------------------------------------------------------

    // Dialog: Edit Item Details
    if (activeCartItemForEditing != null) {
        val item = activeCartItemForEditing!!
        var editName by remember { mutableStateOf(item.productName) }
        var editPrice by remember { mutableStateOf(item.sellingPrice.toString()) }
        var editQty by remember { mutableStateOf(item.quantity.toString()) }
        var editUnit by remember { mutableStateOf(item.unit) }
        
        AlertDialog(
            onDismissRequest = { activeCartItemForEditing = null },
            title = { Text("Modify Invoice Line Item", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Item Name / Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editPrice,
                            onValueChange = { editPrice = it },
                            label = { Text("Rate") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1.5f),
                            leadingIcon = { Text(currencySymbol) }
                        )
                        OutlinedTextField(
                            value = editUnit,
                            onValueChange = { editUnit = it },
                            label = { Text("Unit") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = editQty,
                        onValueChange = { editQty = it },
                        label = { Text("Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val priceVal = editPrice.toDoubleOrNull() ?: item.sellingPrice
                        val qtyVal = editQty.toIntOrNull() ?: item.quantity
                        viewModel.updateCartItemDetails(item.productId, editName, priceVal, editUnit, qtyVal)
                        activeCartItemForEditing = null
                        Toast.makeText(context, "Item details updated!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark)
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        viewModel.removeFromCart(item.productId)
                        activeCartItemForEditing = null
                        Toast.makeText(context, "Item removed from bill", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = OutOfStockRed)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("Delete Line")
                    }
                }
            }
        )
    }

    // -------------------------------------------------------------------------
    // MASTER UI COMPOSE STRUCTURE
    // -------------------------------------------------------------------------

    // Shared Builder Form Workspace Content Composable
    val builderFormContent = @Composable {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 60.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Master POS Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Billing & Invoicing Generator",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = DarkBlue
                    )
                    Text(
                        text = "Document Draft: $invoiceIdSecret",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray
                    )
                }
                FilledTonalButton(
                    onClick = { viewModel.clearCart() },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer
                    )
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset Bill", fontSize = 11.sp)
                }
            }

            // Customer selection block
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(EmeraldLight, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = EmeraldDark, modifier = Modifier.size(18.dp))
                        }
                        Column {
                            Text("Billed Client Ledger", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text(
                                text = selectedCustomer?.name ?: "Walk-in Cash Client",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            if (selectedCustomer != null) {
                                Text(text = "Tel: ${selectedCustomer!!.mobile}", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                    Button(
                        onClick = { showCustomerPickerDropdown = true },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkBlue)
                    ) {
                        Text(if (selectedCustomer == null) "Select client" else "Switch", fontSize = 12.sp)
                    }
                }
            }

            if (selectedCustomer != null) {
                val cust = selectedCustomer!!
                val pointsToRedeemVal by viewModel.pointsToRedeem.collectAsState()
                val storeCreditToApplyVal by viewModel.storeCreditToApply.collectAsState()
                val loyaltyDiscountVal by viewModel.loyaltyDiscount.collectAsState()

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Stars, contentDescription = null, tint = EmeraldDark)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Customer Rewards & Store Credit", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = DarkBlue)
                        }
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Loyalty Points Available: ${cust.loyaltyPoints} pts", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                Text("Points Discount: $currencySymbol${String.format("%.2f", loyaltyDiscountVal)}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(
                                    onClick = { 
                                        val canRedeem = cust.loyaltyPoints
                                        viewModel.pointsToRedeem.value = if (pointsToRedeemVal == 0) canRedeem else 0
                                    },
                                    colors = ButtonDefaults.textButtonColors(contentColor = DarkBlue)
                                ) {
                                    Text(if (pointsToRedeemVal == 0) "Redeem All" else "Clear", fontSize = 12.sp)
                                }
                                OutlinedTextField(
                                    value = if (pointsToRedeemVal == 0) "" else pointsToRedeemVal.toString(),
                                    onValueChange = { 
                                        val parsed = it.toIntOrNull() ?: 0
                                        viewModel.pointsToRedeem.value = parsed.coerceAtMost(cust.loyaltyPoints)
                                    },
                                    placeholder = { Text("0") },
                                    modifier = Modifier.width(65.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )
                            }
                        }

                        Divider(color = Color.LightGray.copy(alpha = 0.3f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Store Credit Available: $currencySymbol${String.format("%.2f", cust.storeCredit)}", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                Text("Applied to Payment: $currencySymbol${String.format("%.2f", storeCreditToApplyVal)}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(
                                    onClick = { 
                                        viewModel.storeCreditToApply.value = if (storeCreditToApplyVal == 0.0) cust.storeCredit.coerceAtMost(grandTotalVal) else 0.0
                                    },
                                    colors = ButtonDefaults.textButtonColors(contentColor = DarkBlue)
                                ) {
                                    Text(if (storeCreditToApplyVal == 0.0) "Apply All" else "Clear", fontSize = 12.sp)
                                }
                                OutlinedTextField(
                                    value = if (storeCreditToApplyVal == 0.0) "" else storeCreditToApplyVal.toString(),
                                    onValueChange = { 
                                        val parsed = it.toDoubleOrNull() ?: 0.0
                                        viewModel.storeCreditToApply.value = parsed.coerceAtMost(cust.storeCredit).coerceAtMost(grandTotalVal)
                                    },
                                    placeholder = { Text("0.00") },
                                    modifier = Modifier.width(85.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    leadingIcon = { Text(currencySymbol, fontSize = 9.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // Product Inventory search & quick-add box
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Search Inventory & Quick-Add", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = productSearchQuery,
                            onValueChange = { productSearchQuery = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Search description, SKU, or barcode...") },
                            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            trailingIcon = {
                                if (productSearchQuery.isNotEmpty()) {
                                    IconButton(onClick = { productSearchQuery = "" }) {
                                        Icon(imageVector = Icons.Default.Close, contentDescription = null)
                                    }
                                }
                            }
                        )

                        Button(
                            onClick = { selectedBarcodeScannerSim = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            modifier = Modifier.align(Alignment.CenterVertically)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("Scan UPC", fontSize = 12.sp)
                            }
                        }
                    }

                    // Product instant results list
                    if (productSearchQuery.isNotBlank()) {
                        Text("Matched Inventory Results (${matchingProducts.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 150.dp)
                                .background(LightGrayBg, RoundedCornerShape(8.dp))
                                .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(4.dp)
                        ) {
                            if (matchingProducts.isEmpty()) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("No matched codes or SKU in inventory", fontSize = 11.sp)
                                }
                            } else {
                                LazyColumn {
                                    items(matchingProducts) { p ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    viewModel.addToCart(p, 1)
                                                    productSearchQuery = "" // reset
                                                    Toast.makeText(context, "${p.name} added!", Toast.LENGTH_SHORT).show()
                                                }
                                                .padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(text = p.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text(text = "SKU: ${p.sku} | Stock: ${p.quantity} ${p.unit}", fontSize = 11.sp, color = if (p.quantity <= 5) OutOfStockRed else Color.Gray)
                                            }
                                            Text(
                                                text = "$currencySymbol${String.format("%.2f", p.sellingPrice)}",
                                                color = EmeraldDark,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                        }
                                        Divider(color = Color.LightGray.copy(alpha = 0.2f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // NEW FEATURE: Collapsible Custom/Ad-Hoc Line Item Addition Form
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.AddBox, contentDescription = null, tint = EmeraldDark)
                            Text("Create Custom / Service Line Item", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }
                        IconButton(onClick = { showCustomItemForm = !showCustomItemForm }) {
                            Icon(
                                imageVector = if (showCustomItemForm) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null
                            )
                        }
                    }
                    
                    AnimatedVisibility(visible = showCustomItemForm) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = customItemName,
                                onValueChange = { customItemName = it },
                                label = { Text("Item Name / Description") },
                                placeholder = { Text("e.g. Consultancy Services, Priority Assembly") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = customItemPrice,
                                    onValueChange = { customItemPrice = it },
                                    label = { Text("Rate") },
                                    placeholder = { Text("0.00") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true,
                                    leadingIcon = { Text(currencySymbol) }
                                )
                                OutlinedTextField(
                                    value = customItemQty,
                                    onValueChange = { customItemQty = it },
                                    label = { Text("Qty") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(0.8f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = customItemUnit,
                                    onValueChange = { customItemUnit = it },
                                    label = { Text("Unit") },
                                    placeholder = { Text("pcs") },
                                    modifier = Modifier.weight(0.8f),
                                    singleLine = true
                                )
                            }
                            
                            Button(
                                onClick = {
                                    val name = customItemName.trim()
                                    val price = customItemPrice.toDoubleOrNull() ?: 0.0
                                    val qty = customItemQty.toIntOrNull() ?: 1
                                    val unit = customItemUnit.trim().ifBlank { "pcs" }
                                    
                                    if (name.isBlank()) {
                                        Toast.makeText(context, "Item description required", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    
                                    viewModel.addCustomLineItem(name, price, qty, unit)
                                    
                                    // Reset form fields
                                    customItemName = ""
                                    customItemPrice = ""
                                    customItemQty = "1"
                                    customItemUnit = "pcs"
                                    showCustomItemForm = false
                                    Toast.makeText(context, "Custom item successfully added!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Insert Ad-Hoc Item", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Cart details & lines title
            Text(
                text = "BILLING REGISTER DETAILS (${cartItems.size} items added)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DarkBlue
            )

            // Scrollable Active items list inside Builder form
            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(LightGrayBg, RoundedCornerShape(12.dp))
                        .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Draft memo is currently empty", fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("Search the inventory above, scan barcodes, or create custom line items to build a bill.", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
                    }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    cartItems.forEach { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.2f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(text = item.productName, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        IconButton(
                                            onClick = { activeCartItemForEditing = item },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit details", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    Text(
                                        text = "$currencySymbol${String.format("%.2f", item.sellingPrice)} x ${item.quantity} ${item.unit}",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                                
                                // Direct Quick Quantity Stepper
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.background(LightGrayBg, RoundedCornerShape(8.dp))
                                ) {
                                    IconButton(
                                        onClick = { viewModel.updateCartQuantity(item.productId, item.quantity - 1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrement", modifier = Modifier.size(14.dp))
                                    }
                                    Text(text = "${item.quantity}", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp))
                                    IconButton(
                                        onClick = { viewModel.updateCartQuantity(item.productId, item.quantity + 1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Add, contentDescription = "Increment", modifier = Modifier.size(14.dp))
                                    }
                                }
                                
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "$currencySymbol${String.format("%.2f", item.totalPrice)}",
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldDark,
                                    fontSize = 14.sp,
                                    modifier = Modifier.widthIn(min = 70.dp),
                                    textAlign = TextAlign.End,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Calculations, Discounts & Tax panel
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Subtotal", fontSize = 12.sp)
                        Text("$currencySymbol${String.format("%.2f", subtotalVal)}", fontWeight = FontWeight.Medium, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }

                    // Discounts Input Line
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Apply Discounts", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Percentage or fixed amount", fontSize = 9.sp, color = Color.Gray)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = if (discountPct == 0.0) "" else discountPct.toString(),
                                onValueChange = { viewModel.setDiscountPercentage(it.toDoubleOrNull() ?: 0.0) },
                                modifier = Modifier.width(65.dp),
                                placeholder = { Text("%") },
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            Text("+", fontSize = 12.sp, color = Color.Gray)
                            OutlinedTextField(
                                value = if (discountAmt == 0.0) "" else discountAmt.toString(),
                                onValueChange = { viewModel.setDiscountAmount(it.toDoubleOrNull() ?: 0.0) },
                                modifier = Modifier.width(80.dp),
                                placeholder = { Text("Amt") },
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                leadingIcon = { Text(currencySymbol, fontSize = 9.sp) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Text("VAT / Sales Tax", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = isTaxEnabled,
                                onCheckedChange = { viewModel.isTaxEnabled.value = it },
                                modifier = Modifier.scale(0.8f)
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isTaxEnabled) {
                                OutlinedTextField(
                                    value = if (defaultTaxPercentage == 0.0) "" else defaultTaxPercentage.toString(),
                                    onValueChange = { input ->
                                        val parsed = input.toDoubleOrNull()
                                        if (parsed != null) {
                                            viewModel.defaultTaxPercentage.value = parsed
                                        } else if (input.isEmpty()) {
                                            viewModel.defaultTaxPercentage.value = 0.0
                                        }
                                    },
                                    modifier = Modifier.width(65.dp),
                                    placeholder = { Text("%") },
                                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )
                            }
                            Text(
                                text = "+$currencySymbol${String.format("%.2f", taxVal)}",
                                fontWeight = FontWeight.Medium,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (isTaxEnabled) Color.Unspecified else Color.Gray
                            )
                        }
                    }

                    Divider(color = Color.LightGray.copy(alpha = 0.3f))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Grand Total", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("$currencySymbol${String.format("%.2f", grandTotalVal)}", fontWeight = FontWeight.Bold, color = EmeraldDark, fontSize = 18.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // Settlement & Paid Balance Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.Payments, contentDescription = null, tint = EmeraldDark)
                            Text("Settlement & Paid Balance", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }
                        Switch(
                            checked = isPaidSelected,
                            onCheckedChange = { 
                                isPaidSelected = it
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldDark, checkedTrackColor = EmeraldLight)
                        )
                    }
                    
                    if (isPaidSelected) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = enteredPaidAmountStr,
                                onValueChange = { enteredPaidAmountStr = it },
                                label = { Text("Amount Paid (${currencySymbol})") },
                                placeholder = { Text(String.format(Locale.US, "%.2f", grandTotalVal)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1.2f),
                                singleLine = true
                            )
                            
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text("Grand Total: $currencySymbol${String.format("%.2f", grandTotalVal)}", fontSize = 11.sp, color = Color.Gray)
                                Text("Paid: $currencySymbol${String.format("%.2f", actualPaidAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                                Text("Due Balance: $currencySymbol${String.format("%.2f", dueAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (dueAmount > 0.0) OutOfStockRed else Color.Gray)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Invoice marked as UNPAID / DUE", fontSize = 12.sp, color = OutOfStockRed, fontWeight = FontWeight.SemiBold)
                            Text("Due: $currencySymbol${String.format("%.2f", grandTotalVal)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OutOfStockRed)
                        }
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // RENDER LAYOUT PREFERENCE
    // -------------------------------------------------------------------------
    if (isWide) {
        // Desktop / Tablet Double-Column Split Panel
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(LightGrayBg)
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Pane (60%): Invoice Builder
            Box(
                modifier = Modifier
                    .weight(0.58f)
                    .fillMaxHeight()
                    .background(Color.White, RoundedCornerShape(12.dp))
                    .border(1.dp, Color.LightGray.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                builderFormContent()
            }

            // Right Pane (40%): Live Interactive Digital Invoice Sheet
            Box(
                modifier = Modifier
                    .weight(0.42f)
                    .fillMaxHeight()
            ) {
                RealTimeInvoicePaperPreview(
                    invoiceId = invoiceIdSecret,
                    customerName = selectedCustomer?.name ?: "Walk-in Cash Client",
                    customerMobile = selectedCustomer?.mobile ?: "",
                    customerEmail = selectedCustomer?.email ?: "",
                    customerAddress = selectedCustomer?.address ?: "",
                    cartItems = cartItems,
                    currencySymbol = currencySymbol,
                    subtotal = subtotalVal,
                    taxAmount = taxVal,
                    taxPercentage = viewModel.defaultTaxPercentage.value,
                    discountAmount = discountAmt,
                    discountPercentage = discountPct,
                    grandTotal = grandTotalVal,
                    paidAmount = actualPaidAmount,
                    onCheckoutClick = handleCheckout
                )
            }
        }
    } else {
        // Mobile Screen with dynamic Sliding Tab Selectors (0 = Builder, 1 = Preview)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(LightGrayBg)
        ) {
            TabRow(
                selectedTabIndex = selectedMobileTab,
                containerColor = Color.White,
                contentColor = DarkBlue
            ) {
                Tab(
                    selected = selectedMobileTab == 0,
                    onClick = { selectedMobileTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("Bill Builder", fontWeight = FontWeight.Bold)
                        }
                    }
                )
                Tab(
                    selected = selectedMobileTab == 1,
                    onClick = { selectedMobileTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("Invoice Live (${cartItems.size})", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                if (selectedMobileTab == 0) {
                    builderFormContent()
                } else {
                    RealTimeInvoicePaperPreview(
                        invoiceId = invoiceIdSecret,
                        customerName = selectedCustomer?.name ?: "Walk-in Cash Client",
                        customerMobile = selectedCustomer?.mobile ?: "",
                        customerEmail = selectedCustomer?.email ?: "",
                        customerAddress = selectedCustomer?.address ?: "",
                        cartItems = cartItems,
                        currencySymbol = currencySymbol,
                        subtotal = subtotalVal,
                        taxAmount = taxVal,
                        taxPercentage = viewModel.defaultTaxPercentage.value,
                        discountAmount = discountAmt,
                        discountPercentage = discountPct,
                        grandTotal = grandTotalVal,
                        paidAmount = actualPaidAmount,
                        onCheckoutClick = handleCheckout
                    )
                }
            }

            if (cartItems.isNotEmpty()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedMobileTab = 1 },
                    color = DarkBlue,
                    contentColor = Color.White,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.2f), CircleShape)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${cartItems.sumOf { it.quantity }}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Column {
                                Text("Running Cart Total", fontSize = 11.sp, color = Color.LightGray)
                                Text("$currencySymbol${String.format("%.2f", grandTotalVal)}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                        
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("View Invoice Draft", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }

    // Modal: Simulated Laser Scanner
    if (selectedBarcodeScannerSim) {
        BarcodeScannerSimulatorDialog(
            products = productsList,
            currencySymbol = currencySymbol,
            onBarcodeScanned = { matchedProduct ->
                if (matchedProduct != null) {
                    viewModel.addToCart(matchedProduct, 1)
                    Toast.makeText(context, "Scanned: ${matchedProduct.name} - Price: ${currencySymbol}${String.format("%.2f", matchedProduct.sellingPrice)}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Barcode has no matching product records", Toast.LENGTH_LONG).show()
                }
            },
            onDismiss = { selectedBarcodeScannerSim = false }
        )
    }

    // Modal: Customer Portfolio Selector
    if (showCustomerPickerDropdown) {
        CustomerPickerDropdownDialog(
            customers = customersList,
            onSelected = { user ->
                viewModel.selectCustomerForInvoice(user)
                showCustomerPickerDropdown = false
            },
            onAddCustomer = { name, mobile ->
                val customerId = "C-${(1000..9999).random()}"
                viewModel.saveCustomer(
                    id = customerId,
                    name = name,
                    mobile = mobile,
                    email = "",
                    address = "",
                    notes = "Added via checkout quick register"
                ) {
                    val newCustomerObj = Customer(
                        id = customerId,
                        name = name,
                        mobile = mobile,
                        email = "",
                        address = "",
                        notes = "Added via checkout quick register"
                    )
                    viewModel.selectCustomerForInvoice(newCustomerObj)
                    showCustomerPickerDropdown = false
                }
            },
            onDismiss = { showCustomerPickerDropdown = false }
        )
    }

    // Modal: Committed Invoice Receipt Viewer (PRINT / PDF / SHARE)
    if (committedInvoiceIdForVisualDialog != null) {
        CommittedInvoiceReceiptDialog(
            invoice = committedInvoiceIdForVisualDialog!!,
            currency = currencySymbol,
            viewModel = viewModel,
            onDismiss = {
                committedInvoiceIdForVisualDialog = null
            }
        )
    }
}

@Composable
fun RealTimeInvoicePaperPreview(
    invoiceId: String,
    customerName: String,
    customerMobile: String,
    customerEmail: String,
    customerAddress: String,
    cartItems: List<InvoiceItem>,
    currencySymbol: String,
    subtotal: Double,
    taxAmount: Double,
    taxPercentage: Double,
    discountAmount: Double,
    discountPercentage: Double,
    grandTotal: Double,
    paidAmount: Double,
    onCheckoutClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                // Letterhead
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SMART LEDGER INC",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = DarkBlue
                        )
                        Text(
                            text = "100 Enterprise Way, Suite 400\nSaaS Cloud Headquarters",
                            fontSize = 9.sp,
                            color = Color.Gray,
                            lineHeight = 11.sp
                        )
                    }
                    
                    Surface(
                        color = EmeraldLight,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "OFFICIAL INVOICE",
                            color = EmeraldDark,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            letterSpacing = 0.5.sp
                        )
                    }
                }
                
                Divider(color = Color.LightGray, modifier = Modifier.padding(vertical = 12.dp))
                
                // Invoice Details Meta Block
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "CLIENT / BILLED TO:", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text(text = customerName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        if (customerMobile.isNotBlank()) {
                            Text(text = "Mobile: $customerMobile", fontSize = 10.sp, color = Color.DarkGray)
                        }
                        if (customerEmail.isNotBlank()) {
                            Text(text = "Email: $customerEmail", fontSize = 10.sp, color = Color.DarkGray)
                        }
                    }
                    
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "INVOICE METADATA:", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "ID:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text(text = invoiceId, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "DATE:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text(
                                text = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()),
                                fontSize = 10.sp,
                                color = Color.Black
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "STATUS:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            val remainingDue = (grandTotal - paidAmount).coerceAtLeast(0.0)
                            val statusText = if (remainingDue <= 0.0) "PAID" else if (paidAmount > 0.0) "PARTIALLY PAID" else "UNPAID"
                            val statusColor = if (remainingDue <= 0.0) EmeraldDark else if (paidAmount > 0.0) Color(0xFFF59E0B) else OutOfStockRed
                            Text(text = statusText, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = statusColor)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Invoice Table Header
                Surface(
                    color = LightGrayBg,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Description", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray, modifier = Modifier.weight(1.5f))
                        Text(text = "Qty", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray, modifier = Modifier.weight(0.4f), textAlign = TextAlign.Center)
                        Text(text = "Rate", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray, modifier = Modifier.weight(0.6f), textAlign = TextAlign.End)
                        Text(text = "Total", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                    }
                }
                
                // Invoice Line Items
                if (cartItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No items added to bill yet.", fontSize = 11.sp, color = Color.Gray, fontStyle = FontStyle.Italic)
                    }
                } else {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        cartItems.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.5f)) {
                                    Text(text = item.productName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    Text(text = "ID: ${item.productId.take(8)}", fontSize = 8.sp, color = Color.Gray)
                                }
                                Text(
                                    text = "${item.quantity} ${item.unit}",
                                    fontSize = 11.sp,
                                    color = Color.Black,
                                    modifier = Modifier.weight(0.4f),
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "$currencySymbol${String.format("%.2f", item.sellingPrice)}",
                                    fontSize = 11.sp,
                                    color = Color.Black,
                                    modifier = Modifier.weight(0.6f),
                                    textAlign = TextAlign.End,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "$currencySymbol${String.format("%.2f", item.totalPrice)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black,
                                    modifier = Modifier.weight(0.7f),
                                    textAlign = TextAlign.End,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Divider(color = Color.LightGray.copy(alpha = 0.3f))
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Financial Calculation Summary
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.End)
                        .padding(horizontal = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Spacer(modifier = Modifier.weight(1f))
                        Row(modifier = Modifier.weight(1.2f), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Subtotal", fontSize = 10.sp, color = Color.Gray)
                            Text("$currencySymbol${String.format("%.2f", subtotal)}", fontSize = 10.sp, color = Color.Black, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Spacer(modifier = Modifier.weight(1f))
                        Row(modifier = Modifier.weight(1.2f), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("VAT / Sales Tax ($taxPercentage%)", fontSize = 10.sp, color = Color.Gray)
                            Text("+$currencySymbol${String.format("%.2f", taxAmount)}", fontSize = 10.sp, color = Color.Black, fontFamily = FontFamily.Monospace)
                        }
                    }
                    if (discountAmount > 0 || discountPercentage > 0) {
                        val totalDiscVal = discountAmount + (subtotal * (discountPercentage / 100.0))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Spacer(modifier = Modifier.weight(1f))
                            Row(modifier = Modifier.weight(1.2f), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Discount Applied", fontSize = 10.sp, color = EmeraldDark)
                                Text("-$currencySymbol${String.format("%.2f", totalDiscVal)}", fontSize = 10.sp, color = EmeraldDark, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                    
                    Divider(color = Color.LightGray, modifier = Modifier.padding(vertical = 4.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Spacer(modifier = Modifier.weight(1f))
                        Row(modifier = Modifier.weight(1.2f), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("GRAND TOTAL", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DarkBlue)
                            Text("$currencySymbol${String.format("%.2f", grandTotal)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DarkBlue, fontFamily = FontFamily.Monospace)
                        }
                    }

                    val remainingDue = (grandTotal - paidAmount).coerceAtLeast(0.0)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Spacer(modifier = Modifier.weight(1f))
                        Row(modifier = Modifier.weight(1.2f), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Amount Paid", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                            Text("$currencySymbol${String.format("%.2f", paidAmount)}", fontSize = 11.sp, color = Color.Black, fontFamily = FontFamily.Monospace)
                        }
                    }

                    if (remainingDue > 0.0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Spacer(modifier = Modifier.weight(1f))
                            Row(modifier = Modifier.weight(1.2f), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("DUE BALANCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OutOfStockRed)
                                Text("$currencySymbol${String.format("%.2f", remainingDue)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = OutOfStockRed, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
            
            // Footer Section of Invoice Sheet
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 20.dp)) {
                // Stylized Barcode showing invoice id
                StylizedBarcode(
                    value = invoiceId.filter { it.isDigit() }.take(12).ifEmpty { "123456789012" },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(35.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Thank you for doing business with Smart Ledger Inc.",
                    fontSize = 8.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Action checkout button
                Button(
                    onClick = onCheckoutClick,
                    enabled = cartItems.isNotEmpty(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null)
                        Text("Issue Invoice & Finalize", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}




// Dropdown Customer Picker Dialog
@Composable
fun CustomerPickerDropdownDialog(
    customers: List<Customer>,
    onSelected: (Customer?) -> Unit,
    onAddCustomer: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var addNewMode by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newMobile by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Checkout Customer", style = MaterialTheme.typography.titleMedium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Add New", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Spacer(modifier = Modifier.width(4.dp))
                    Switch(
                        checked = addNewMode,
                        onCheckedChange = { addNewMode = it },
                        modifier = Modifier.scale(0.7f)
                    )
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (addNewMode) {
                    Text("Enter new customer details to save & register them instantly.", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    if (errorText.isNotEmpty()) {
                        Text(errorText, color = MaterialTheme.colorScheme.error, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Customer Name*") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newMobile,
                        onValueChange = { newMobile = it },
                        label = { Text("Mobile Number*") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Button(
                        onClick = {
                            if (newName.isBlank() || newMobile.isBlank()) {
                                errorText = "Name and Mobile are required!"
                            } else {
                                onAddCustomer(newName, newMobile)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save & Assign Customer", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text("Tapping a client profile assigns them to the current checkout memo.", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 240.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelected(null) },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Text("Walk-in Anonymous Checkout 👤", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                            }
                        }
                        items(customers) { c ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelected(c) },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text(text = c.name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(text = "Tel: ${c.mobile}", fontSize = 10.sp, color = Color.Gray)
                                    }
                                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close Picker")
            }
        }
    )
}

// Barcode Scanning Laser Simulator Dialog
@Composable
fun BarcodeScannerSimulatorDialog(
    products: List<Product>,
    currencySymbol: String = "$",
    onBarcodeScanned: (Product?) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, tint = EmeraldDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Select Barcode Scan Mode")
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Choose how you would like to scan product items into your active terminal billing:", fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(16.dp))

                // Primary Option: Real Device Camera Scan
                Button(
                    onClick = {
                        val scanner = GmsBarcodeScanning.getClient(context)
                        scanner.startScan()
                            .addOnSuccessListener { result ->
                                val sc = result.rawValue ?: ""
                                if (sc.isNotBlank()) {
                                    val matched = products.find { it.barcode == sc || it.sku == sc }
                                    onBarcodeScanned(matched ?: Product(
                                        id = "temp",
                                        name = "Scanned Item (Not in Inventory)",
                                        sku = sc,
                                        category = "General",
                                        sellingPrice = 0.0,
                                        purchasePrice = 0.0,
                                        quantity = 1,
                                        unit = "pcs",
                                        barcode = sc
                                    ))
                                }
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(context, "Camera scanner failed / not configured: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)), // emerald-600
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.PhotoCamera, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Capture via Mobile Camera", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "VIRTUAL EMULATOR SIMULATOR",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("Simulates sweeping standard register laser scanner over physical barcodes. Tap a label to mock scan instantly:", fontSize = 11.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .background(Color.Black, RoundedCornerShape(12.dp))
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawLine(
                            color = Color.Red,
                            start = Offset(0f, size.height / 2),
                            end = Offset(size.width, size.height / 2),
                            strokeWidth = 2.dp.toPx()
                        )
                    }
                    Text("ACTIVE LASER SIMULATION PATTERN", color = Color.Red.copy(alpha = 0.8f), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text("SCAN TARGET LABELS:", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                
                LazyColumn(
                    modifier = Modifier.heightIn(max = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(products) { p ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onBarcodeScanned(p) },
                            colors = CardDefaults.cardColors(containerColor = LightGrayBg)
                        ) {
                            Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = p.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text(text = "Code: ${p.barcode} | Price: ${currencySymbol}${String.format("%.2f", p.sellingPrice)}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Color.DarkGray)
                                }
                                Badge(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                                    Text("UPC Label", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                             }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close Scanner")
            }
        }
    )
}

// Beautiful Committed Invoice Receipt Dialog with actions (PRINT Receipt, SHARE, Simulate Thermal Printing)
@Composable
fun CommittedInvoiceReceiptDialog(
    invoice: Invoice,
    currency: String,
    viewModel: POSViewModel,
    onDismiss: () -> Unit
) {
    val items = viewModel.getItemsOfInvoice(invoice)
    val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(invoice.date))
    val context = LocalContext.current

    // Document launcher for exporting professional PDF invoice using SAF
    val pdfSaveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            viewModel.generateAndSaveInvoicePdf(context, it, invoice, currency)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldActive)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Billing Completed!", color = EmeraldDark)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "SMART CASH MEMO SYSTEM", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Black)
                        Text(text = "Tax Invoice Receipt: offline-first", fontSize = 9.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        Divider(color = Color.Black, modifier = Modifier.padding(vertical = 4.dp))
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Invoice: ${invoice.invoiceId}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                            Text(text = dateStr, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                        }
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Customer: ${invoice.customerName}", fontSize = 10.sp, color = Color.Black)
                            Text(text = "Tel: ${invoice.customerMobile}", fontSize = 10.sp, color = Color.Black)
                        }

                        Divider(color = Color.Black, modifier = Modifier.padding(vertical = 4.dp))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Items list
                        for (item in items) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "${item.productName} (x${item.quantity})", fontSize = 11.sp, modifier = Modifier.weight(1f), color = Color.Black)
                                Text(
                                    text = "$currency${String.format("%.2f", item.totalPrice)}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = Color.Black
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = Color.Black, modifier = Modifier.padding(vertical = 4.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Subtotal", fontSize = 11.sp, color = Color.Black)
                            Text(text = "$currency${String.format("%.2f", invoice.subtotal)}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.Black)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "VAT Tax", fontSize = 11.sp, color = Color.Black)
                            Text(text = "+$currency${String.format("%.2f", invoice.taxAmount)}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.Black)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            val absoluteDisc = (invoice.subtotal * (invoice.discountPercentage / 100)) + invoice.discountAmount
                            Text(text = "Discounts total", fontSize = 11.sp, color = Color.Black)
                            Text(text = "-$currency${String.format("%.2f", absoluteDisc)}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.Black)
                        }

                        Divider(color = Color.Black, modifier = Modifier.padding(vertical = 4.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "GRAND TOTAL", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            Text(text = "$currency${String.format("%.2f", invoice.grandTotal)}", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color.Black)
                        }

                        val invoicePaid = invoice.paidAmount
                        val invoiceDue = (invoice.grandTotal - invoicePaid).coerceAtLeast(0.0)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Amount Paid", fontSize = 11.sp, color = Color.Black)
                            Text(text = "$currency${String.format("%.2f", invoicePaid)}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.Black)
                        }

                        if (invoiceDue > 0.0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Due Balance", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = OutOfStockRed)
                                Text(text = "$currency${String.format("%.2f", invoiceDue)}", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = OutOfStockRed)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // barcode simulator
                        StylizedBarcode(value = invoice.invoiceId.filter { it.isDigit() }.take(12), modifier = Modifier.fillMaxWidth())

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("--- Thank You, Save Green Environment ---", fontSize = 9.sp, color = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text("Select Checkout Action:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                // Actions row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    IconButtonWithText(
                        icon = Icons.Default.Share, 
                        label = "Share",
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "Bill from Smart POS invoice: ${invoice.invoiceId} committed for client: ${invoice.customerName}. Grand Total: $currency${String.format("%.2f", invoice.grandTotal)}")
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Receipt Link"))
                        }
                    )
                    IconButtonWithText(
                        icon = Icons.Default.LocalPrintshop, 
                        label = "Print Receipt",
                        onClick = {
                            Toast.makeText(context, "Bluetooth Thermal Print Command Issued to Printer!", Toast.LENGTH_LONG).show()
                        }
                    )
                    IconButtonWithText(
                        icon = Icons.Default.Download, 
                        label = "Save PDF",
                        onClick = {
                            val cleanInvoiceId = invoice.invoiceId.replace("[^a-zA-Z0-9]".toRegex(), "_")
                            pdfSaveLauncher.launch("Invoice_$cleanInvoiceId.pdf")
                        }
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark)) {
                Text("Dismiss Receipt & Clear")
            }
        }
    )
}

@Composable
fun IconButtonWithText(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onClick() }.padding(4.dp)) {
        Box(
            modifier = Modifier
                .background(EmeraldLight, CircleShape)
                .size(40.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = EmeraldDark, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}


// -----------------------------------------------------------------------------
// SCREEN 5: ADVANCED BUSINESS PERFORMANCE REPORTS
// -----------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: POSViewModel) {
    val invoicesList by viewModel.invoices.collectAsState()
    val expensesList by viewModel.expenses.collectAsState()
    val suppliersList by viewModel.suppliers.collectAsState()
    val purchaseOrdersList by viewModel.purchaseOrders.collectAsState()
    val shopsList by viewModel.shops.collectAsState()
    val productsList by viewModel.products.collectAsState()

    val stats by viewModel.getSalesStats().collectAsState(initial = Triple(0.0, 0.0, 0.0))
    val currencySymbol by viewModel.multiCurrencySymbol.collectAsState()
    
    val aiInsights by viewModel.aiInsightsState.collectAsState()
    val isAiLoading by viewModel.isAiLoadingState.collectAsState()

    val context = LocalContext.current

    val supplierTransactionsList by viewModel.supplierTransactions.collectAsState()

    var activeTab by remember { mutableStateOf(0) }
    var selectedSupplierForLedger by remember { mutableStateOf<Supplier?>(null) }
    val tabLabels = listOf("All Invoices", "AI Advisory Insights", "Profit & Loss (P&L)", "Operating Expenses", "Purchase Orders", "Suppliers CRM")

    var selectedInvoiceForDetail by remember { mutableStateOf<Invoice?>(null) }
    var expenseToDelete by remember { mutableStateOf<Expense?>(null) }
    var purchaseOrderToDelete by remember { mutableStateOf<PurchaseOrder?>(null) }
    var supplierToDelete by remember { mutableStateOf<Supplier?>(null) }
    var showAddSupplierDialog by remember { mutableStateOf(false) }

    if (selectedInvoiceForDetail != null) {
        CommittedInvoiceReceiptDialog(
            invoice = selectedInvoiceForDetail!!,
            currency = currencySymbol,
            viewModel = viewModel,
            onDismiss = { selectedInvoiceForDetail = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "Enterprise Resource Center", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(text = "Consolidated ledger auditing and predictive analysis", fontSize = 11.sp, color = Color.Gray)
            }
            Box(
                modifier = Modifier
                    .background(EmeraldDark.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                    .border(1.dp, EmeraldDark.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                val activeShopCode by viewModel.selectedShopId.collectAsState()
                Text(
                    text = "BRANCH: ${activeShopCode.uppercase()}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = EmeraldDark
                )
            }
        }

        // Horizontal Scrollable Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            tabLabels.forEachIndexed { index, label ->
                val isSelected = activeTab == index
                FilterChip(
                    selected = isSelected,
                    onClick = { activeTab = index },
                    label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldDark,
                        selectedLabelColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        // Tab Content Renderer
        when (activeTab) {
            0 -> {
                // TAB 0: ALL INVOICES
                var invoiceQuery by remember { mutableStateOf("") }
                val filteredInvoices = if (invoiceQuery.isBlank()) {
                    invoicesList
                } else {
                    invoicesList.filter { 
                        it.invoiceId.contains(invoiceQuery, ignoreCase = true) ||
                        it.customerName.contains(invoiceQuery, ignoreCase = true) ||
                        it.customerMobile.contains(invoiceQuery, ignoreCase = true)
                    }
                }
                
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = invoiceQuery,
                        onValueChange = { invoiceQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search invoices by ID, Client, or Phone...") },
                        leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    
                    if (filteredInvoices.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No invoices matched your search.", color = Color.Gray, fontStyle = FontStyle.Italic)
                        }
                    } else {
                        filteredInvoices.forEach { invoice ->
                            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(invoice.date))
                            val invoicePaid = invoice.paidAmount
                            val invoiceDue = (invoice.grandTotal - invoicePaid).coerceAtLeast(0.0)
                            
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedInvoiceForDetail = invoice },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = invoice.invoiceId, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                                        Text(text = "Client: ${invoice.customerName}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                        Text(text = "Date: $dateStr", fontSize = 11.sp, color = Color.Gray)
                                    }
                                    
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(text = "$currencySymbol${String.format("%.2f", invoice.grandTotal)}", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = DarkBlue)
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(text = "Paid: $currencySymbol${String.format("%.2f", invoicePaid)}", fontSize = 10.sp, color = EmeraldDark)
                                            if (invoiceDue > 0.0) {
                                                Text(text = "Due: $currencySymbol${String.format("%.2f", invoiceDue)}", fontSize = 10.sp, color = OutOfStockRed, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        val statusText = if (invoiceDue <= 0.0) "FULLY PAID" else if (invoicePaid > 0.0) "PARTIAL" else "UNPAID"
                                        val statusColor = if (invoiceDue <= 0.0) EmeraldDark else if (invoicePaid > 0.0) Color(0xFFF59E0B) else OutOfStockRed
                                        Surface(
                                            color = statusColor.copy(alpha = 0.1f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = statusText,
                                                color = statusColor,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // TAB 1: AI EXECUTIVE INTELLIGENCE FORECASTING
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)), // deep indigo
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color(0xFF4338CA))
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(Color(0xFF4F46E5), CircleShape),
                                    contentAlignment = Alignment.Center
                                   ) {
                                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                Column {
                                    Text("Gemini 3.5 Predictive BI Forecast", fontWeight = FontWeight.ExtraBold, color = Color.White, style = MaterialTheme.typography.titleMedium)
                                    Text("Neural risk diagnostics & corporate planning recommendations ", fontSize = 10.sp, color = Color(0xFFC7D2FE))
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            if (isAiLoading) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                    Text("Recalculating cash flows...", color = Color(0xFFC7D2FE), fontSize = 11.sp, fontStyle = FontStyle.Italic)
                                }
                            } else {
                                Text(
                                    text = aiInsights,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFFE0E7FF),
                                    lineHeight = 20.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = { viewModel.fetchPredictiveInsights() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(imageVector = Icons.Default.Troubleshoot, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Text("Synthesise Corporate Advisory Report", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Performance visualization card
                    BeautifulSalesGraph(currency = currencySymbol)
                }
            }

            2 -> {
                // TAB 2: PROFIT & LOSS LEDGER (MANDATORY REQUIREMENT 4)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    val grossRevenue = invoicesList.sumOf { it.grandTotal }
                    val totalVatAccumulated = invoicesList.sumOf { it.taxAmount }
                    val grossSubtotal = invoicesList.sumOf { it.subtotal }
                    val totalOperationalExpenditures = expensesList.sumOf { it.amount }
                    
                    // Simple COGS heuristic estimation (product cost average factor 70% or look up if available)
                    val cogsCalculated = invoicesList.sumOf { it.subtotal * 0.70 }
                    val netOperatingProfit = grossRevenue - cogsCalculated - totalOperationalExpenditures

                    // Summary Bento Profit representation
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (netOperatingProfit >= 0.0) Color(0xFFE6F4EA) else Color(0xFFFCE8E6)
                        ),
                        border = BorderStroke(1.dp, if (netOperatingProfit >= 0.0) Color(0xFF137333).copy(alpha = 0.2f) else Color(0xFFC5221F).copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                "ESTIMATED NET MARGINS (YTD)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (netOperatingProfit >= 0.0) Color(0xFF137333) else Color(0xFFC5221F),
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "$currencySymbol${String.format("%.2f", netOperatingProfit)}",
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (netOperatingProfit >= 0.0) Color(0xFF137333) else Color(0xFFC5221F)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Based on sales revenue deducting cost factor and operating expenses",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    // Bookkeeping Cards
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Corporate Bookkeeping Statement", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("A. Gross Client Receipts:", fontSize = 13.sp)
                                Text("$currencySymbol${String.format("%.2f", grossRevenue)}", fontWeight = FontWeight.Bold, color = EmeraldDark)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("B. Est. Cost of Goods (COGS 70%):", fontSize = 13.sp)
                                Text("- $currencySymbol${String.format("%.2f", cogsCalculated)}", color = Color.Gray)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("C. Operating Overhead Expenditures:", fontSize = 13.sp)
                                Text("- $currencySymbol${String.format("%.2f", totalOperationalExpenditures)}", color = Color.Gray)
                            }

                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Net Corporate Profit Calculation (A - B - C):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("$currencySymbol${String.format("%.2f", netOperatingProfit)}", fontWeight = FontWeight.ExtraBold, color = if (netOperatingProfit >= 0.0) EmeraldDark else Color.Red)
                            }
                        }
                    }

                    // Tax Accumulated Cards (MANDATORY REQUIREMENT 2)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Cumulative Tax & Fiscal Breakdown", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Box(
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    val isTaxOn by viewModel.isTaxEnabled.collectAsState()
                                    Text(if (isTaxOn) "TAX STATE ACTIVE" else "DISABLED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Tax Bracket Standard Rate:", fontSize = 13.sp)
                                val taxRatePct by viewModel.defaultTaxPercentage.collectAsState()
                                Text("$taxRatePct%", fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Consolidated Invoice Subtotal (Exclusive):", fontSize = 13.sp)
                                Text("$currencySymbol${String.format("%.2f", grossSubtotal)}")
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Aggregated VAT/GST Collected (Inclusive):", fontSize = 13.sp)
                                Text("$currencySymbol${String.format("%.2f", totalVatAccumulated)}", fontWeight = FontWeight.Bold, color = EmeraldDark)
                            }
                        }
                    }
                }
            }

            3 -> {
                // TAB 3: OPERATING EXPENSES (MANDATORY REQUIREMENT 3)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    var expenseTitle by remember { mutableStateOf("") }
                    var expenseAmt by remember { mutableStateOf("") }
                    var expenseCat by remember { mutableStateOf("Rent") }
                    var expenseShopSelection by remember { mutableStateOf("default_shop") }
                    val expenseCategories = listOf("Rent", "Electricity", "Salaries", "Internet", "Taxes", "Maintenance", "Misc")

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Quick Addition Form
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Log New Business Expense Entry", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        
                                        OutlinedTextField(
                                            value = expenseTitle,
                                            onValueChange = { expenseTitle = it },
                                            label = { Text("Expense Title / Invoice Reference") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )

                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            OutlinedTextField(
                                                value = expenseAmt,
                                                onValueChange = { expenseAmt = it },
                                                label = { Text("Overhead Amount") },
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                modifier = Modifier.weight(1.2f)
                                            )

                                            // Category Spinner Selection
                                            var expandedCatMenu by remember { mutableStateOf(false) }
                                            Box(modifier = Modifier.weight(1f)) {
                                                Button(
                                                    onClick = { expandedCatMenu = true },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                                                    modifier = Modifier.fillMaxWidth(),
                                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                                ) {
                                                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                        Text(expenseCat, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                                DropdownMenu(
                                                    expanded = expandedCatMenu,
                                                    onDismissRequest = { expandedCatMenu = false }
                                                ) {
                                                    expenseCategories.forEach { category ->
                                                        DropdownMenuItem(
                                                            text = { Text(category) },
                                                            onClick = {
                                                                expenseCat = category
                                                                expandedCatMenu = false
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Text("Branch:", fontWeight = FontWeight.Medium, fontSize = 12.sp)
                                            var expandedShopMenu by remember { mutableStateOf(false) }
                                            Box(modifier = Modifier.weight(1f)) {
                                                Button(
                                                    onClick = { expandedShopMenu = true },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                        Text(expenseShopSelection, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                                DropdownMenu(
                                                    expanded = expandedShopMenu,
                                                    onDismissRequest = { expandedShopMenu = false }
                                                ) {
                                                    DropdownMenuItem(
                                                        text = { Text("HQ Setup") },
                                                        onClick = {
                                                            expenseShopSelection = "HQ"
                                                            expandedShopMenu = false
                                                        }
                                                    )
                                                    shopsList.forEach { s ->
                                                        DropdownMenuItem(
                                                            text = { Text(s.name) },
                                                            onClick = {
                                                                expenseShopSelection = s.id
                                                                expandedShopMenu = false
                                                            }
                                                        )
                                                    }
                                                }
                                            }

                                            Button(
                                                onClick = {
                                                    val amt = expenseAmt.toDoubleOrNull()
                                                    if (expenseTitle.isBlank() || amt == null || amt <= 0.0) {
                                                        Toast.makeText(context, "Please configure valid entries", Toast.LENGTH_SHORT).show()
                                                        return@Button
                                                    }
                                                    viewModel.saveExpense(
                                                        id = "",
                                                        title = expenseTitle,
                                                        amount = amt,
                                                        category = expenseCat,
                                                        date = System.currentTimeMillis(),
                                                        notes = "Operating cost",
                                                        receiptImage = "",
                                                        shopId = expenseShopSelection,
                                                        onCompleted = {
                                                            expenseTitle = ""
                                                            expenseAmt = ""
                                                            Toast.makeText(context, "Overhead logged into database Ledger!", Toast.LENGTH_SHORT).show()
                                                        }
                                                    )
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Text("Log Cost", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            // Overhead entries log
                            item {
                                Text("Expense Entries Log (${expensesList.size}):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            }

                            if (expensesList.isEmpty()) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(24.dp), contentAlignment = Alignment.Center
                                    ) {
                                        Text("No operational overhead items recorded.", color = Color.Gray, fontStyle = FontStyle.Italic, fontSize = 12.sp)
                                    }
                                }
                            }

                            items(expensesList) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                            ) {
                                                Text(item.category.uppercase(), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                            }
                                            Text("Branch: ${item.shopId.uppercase()}", fontSize = 10.sp, color = Color.Gray)
                                            val df = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                                            Text(df.format(Date(item.date)), fontSize = 10.sp, color = Color.Gray)
                                        }
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("$currencySymbol${String.format("%.2f", item.amount)}", fontWeight = FontWeight.Bold, color = Color.Red, fontSize = 13.sp)
                                        IconButton(
                                            onClick = {
                                                expenseToDelete = item
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }

                            item { Spacer(modifier = Modifier.height(100.dp)) }
                        }
                    }
                }
            }

            4 -> {
                // TAB 4: PURCHASE ORDER REQUISITION SYSTEM (MANDATORY REQUIREMENT 6)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    var poNumberInput by remember { mutableStateOf("") }
                    var poQuantityInput by remember { mutableStateOf("20") }
                    var poUnitCostInput by remember { mutableStateOf("5.00") }
                    
                    var selectedPOProduct by remember { mutableStateOf<Product?>(null) }
                    var selectedPOSupplier by remember { mutableStateOf<Supplier?>(null) }
                    var selectedPOStatus by remember { mutableStateOf("Pending") }

                    val poStatuses = listOf("Draft", "Pending", "Approved", "Received", "Cancelled")

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Issue Requisition Form
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Issue Supply Stock Purchase Order", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            OutlinedTextField(
                                                value = poNumberInput,
                                                onValueChange = { poNumberInput = it },
                                                label = { Text("PO Number Reference") },
                                                placeholder = { Text("E.g. PO-8902") },
                                                singleLine = true,
                                                modifier = Modifier.weight(1f)
                                            )

                                            // Choose PO status
                                            var expandedStatusMenu by remember { mutableStateOf(false) }
                                            Box(modifier = Modifier.weight(1f)) {
                                                Button(
                                                    onClick = { expandedStatusMenu = true },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                        Text("Status: $selectedPOStatus", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                                DropdownMenu(
                                                    expanded = expandedStatusMenu,
                                                    onDismissRequest = { expandedStatusMenu = false }
                                                ) {
                                                    poStatuses.forEach { status ->
                                                        DropdownMenuItem(
                                                            text = { Text(status) },
                                                            onClick = {
                                                                selectedPOStatus = status
                                                                expandedStatusMenu = false
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        // Select Supplier Dropdown
                                        var expandedSuppMenu by remember { mutableStateOf(false) }
                                        Box(modifier = Modifier.fillMaxWidth()) {
                                            Button(
                                                onClick = { expandedSuppMenu = true },
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(text = if (selectedPOSupplier != null) "Supplier: ${selectedPOSupplier?.name} (${selectedPOSupplier?.companyName})" else "Associate Vendor Supplier", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                            DropdownMenu(
                                                expanded = expandedSuppMenu,
                                                onDismissRequest = { expandedSuppMenu = false }
                                            ) {
                                                suppliersList.forEach { supp ->
                                                    DropdownMenuItem(
                                                        text = { Text("${supp.name} [${supp.companyName}]") },
                                                        onClick = {
                                                            selectedPOSupplier = supp
                                                            expandedSuppMenu = false
                                                        }
                                                    )
                                                }
                                            }
                                        }

                                        // Select Product to Replenish
                                        var expandedProdMenu by remember { mutableStateOf(false) }
                                        Box(modifier = Modifier.fillMaxWidth()) {
                                            Button(
                                                onClick = { expandedProdMenu = true },
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer, contentColor = MaterialTheme.colorScheme.onTertiaryContainer),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(text = if (selectedPOProduct != null) "Replenish: ${selectedPOProduct?.name} (Sku: ${selectedPOProduct?.sku})" else "Choose Product to Replenish Map", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                            DropdownMenu(
                                                expanded = expandedProdMenu,
                                                onDismissRequest = { expandedProdMenu = false }
                                            ) {
                                                productsList.forEach { p ->
                                                    DropdownMenuItem(
                                                        text = { Text("${p.name} [SKU: ${p.sku}] - Stock: ${p.quantity}") },
                                                        onClick = {
                                                            selectedPOProduct = p
                                                            poUnitCostInput = String.format("%.2f", p.purchasePrice)
                                                            expandedProdMenu = false
                                                        }
                                                    )
                                                }
                                            }
                                        }

                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            OutlinedTextField(
                                                value = poQuantityInput,
                                                onValueChange = { poQuantityInput = it },
                                                label = { Text("Order Quantity") },
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                modifier = Modifier.weight(1f)
                                            )
                                            OutlinedTextField(
                                                value = poUnitCostInput,
                                                onValueChange = { poUnitCostInput = it },
                                                label = { Text("Supply Unit Cost") },
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                val supp = selectedPOSupplier
                                                val prod = selectedPOProduct
                                                val qty = poQuantityInput.toIntOrNull()
                                                val cost = poUnitCostInput.toDoubleOrNull()
                                                if (supp == null || prod == null || qty == null || cost == null || qty <= 0) {
                                                    Toast.makeText(context, "Please wire Supplier, Product, Qty and Cost completely!", Toast.LENGTH_LONG).show()
                                                    return@Button
                                                }
                                                val poItemsList = listOf(
                                                    PurchaseOrderItem(
                                                        productId = prod.id,
                                                        productName = prod.name,
                                                        sku = prod.sku,
                                                        quantity = qty,
                                                        costPrice = cost,
                                                        unit = prod.unit,
                                                        totalPrice = qty * cost
                                                    )
                                                )
                                                viewModel.createPurchaseOrder(
                                                    poNumber = poNumberInput,
                                                    supplier = supp,
                                                    items = poItemsList,
                                                    totalCost = qty * cost,
                                                    status = selectedPOStatus,
                                                    onCompleted = {
                                                        poNumberInput = ""
                                                        Toast.makeText(context, "Created Requisition purchase record!", Toast.LENGTH_SHORT).show()
                                                    }
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("Issue Purchase Order", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // PO List Ledger log
                            item {
                                Text("Dispatched Purchase Orders (${purchaseOrdersList.size}):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            }

                            if (purchaseOrdersList.isEmpty()) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(24.dp), contentAlignment = Alignment.Center
                                    ) {
                                        Text("No system Purchase Orders configured.", color = Color.Gray, fontStyle = FontStyle.Italic, fontSize = 12.sp)
                                    }
                                }
                            }

                            items(purchaseOrdersList) { po ->
                                val poItems = viewModel.deserializePurchaseOrderItems(po.itemsJson)
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Text(po.poNumber, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = EmeraldDark)
                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        when (po.status) {
                                                            "Received" -> Color(0xFFD1FAE5)
                                                            "Cancelled" -> Color(0xFFFEE2E2)
                                                            else -> Color(0xFFFFECE0)
                                                        },
                                                        RoundedCornerShape(8.dp)
                                                    )
                                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = po.status.uppercase(),
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = when (po.status) {
                                                        "Received" -> Color(0xFF047857)
                                                        "Cancelled" -> Color(0xFFEF4444)
                                                        else -> Color(0xFFEA580C)
                                                    }
                                                )
                                            }
                                        }

                                        Text("Supplier Link: ${po.supplierName}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        poItems.forEach { subItem ->
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("• ${subItem.productName} (x${subItem.quantity})", fontSize = 11.sp)
                                                Text("$currencySymbol${String.format("%.2f", subItem.totalPrice)}", fontSize = 11.sp, color = Color.Gray)
                                            }
                                        }

                                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Total Cost: $currencySymbol${String.format("%.2f", po.totalCost)}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                if (po.status != "Received" && po.status != "Cancelled") {
                                                    Button(
                                                        onClick = {
                                                            // Trigger Receiving update logic to credit stock!
                                                            viewModel.updatePurchaseOrderStatus(po, "Received", onCompleted = {
                                                                Toast.makeText(context, "Marked RECEIVED! Stocks upgraded automatically.", Toast.LENGTH_SHORT).show()
                                                            })
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text("Receive Stock Plan", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                                IconButton(
                                                    onClick = { purchaseOrderToDelete = po },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            item { Spacer(modifier = Modifier.height(100.dp)) }
                        }
                    }
                }
            }

            5 -> {
                // TAB 5: SUPPLIERS CONTACTS DATABASE (MANDATORY REQUIREMENT 5)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Supply Partners Directory", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("Manage vendor relationships & dual-ledger accounting", fontSize = 11.sp, color = Color.Gray)
                        }
                        IconButton(
                            onClick = { showAddSupplierDialog = true },
                            modifier = Modifier
                                .background(EmeraldDark, RoundedCornerShape(12.dp))
                                .size(40.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Supplier", tint = Color.White)
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Supplier listing
                            item {
                                Text("Registered Supply Partners (${suppliersList.size}):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            }

                            if (suppliersList.isEmpty()) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(24.dp), contentAlignment = Alignment.Center
                                    ) {
                                        Text("No associated supply vendors found.", color = Color.Gray, fontStyle = FontStyle.Italic, fontSize = 12.sp)
                                    }
                                }
                            }

                            items(suppliersList) { s ->
                                val sTx = supplierTransactionsList.filter { it.supplierId == s.id }
                                val buys = sTx.filter { it.type == "BUY" }.sumOf { it.amount }
                                val paid = sTx.filter { it.type == "PAYMENT" }.sumOf { it.amount }
                                val currentDue = (buys - paid).coerceAtLeast(0.0)

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                        .clickable { selectedSupplierForLedger = s }
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${s.name} [${s.companyName}]", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("Tel: ${s.mobile}  •  Email: ${s.email}", fontSize = 11.sp, color = Color.Gray)
                                        Text("Tax Reg: ${s.taxNumber}  •  ${s.address}", fontSize = 10.sp, color = Color.Gray)

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Column {
                                                Text("Total Buys", fontSize = 9.sp, color = Color.Gray)
                                                Text("$currencySymbol${String.format("%.2f", buys)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DarkBlue)
                                            }
                                            Column {
                                                Text("Total Paid", fontSize = 9.sp, color = Color.Gray)
                                                Text("$currencySymbol${String.format("%.2f", paid)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                                            }
                                            Column {
                                                Text("Outstanding Due", fontSize = 9.sp, color = Color.Gray)
                                                Text("$currencySymbol${String.format("%.2f", currentDue)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (currentDue > 0.0) OutOfStockRed else Color.Gray)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Click to view Ledger Book & Record Payments", fontSize = 9.sp, color = Color.Gray, fontStyle = FontStyle.Italic)

                                        // Display supplied products
                                        val suppliedProducts = productsList.filter { p ->
                                            p.supplierIds.split(",").map { it.trim() }.contains(s.id)
                                        }
                                        if (suppliedProducts.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "Supplied Products:",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            FlowRow(
                                                modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                suppliedProducts.forEach { p ->
                                                    SuggestionChip(
                                                        onClick = {},
                                                        label = {
                                                            Text(
                                                                text = "${p.name} (${p.quantity} ${p.unit})",
                                                                fontSize = 9.sp
                                                            )
                                                        },
                                                        modifier = Modifier.height(24.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    IconButton(
                                        onClick = {
                                            supplierToDelete = s
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            item { Spacer(modifier = Modifier.height(100.dp)) }
                        }
                    }

                    if (selectedSupplierForLedger != null) {
                        SupplierLedgerDetailsDialog(
                            supplier = selectedSupplierForLedger!!,
                            viewModel = viewModel,
                            currencySymbol = currencySymbol,
                            onDismiss = { selectedSupplierForLedger = null }
                        )
                    }
                }
            }
        }
    }

    if (expenseToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Expense Record",
            message = "Are you sure you want to permanently delete the expense entry '${expenseToDelete!!.title}' of $currencySymbol${String.format("%.2f", expenseToDelete!!.amount)}?",
            onConfirm = {
                viewModel.deleteExpense(expenseToDelete!!)
                Toast.makeText(context, "Deleted Expense: ${expenseToDelete!!.title}", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { expenseToDelete = null }
        )
    }

    if (purchaseOrderToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Purchase Order",
            message = "Are you sure you want to permanently delete purchase order '${purchaseOrderToDelete!!.poNumber}' of amount $currencySymbol${String.format("%.2f", purchaseOrderToDelete!!.totalCost)}?",
            onConfirm = { viewModel.deletePurchaseOrder(purchaseOrderToDelete!!) },
            onDismiss = { purchaseOrderToDelete = null }
        )
    }

    if (supplierToDelete != null) {
        DeleteConfirmationDialog(
            title = "Remove Supplier Profile",
            message = "Are you sure you want to delete supplier '${supplierToDelete!!.name}' [${supplierToDelete!!.companyName}]? This will remove their registration, dual-ledger entries, and pending payments from the database.",
            onConfirm = {
                viewModel.deleteSupplier(supplierToDelete!!)
                Toast.makeText(context, "Removed supplier: ${supplierToDelete!!.name}", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { supplierToDelete = null }
        )
    }

    if (showAddSupplierDialog) {
        SupplierFormDialog(
            supplier = null,
            onDismiss = { showAddSupplierDialog = false },
            onSave = { name, company, mobile, email, address, taxNumber, notes ->
                viewModel.saveSupplier(
                    id = "",
                    name = name,
                    companyName = company,
                    mobile = mobile,
                    email = email,
                    address = address,
                    taxNumber = taxNumber,
                    notes = notes,
                    onCompleted = {
                        showAddSupplierDialog = false
                        Toast.makeText(context, "Supplier registered successfully!", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        )
    }
}



// -----------------------------------------------------------------------------
// SCREEN 6: SYSTEM SETTINGS, BACKUP, RESTORE & DATA SEEDING
// -----------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: POSViewModel) {
    val context = LocalContext.current
    val productsList by viewModel.products.collectAsState()
    val customersList by viewModel.customers.collectAsState()
    val invoicesList by viewModel.invoices.collectAsState()
    val shopsList by viewModel.shops.collectAsState()
    val expensesList by viewModel.expenses.collectAsState()

    var currencyInput by remember { mutableStateOf(viewModel.multiCurrencySymbol.value) }
    var taxInput by remember { mutableStateOf(viewModel.defaultTaxPercentage.value.toString()) }
    var isTaxActive by remember { mutableStateOf(viewModel.isTaxEnabled.value) }

    val currencyOptions = remember {
        listOf(
            Pair("USA – US Dollar ($)", "$"),
            Pair("UK – Pound Sterling (£)", "£"),
            Pair("Europe (EU) – Euro (€)", "€"),
            Pair("Japan – Yen (¥)", "¥"),
            Pair("Bangladesh – Taka (৳)", "৳"),
            Pair("India – Rupee (₹)", "₹"),
            Pair("China – Yuan (¥)", "¥"),
            Pair("Australia – Australian Dollar (A$)", "A$"),
            Pair("Canada – Canadian Dollar (C$)", "C$"),
            Pair("Brazil – Real (R$)", "R$"),
            Pair("South Africa – Rand (R)", "R"),
            Pair("Russia – Ruble (₽)", "₽"),
            Pair("Mexico – Peso ($)", "$"),
            Pair("South Korea – Won (₩)", "₩"),
            Pair("Turkey – Lira (₺)", "₺"),
            Pair("Switzerland – Swiss Franc (CHF)", "CHF"),
            Pair("Custom / Own Currency", "")
        )
    }
    var showCurrencyDropdown by remember { mutableStateOf(false) }
    var selectedPresetLabel by remember { mutableStateOf("") }

    LaunchedEffect(currencyInput) {
        val matchingPreset = currencyOptions.firstOrNull { it.second == currencyInput && it.second.isNotEmpty() }
        selectedPresetLabel = matchingPreset?.first ?: "Custom / Own Currency"
    }

    // Multi-Shop Branch Add Form State
    var shopNameInput by remember { mutableStateOf("") }
    var shopAddressInput by remember { mutableStateOf("") }
    var shopMobileInput by remember { mutableStateOf("") }

    // Active staff dropdown state
    var selectedRole by remember { mutableStateOf(viewModel.currentUserRole.value) }
    val rolesList = listOf("Super Admin", "Shop Owner", "Manager", "Cashier", "Inventory Staff", "Accountant")

    var mockLoadedText by remember { mutableStateOf("") }
    var autoBackupChecked by remember { mutableStateOf(true) }
    var shopToDelete by remember { mutableStateOf<Shop?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "Enterprise POS Configurations", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        // 1. ACTIVE STAFF ACCOUNT & SECURITY SIMULATOR (MANDATORY REQUIREMENT 12)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Staff Security & Role Switching", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("Simulate user logs and live action authorization", fontSize = 11.sp, color = Color.Gray)
                    }
                    Box(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "SECURITY ENFORCED",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Selected Profile Account:", modifier = Modifier.weight(1.2f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    
                    var expandedRoleMenu by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.weight(2f)) {
                        Button(
                            onClick = { expandedRoleMenu = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedRole, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }
                        DropdownMenu(
                            expanded = expandedRoleMenu,
                            onDismissRequest = { expandedRoleMenu = false }
                        ) {
                            rolesList.forEach { role ->
                                DropdownMenuItem(
                                    text = { Text(role, fontWeight = FontWeight.Medium) },
                                    onClick = {
                                        selectedRole = role
                                        viewModel.currentUserRole.value = role
                                        expandedRoleMenu = false
                                        Toast.makeText(context, "Logged in as $role", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    }
                }

                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                // Render dynamic permission matrix summary
                Text("Role Capabilities Matrix:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                
                val keyCapabilities = listOf(
                    "Billing" to "Direct Customer checkout",
                    "Add Products" to "Create items, tags, SKUs",
                    "Manage Expenses" to "Add operating expenses",
                    "Purchase Orders" to "Configure supply requisitions",
                    "Manage Staff Security" to "Modify user authorization levels"
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    keyCapabilities.forEach { (cap, desc) ->
                        val behaves = viewModel.hasPermission(cap)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(cap, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                Text(desc, fontSize = 10.sp, color = Color.Gray)
                            }
                            Box(
                                modifier = Modifier
                                    .background(if (behaves) Color(0xFFD1FAE5) else Color(0xFFFEE2E2), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (behaves) "GRANTED" else "RESTRICTED",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (behaves) Color(0xFF047857) else Color(0xFFEF4444)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. MULTI-BRANCH OFFICE MANAGER (MANDATORY REQUIREMENT 1)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Multi-Branch & Shop Registry", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Deploy and register unlimited sales branches dynamically under your consolidated owner ledger.", fontSize = 11.sp, color = Color.Gray)

                // Select branch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Select Branch Context:", modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    
                    val activeShop by viewModel.selectedShopId.collectAsState()
                    var expandedShopMenu by remember { mutableStateOf(false) }
                    
                    Box(modifier = Modifier.weight(2f)) {
                        Button(
                            onClick = { expandedShopMenu = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(if (activeShop == "All Branches") "All Branches" else "Branch: $activeShop", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }
                        DropdownMenu(
                            expanded = expandedShopMenu,
                            onDismissRequest = { expandedShopMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Branches (Unified)", fontWeight = FontWeight.Bold) },
                                onClick = {
                                    viewModel.selectedShopId.value = "All Branches"
                                    expandedShopMenu = false
                                }
                            )
                            shopsList.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s.name) },
                                    onClick = {
                                        viewModel.selectedShopId.value = s.id
                                        expandedShopMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                // Registered branches list
                Text("Registered Branches (${shopsList.size}):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    shopsList.forEach { s ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(s.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("ID: ${s.id}  •  ${s.address}", fontSize = 11.sp, color = Color.Gray)
                                Text("Tel: ${s.mobile}", fontSize = 11.sp, color = Color.Gray)
                            }
                            if (s.id != "default_shop" && s.id != "HQ") {
                                IconButton(
                                    onClick = {
                                        shopToDelete = s
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Shop", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // New Branch Form
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.02f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Add New Business Branch:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        OutlinedTextField(
                            value = shopNameInput,
                            onValueChange = { shopNameInput = it },
                            label = { Text("Branch Identifier / Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = shopAddressInput,
                            onValueChange = { shopAddressInput = it },
                            label = { Text("Address") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = shopMobileInput,
                            onValueChange = { shopMobileInput = it },
                            label = { Text("Telephone Mobile Link") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                if (shopNameInput.isBlank()) {
                                    Toast.makeText(context, "Enter branch name", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                viewModel.saveShop(
                                    id = shopNameInput.replace("\\s+".toRegex(), "_").lowercase(),
                                    name = shopNameInput,
                                    address = shopAddressInput,
                                    mobile = shopMobileInput,
                                    onCompleted = {
                                        shopNameInput = ""
                                        shopAddressInput = ""
                                        shopMobileInput = ""
                                        Toast.makeText(context, "Branch created successfully!", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Provision Branch", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 3. TAX & FISCAL POLICY MANAGER (MANDATORY REQUIREMENT 2)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("GST / VAT / Tax Management Panel", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Enable or configure corporate tax brackets automatically breakdown for all issued receipt transactions.", fontSize = 11.sp, color = Color.Gray)
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Invoice Tax Calculation Enabled", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Calculate cumulative taxes at standard rate", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(
                        checked = isTaxActive,
                        onCheckedChange = {
                            isTaxActive = it
                            viewModel.isTaxEnabled.value = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = EmeraldActive)
                    )
                }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1.2f)) {
                            OutlinedTextField(
                                value = selectedPresetLabel,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Select System Currency") },
                                trailingIcon = {
                                    IconButton(onClick = { showCurrencyDropdown = !showCurrencyDropdown }) {
                                        Icon(
                                            imageVector = if (showCurrencyDropdown) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                            contentDescription = "Toggle Currency List"
                                        )
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                leadingIcon = { Icon(imageVector = Icons.Default.Language, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            )
                            
                            DropdownMenu(
                                expanded = showCurrencyDropdown,
                                onDismissRequest = { showCurrencyDropdown = false },
                                modifier = Modifier.fillMaxWidth(0.9f).heightIn(max = 280.dp)
                            ) {
                                currencyOptions.forEach { preset ->
                                    DropdownMenuItem(
                                        text = { Text(preset.first, fontSize = 13.sp) },
                                        onClick = {
                                            selectedPresetLabel = preset.first
                                            showCurrencyDropdown = false
                                            if (preset.second.isNotEmpty()) {
                                                currencyInput = preset.second
                                                viewModel.multiCurrencySymbol.value = preset.second
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = currencyInput,
                            onValueChange = {
                                currencyInput = it
                                viewModel.multiCurrencySymbol.value = it
                                val matchingPreset = currencyOptions.firstOrNull { p -> p.second == it && p.second.isNotEmpty() }
                                selectedPresetLabel = matchingPreset?.first ?: "Custom / Own Currency"
                            },
                            label = { Text("Symbol / Custom") },
                            singleLine = true,
                            modifier = Modifier.weight(0.8f),
                            leadingIcon = { Icon(imageVector = Icons.Default.CurrencyExchange, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                    }

                    OutlinedTextField(
                        value = taxInput,
                        onValueChange = {
                            taxInput = it
                            it.toDoubleOrNull()?.let { d -> viewModel.defaultTaxPercentage.value = d }
                        },
                        label = { Text("Standard Tax Rate (%)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        leadingIcon = { Icon(imageVector = Icons.Default.Percent, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }
            }
        }

        // 4. BACKUP / EXPORT REGISTRY
        GoogleDriveBackupSection(viewModel = viewModel)
        LocalBackupSection(viewModel = viewModel)

        // 5. DIAGNOSTIC SIMULATION POOL
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Simulation Seeder", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = EmeraldDark)
                Text(
                    text = "Launches default mock inventory packages (Tea, Sunflower Oil, Sugar), active invoices, and CRM profiles to try POS flow.",
                    fontSize = 11.sp,
                    color = Color.DarkGray
                )

                Button(
                    onClick = {
                        viewModel.seedSampleDataIfEmpty()
                        mockLoadedText = "Loaded sample metrics! Navigate to Register/Inventory."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Seed POS Default Mock Datasets", fontWeight = FontWeight.Bold)
                }

                if (mockLoadedText.isNotBlank()) {
                    Text(text = mockLoadedText, color = EmeraldDark, fontSize = 12.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        }

        // Database overview diagnostics
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = LightGrayBg)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("System Diagnostics Logs", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Product tables contains: ${productsList.size} rows", fontSize = 11.sp)
                Text("Customer databases: ${customersList.size} records", fontSize = 11.sp)
                Text("Invoices committed: ${invoicesList.size} records", fontSize = 11.sp)
                Text("Provisioned Shops: ${shopsList.size} records", fontSize = 11.sp)
                Text("Business Operational Expenses: ${expensesList.size} entries", fontSize = 11.sp)
                Text("SQLite State: Connected & Synced offline-first ✅", fontSize = 11.sp, color = EmeraldDark, fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(modifier = Modifier.height(100.dp))
    }

    if (shopToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Shop/Branch",
            message = "Are you sure you want to permanently delete branch '${shopToDelete!!.name}'? This action cannot be undone.",
            onConfirm = {
                viewModel.deleteShop(shopToDelete!!)
                Toast.makeText(context, "Deleted branch: ${shopToDelete!!.name}", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { shopToDelete = null }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoogleDriveBackupSection(viewModel: POSViewModel) {
    val context = LocalContext.current
    val googleEmail by viewModel.googleDriveEmail.collectAsState()
    val googleName by viewModel.googleDriveName.collectAsState()
    val isAutoBackEnabled by viewModel.isAutoBackupOn.collectAsState()
    val autoInterval by viewModel.autoBackupInterval.collectAsState()
    val isEncrypted by viewModel.isBackupEncrypted.collectAsState()
    val encryptionPassword by viewModel.backupEncPassword.collectAsState()
    val backupList by viewModel.googleDriveBackups.collectAsState()
    val isRunning by viewModel.isBackupRunning.collectAsState()
    val progressStep by viewModel.backupProgress.collectAsState()

    val customClientId by viewModel.customClientId.collectAsState()
    val customClientSecret by viewModel.customClientSecret.collectAsState()

    var showGoogleAuthDialog by remember { mutableStateOf(false) }
    var inputEmail by remember { mutableStateOf("ilovetryagain@gmail.com") }
    var inputName by remember { mutableStateOf("Enterprise Administrator") }

    var inputClientId by remember { mutableStateOf("") }
    var inputClientSecret by remember { mutableStateOf("") }

    LaunchedEffect(showGoogleAuthDialog) {
        if (showGoogleAuthDialog) {
            inputClientId = customClientId
            inputClientSecret = customClientSecret
        }
    }

    var localPasscode by remember { mutableStateOf(encryptionPassword) }
    var backupToDelete by remember { mutableStateOf<String?>(null) }

    // Google Sign-In and REST simulated authentication Dialog
    if (showGoogleAuthDialog) {
        AlertDialog(
            onDismissRequest = { showGoogleAuthDialog = false },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showGoogleAuthDialog = false }) {
                    Text("Cancel", color = EmeraldDark)
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.CloudQueue, contentDescription = null, tint = EmeraldDark)
                    Text("Google Drive Integration Setup", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Synchronize your product database, customer balances, invoices, and expense registers securely using Google Cloud.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    Text(
                        text = "Custom Developer Credentials (Avoids 404 Errors):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = EmeraldDark
                    )

                    OutlinedTextField(
                        value = inputClientId,
                        onValueChange = { inputClientId = it.trim() },
                        label = { Text("Google Client ID") },
                        placeholder = { Text("xxxxxx-xxxxxx.apps.googleusercontent.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp)
                    )

                    OutlinedTextField(
                        value = inputClientSecret,
                        onValueChange = { inputClientSecret = it.trim() },
                        label = { Text("Google Client Secret") },
                        placeholder = { Text("GOCSPX-xxxxxxxxxxxxxxxxxxxx") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp)
                    )

                    Text(
                        text = "Tip: Create an OAuth 2.0 Web Application client in Google Cloud Console. Set Redirect URI to: smartcashmemo://oauth",
                        fontSize = 10.sp,
                        color = Color.Gray,
                        lineHeight = 13.sp
                    )

                    Button(
                        onClick = {
                            viewModel.saveCustomGoogleCredentials(inputClientId, inputClientSecret)
                            showGoogleAuthDialog = false
                            try {
                                val urlStr = viewModel.getGoogleAuthUrl()
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urlStr))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Could not open browser: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("Real Google OAuth Login", fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Divider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        Text("OR SIMULATE CONNECT", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Divider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    }

                    OutlinedTextField(
                        value = inputName,
                        onValueChange = { inputName = it },
                        label = { Text("Simulation User Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = inputEmail,
                        onValueChange = { inputEmail = it },
                        label = { Text("Simulation Email Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            if (inputEmail.isBlank() || !inputEmail.contains("@")) {
                                Toast.makeText(context, "Please configure a valid email coordinates", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            viewModel.loginToGoogleDrive(inputEmail, inputName)
                            showGoogleAuthDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Connect Simulation Account", fontWeight = FontWeight.Bold)
                    }
                }
            }
        )
    }

    // Processing Progression Dialog
    if (isRunning) {
        Dialog(onDismissRequest = {}) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(color = EmeraldDark, modifier = Modifier.size(36.dp))
                    Text(
                        text = "Cloud Ledger Alignment Active",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    LinearProgressIndicator(
                        color = EmeraldDark,
                        trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape)
                    )
                    Text(
                        text = progressStep,
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        fontStyle = FontStyle.Italic
                    )
                }
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Google Drive Logo Theme Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .background(EmeraldDark.copy(alpha = 0.1f), CircleShape)
                            .padding(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudCircle,
                            contentDescription = null,
                            tint = EmeraldDark,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            "Google Drive Automatic Backup",
                            fontWeight = FontWeight.ExtraBold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            "Corporate automated synchronization protocol",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .background(
                            if (googleEmail.isNotBlank()) EmeraldDark.copy(alpha = 0.1f) else Color.Red.copy(
                                alpha = 0.1f
                            ), RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (googleEmail.isNotBlank()) "SYNC LINKED" else "DISCONNECTED",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (googleEmail.isNotBlank()) EmeraldDark else Color.Red
                    )
                }
            }

            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

            if (googleEmail.isBlank()) {
                // Not Connected State Panel
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Drive Cloud Synchronization Off",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Enable secure ledger backups of products, client registers, invoices, and expense sheets directly to your private Google Drive account.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )
                    Button(
                        onClick = { showGoogleAuthDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("Connect Google Drive", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                // Connected State User Info Account Card
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(EmeraldDark, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = googleName.take(1).uppercase(),
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                        Column {
                            Text(googleName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(googleEmail, fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                    TextButton(
                        onClick = { viewModel.logoutFromGoogleDrive() }
                    ) {
                        Text("Disconnect", color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Auto Backup Configuration
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Automatic Periodic Backups", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Quietly triggers local sync sequences matching cycles", fontSize = 10.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = isAutoBackEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.updateAutoBackupSettings(enabled, autoInterval)
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldDark)
                        )
                    }

                    if (isAutoBackEnabled) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            listOf("Daily", "Weekly", "Monthly").forEach { interval ->
                                val selected = autoInterval == interval
                                FilterChip(
                                    selected = selected,
                                    onClick = { viewModel.updateAutoBackupSettings(true, interval) },
                                    label = { Text(interval, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldDark,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Security & Encryption Config
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Secure Encryption Cipher (AES-256)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Encrypts compiled backup archives prior to sync", fontSize = 10.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = isEncrypted,
                            onCheckedChange = { enabled ->
                                viewModel.updateEncryptionSettings(enabled, localPasscode)
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldDark)
                        )
                    }

                    if (isEncrypted) {
                        OutlinedTextField(
                            value = localPasscode,
                            onValueChange = {
                                localPasscode = it
                                viewModel.updateEncryptionSettings(isEncrypted, it)
                            },
                            label = { Text("AES Security Passphrase Code") },
                            singleLine = true,
                            trailingIcon = {
                                Icon(
                                    imageVector = if (isEncrypted) Icons.Default.Lock else Icons.Default.LockOpen,
                                    contentDescription = null,
                                    tint = EmeraldDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Storage Folder Metadata indicator
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(LightGrayBg, RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                    Text(
                        text = "Drive Destination: My Drive > Smart Cash Memo Backups",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.DarkGray
                    )
                }

                // CTA Action Manual Backup
                Button(
                    onClick = { viewModel.performManualGoogleDriveBackup(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("Initiate Manual Cloud Secure Backup", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            // BACKUP REGISTRY MATRIX LIST (History UI)
            Text(
                text = "Backups Registry Vault (${backupList.size}):",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )

            if (backupList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No archive history cataloged yet.",
                        color = Color.LightGray,
                        fontStyle = FontStyle.Italic,
                        fontSize = 11.sp
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    backupList.forEach { bk ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(EmeraldDark.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                        .padding(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CloudDownload,
                                        contentDescription = null,
                                        tint = EmeraldDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            text = bk.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        if (bk.isEncrypted) {
                                            Icon(
                                                imageVector = Icons.Default.Lock,
                                                contentDescription = "Encrypted Archive",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${bk.size / 1024} KB", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                        Text(bk.createdTime, fontSize = 10.sp, color = Color.Gray)
                                        Box(
                                            modifier = Modifier
                                                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = bk.activeIntervalLabel.uppercase(),
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                    }
                                }
                            }

                            // Restore and Purge actions
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { viewModel.performGoogleDriveRestore(context, bk.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Sync,
                                        contentDescription = "Restore",
                                        tint = EmeraldDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { backupToDelete = bk.id },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = Color.Red,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (backupToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Backup File",
            message = "Are you sure you want to permanently delete this backup file [ID: $backupToDelete] from your Google Drive storage?",
            onConfirm = { viewModel.deleteGoogleDriveBackupFile(backupToDelete!!, context) },
            onDismiss = { backupToDelete = null }
        )
    }
}

@Composable
fun LocalBackupSection(viewModel: POSViewModel) {
    val context = LocalContext.current

    // Launcher for exporting backup JSON file using SAF
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let {
            viewModel.exportDatabaseToUri(context, it)
        }
    }

    // Launcher for importing backup JSON file using SAF
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            viewModel.importDatabaseFromUri(context, it)
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape)
                            .padding(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SaveAlt,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            "Local Backup & Restore",
                            fontWeight = FontWeight.ExtraBold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            "Export or import database backups offline",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

            Text(
                text = "Save a secure backup file containing all products, customers, invoices, expenses, suppliers, purchase orders, and categories to your device's local storage. You can restore this file anytime to revert or transfer your data.",
                fontSize = 11.sp,
                color = Color.Gray,
                lineHeight = 16.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Export Button
                Button(
                    onClick = {
                        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                        exportLauncher.launch("smart_cash_memo_backup_$timestamp.json")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("Export Backup", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // Import Button
                Button(
                    onClick = {
                        importLauncher.launch(arrayOf("application/json", "*/*"))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("Import / Restore", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryManagerDialog(
    viewModel: POSViewModel,
    onDismiss: () -> Unit
) {
    val categories by viewModel.categories.collectAsState()
    var newCategoryName by remember { mutableStateOf("") }
    var editingCategory by remember { mutableStateOf<Category?>(null) }
    var errorText by remember { mutableStateOf("") }
    var categoryToDelete by remember { mutableStateOf<Category?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Manage Categories", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp)
            ) {
                Text(
                    text = "Add, edit, or delete product categorization tags.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Input Field Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = if (editingCategory != null) editingCategory!!.name else newCategoryName,
                        onValueChange = {
                            if (editingCategory != null) {
                                editingCategory = editingCategory!!.copy(name = it)
                            } else {
                                newCategoryName = it
                            }
                        },
                        label = { Text(if (editingCategory != null) "Edit Category" else "New Category Name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            val nameToSave = if (editingCategory != null) editingCategory!!.name else newCategoryName
                            if (nameToSave.isBlank()) {
                                errorText = "Name cannot be empty!"
                            } else {
                                val catId = if (editingCategory != null) editingCategory!!.id else ""
                                viewModel.saveCategory(id = catId, name = nameToSave)
                                newCategoryName = ""
                                editingCategory = null
                                errorText = ""
                            }
                        }
                    ) {
                        Text(if (editingCategory != null) "Update" else "Add")
                    }
                    if (editingCategory != null) {
                        IconButton(onClick = { editingCategory = null }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Cancel Edit")
                        }
                    }
                }

                if (errorText.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(errorText, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                Spacer(modifier = Modifier.height(8.dp))

                // Category List
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(categories) { cat ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = cat.name,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                                Row {
                                    IconButton(
                                        onClick = { editingCategory = cat },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Edit Category",
                                            tint = Color.Gray,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { categoryToDelete = cat },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete Category",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )

    if (categoryToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Category",
            message = "Are you sure you want to permanently delete category '${categoryToDelete!!.name}'? Any products under this category will remain, but will no longer have this tag.",
            onConfirm = { viewModel.deleteCategory(categoryToDelete!!) },
            onDismiss = { categoryToDelete = null }
        )
    }
}

@Composable
fun DeleteConfirmationDialog(
    title: String = "Confirm Deletion",
    message: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(36.dp)
            )
        },
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        },
        text = {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Confirm Delete", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("Cancel", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupplierFormDialog(
    supplier: Supplier?,
    onDismiss: () -> Unit,
    onSave: (name: String, companyName: String, mobile: String, email: String, address: String, taxNumber: String, notes: String) -> Unit
) {
    var name by remember { mutableStateOf(supplier?.name ?: "") }
    var companyName by remember { mutableStateOf(supplier?.companyName ?: "") }
    var mobile by remember { mutableStateOf(supplier?.mobile ?: "") }
    var email by remember { mutableStateOf(supplier?.email ?: "") }
    var address by remember { mutableStateOf(supplier?.address ?: "") }
    var taxNumber by remember { mutableStateOf(supplier?.taxNumber ?: "") }
    var notes by remember { mutableStateOf(supplier?.notes ?: "Wholesale corporate supply") }

    var errorMsg by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (supplier == null) "Register Professional Vendor Supplier" else "Modify Supplier Profile",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (errorMsg.isNotBlank()) {
                    Text(text = errorMsg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Supplier Agent Name*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = companyName,
                    onValueChange = { companyName = it },
                    label = { Text("Company Enterprise Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it },
                    label = { Text("Mobile Contact*") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = taxNumber,
                    onValueChange = { taxNumber = it },
                    label = { Text("Business VAT/Tax Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Registered Business Location Details") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Description") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank() || mobile.isBlank()) {
                        errorMsg = "Agent Name and Mobile Contact are required."
                    } else {
                        onSave(name, companyName, mobile, email, address, taxNumber, notes)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}



