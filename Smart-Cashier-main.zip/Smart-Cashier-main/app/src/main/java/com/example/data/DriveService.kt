package com.example.data

import android.util.Log
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

@JsonClass(generateAdapter = true)
data class GDriveFileListResponse(
    val files: List<GDriveFile> = emptyList()
)

@JsonClass(generateAdapter = true)
data class GDriveFile(
    val id: String,
    val name: String,
    val mimeType: String? = null,
    val size: String? = null,
    val createdTime: String? = null
)

class DriveService {

    private val client = OkHttpClient()
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val mediaTypeJson = "application/json; charset=utf-8".toMediaTypeOrNull()
    private val mediaTypeZip = "application/zip".toMediaTypeOrNull()

    /**
     * Resolves the "Smart Cash Memo Backups" folder ID. Creates it if missing.
     */
    suspend fun getOrCreateBackupFolder(accessToken: String): String = withContext(Dispatchers.IO) {
        if (accessToken.startsWith("mock-")) {
            return@withContext "mock-folder-id-smart-cash-memo"
        }

        // 1. Query for the folder
        val query = "name = 'Smart Cash Memo Backups' and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
        val queryEncoded = URLEncoder.encode(query, "UTF-8")
        val searchUrl = "https://www.googleapis.com/drive/v3/files?q=$queryEncoded&spaces=drive&fields=files(id,name)"

        val searchRequest = Request.Builder()
            .url(searchUrl)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()

        try {
            client.newCall(searchRequest).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: ""
                    val fileList = moshi.adapter(GDriveFileListResponse::class.java).fromJson(bodyString)
                    val existingFolder = fileList?.files?.firstOrNull()
                    if (existingFolder != null) {
                        Log.i("DriveService", "Found existing backups folder: ${existingFolder.id}")
                        return@withContext existingFolder.id
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("DriveService", "Error finding backups folder", e)
        }

        // 2. Create folder if not found
        Log.i("DriveService", "Backups folder missing. Creating Google Drive folder...")
        val createUrl = "https://www.googleapis.com/drive/v3/files"
        val jsonMeta = """
            {
                "name": "Smart Cash Memo Backups",
                "mimeType": "application/vnd.google-apps.folder"
            }
        """.trimIndent()

        val createRequest = Request.Builder()
            .url(createUrl)
            .header("Authorization", "Bearer $accessToken")
            .post(jsonMeta.toRequestBody(mediaTypeJson))
            .build()

        try {
            client.newCall(createRequest).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: ""
                    val file = moshi.adapter(GDriveFile::class.java).fromJson(bodyString)
                    if (file != null) {
                        Log.i("DriveService", "Successfully created backup folder: ${file.id}")
                        return@withContext file.id
                    }
                } else {
                    Log.e("DriveService", "Failed to create folder: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            Log.e("DriveService", "Exception creating backup folder", e)
        }

        // Fallback
        return@withContext "fallback-folder-id"
    }

    /**
     * Uploads the backup ZIP stream to Drive in a specified folder.
     */
    suspend fun uploadBackupFile(
        accessToken: String,
        folderId: String,
        fileName: String,
        backupData: ByteArray
    ): GoogleDriveFileMetadata? = withContext(Dispatchers.IO) {
        if (accessToken.startsWith("mock-")) {
            val simpleDateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            return@withContext GoogleDriveFileMetadata(
                id = "mock-file-" + UUID.randomUUID().toString().take(8),
                name = fileName,
                mimeType = "application/zip",
                size = backupData.size.toLong(),
                createdTime = simpleDateFormat.format(Date()),
                isEncrypted = true,
                activeIntervalLabel = "Manual"
            )
        }

        // We use Multipart/Related format for metadata + content combined upload
        val boundary = "smart_boundary_segment"
        val requestBody = MultipartBody.Builder(boundary)
            .setType("multipart/related; boundary=$boundary".toMediaTypeOrNull()!!)
            .addPart(
                Headers.Builder().add("Content-Type", "application/json; charset=UTF-8").build(),
                """{"name": "$fileName", "parents": ["$folderId"]}""".toRequestBody(mediaTypeJson)
            )
            .addPart(
                Headers.Builder().add("Content-Type", "application/zip").build(),
                backupData.toRequestBody(mediaTypeZip)
            )
            .build()

        val uploadUrl = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,createdTime"
        val request = Request.Builder()
            .url(uploadUrl)
            .header("Authorization", "Bearer $accessToken")
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("DriveService", "Upload failed: ${response.code} ${response.message}")
                    return@withContext null
                }
                val bodyString = response.body?.string() ?: return@withContext null
                val file = moshi.adapter(GDriveFile::class.java).fromJson(bodyString) ?: return@withContext null
                
                val sizeVal = try { file.size?.toLong() ?: backupData.size.toLong() } catch (ex: Exception) { backupData.size.toLong() }
                
                // Drive API returns createdTime ISO-8601 string. Let's format nicely.
                val formattedTime = try {
                    val rawStr = file.createdTime ?: ""
                    val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
                    val date = parser.parse(rawStr)
                    SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(date ?: Date())
                } catch (e: Exception) {
                    SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                }

                return@withContext GoogleDriveFileMetadata(
                    id = file.id,
                    name = file.name,
                    mimeType = "application/zip",
                    size = sizeVal,
                    createdTime = formattedTime,
                    isEncrypted = true,
                    activeIntervalLabel = "Manual"
                )
            }
        } catch (e: Exception) {
            Log.e("DriveService", "Exception during backup zip upload", e)
            return@withContext null
        }
    }

    /**
     * Lists all ZIP backups residing inside our custom backups folder on Drive.
     */
    suspend fun listBackupFiles(
        accessToken: String,
        folderId: String
    ): List<GoogleDriveFileMetadata> = withContext(Dispatchers.IO) {
        if (accessToken.startsWith("mock-")) {
            return@withContext emptyList()
        }

        val query = "'$folderId' in parents and mimeType = 'application/zip' and trashed = false"
        val queryEncoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://www.googleapis.com/drive/v3/files?q=$queryEncoded&fields=files(id,name,size,createdTime)&orderBy=createdTime%20desc"

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext emptyList()
                val bodyString = response.body?.string() ?: return@withContext emptyList()
                val responseData = moshi.adapter(GDriveFileListResponse::class.java).fromJson(bodyString) ?: return@withContext emptyList()
                
                return@withContext responseData.files.map { f ->
                    val sizeVal = f.size?.toLongOrNull() ?: 1024L
                    val formattedTime = try {
                        val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
                        val date = parser.parse(f.createdTime ?: "")
                        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(date ?: Date())
                    } catch (e: Exception) {
                        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                    }
                    GoogleDriveFileMetadata(
                        id = f.id,
                        name = f.name,
                        mimeType = "application/zip",
                        size = sizeVal,
                        createdTime = formattedTime,
                        isEncrypted = f.name.contains("encrypted") || true,
                        activeIntervalLabel = if (f.name.contains("auto")) "Auto" else "Manual"
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("DriveService", "Error listing backlog index files", e)
            return@withContext emptyList()
        }
    }

    /**
     * Downloads direct file stream media from Drive for database restore.
     */
    suspend fun downloadBackupBytes(
        accessToken: String,
        fileId: String
    ): ByteArray? = withContext(Dispatchers.IO) {
        if (accessToken.startsWith("mock-")) {
            return@withContext null
        }

        val url = "https://www.googleapis.com/drive/v3/files/$fileId?alt=media"
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                return@withContext response.body?.bytes()
            }
        } catch (e: Exception) {
            Log.e("DriveService", "Exception loading byte stream", e)
            return@withContext null
        }
    }

    /**
     * Deletes specified file physically on Google Drive.
     */
    suspend fun deleteBackupFile(
        accessToken: String,
        fileId: String
    ): Boolean = withContext(Dispatchers.IO) {
        if (accessToken.startsWith("mock-")) {
            return@withContext true
        }

        val url = "https://www.googleapis.com/drive/v3/files/$fileId"
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $accessToken")
            .delete()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                return@withContext response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e("DriveService", "Exception deleting file from server", e)
            return@withContext false
        }
    }
}
