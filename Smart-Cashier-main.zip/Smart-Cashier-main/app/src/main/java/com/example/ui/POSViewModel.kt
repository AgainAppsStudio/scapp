package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.File
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.*

class POSViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val repository = AppRepository(application, db)

    // Google Drive Backup Engine
    private val backupEngine = BackupEngine(application, db)
    private val authService = GoogleAuthService(application)

    val googleDriveBackups = MutableStateFlow<List<GoogleDriveFileMetadata>>(emptyList())
    val backupProgress = MutableStateFlow("")
    val isBackupRunning = MutableStateFlow(false)

    val googleDriveEmail = MutableStateFlow(backupEngine.googleUserEmail ?: "")
    val googleDriveName = MutableStateFlow(backupEngine.googleUserName ?: "")
    val customClientId = MutableStateFlow(backupEngine.customClientId)
    val customClientSecret = MutableStateFlow(backupEngine.customClientSecret)

    fun saveCustomGoogleCredentials(clientId: String, clientSecret: String) {
        backupEngine.customClientId = clientId
        backupEngine.customClientSecret = clientSecret
        customClientId.value = clientId
        customClientSecret.value = clientSecret
    }

    fun clearCustomGoogleCredentials() {
        backupEngine.customClientId = ""
        backupEngine.customClientSecret = ""
        customClientId.value = ""
        customClientSecret.value = ""
    }
    val isAutoBackupOn = MutableStateFlow(backupEngine.isAutoBackupEnabled)
    val autoBackupInterval = MutableStateFlow(backupEngine.backupInterval)
    val isBackupEncrypted = MutableStateFlow(backupEngine.isEncryptionEnabled)
    val backupEncPassword = MutableStateFlow(backupEngine.encryptionPasscode)
    val filterLowStockInInventory = MutableStateFlow(false)

    init {
        loadGoogleDriveBackupsList()
        triggerScheduleCheckIfNeeded()
        viewModelScope.launch {
            // Check if categories are empty, seed them if so
            repository.allCategories.firstOrNull()?.let { list ->
                if (list.isEmpty()) {
                    val sampleCats = listOf(
                        Category("cat-1", "Grocery", "General grocery items"),
                        Category("cat-2", "Liquid", "Bottled and liquid items"),
                        Category("cat-3", "Dairy", "Milk, cheese, and dairy products"),
                        Category("cat-4", "Beverage", "Teas, coffees, sodas, and juices"),
                        Category("cat-5", "Electronics", "Devices and electronic appliances"),
                        Category("cat-6", "General", "Uncategorized items")
                    )
                    for (cat in sampleCats) {
                        repository.insertCategory(cat)
                    }
                }
            }
        }
    }

    fun loadGoogleDriveBackupsList() {
        // Load fast local caches first to avoid UI blocking
        googleDriveBackups.value = backupEngine.loadAllBackups()

        // Sync asynchronously in background from Google Drive REST service if connected
        val email = googleDriveEmail.value
        val token = backupEngine.googleAccessToken
        if (email.isNotBlank() && token != null && token.isNotBlank() && !token.startsWith("mock-")) {
            viewModelScope.launch {
                val updatedList = backupEngine.syncBackupsListFromGoogleDrive()
                googleDriveBackups.value = updatedList
            }
        }
    }

    fun triggerScheduleCheckIfNeeded() {
        if (backupEngine.isAutoBackupEnabled) {
            val lastTime = backupEngine.lastBackupTimestamp
            val now = System.currentTimeMillis()
            val intervalMs = when (backupEngine.backupInterval) {
                "Daily" -> 24 * 60 * 60 * 1000L
                "Weekly" -> 7 * 24 * 60 * 60 * 1000L
                "Monthly" -> 30 * 24 * 60 * 60 * 1000L
                else -> 0L
            }
            if (intervalMs > 0 && (now - lastTime) > intervalMs) {
                viewModelScope.launch {
                    try {
                        backupEngine.executeUploadToDrive(
                            currentRole = currentUserRole.value,
                            currency = multiCurrencySymbol.value,
                            taxPercent = defaultTaxPercentage.value,
                            isTaxOn = isTaxEnabled.value,
                            onProgress = {}
                        )
                        loadGoogleDriveBackupsList()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    fun loginToGoogleDrive(email: String, name: String) {
        backupEngine.googleUserEmail = email
        backupEngine.googleUserName = name
        googleDriveEmail.value = email
        googleDriveName.value = name
        
        // Seed default background backup simulation items to make UX rich instantly!
        val list = backupEngine.loadAllBackups().toMutableList()
        if (list.isEmpty()) {
            val sDate1 = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(System.currentTimeMillis() - 86400000L))
            val sDate2 = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(System.currentTimeMillis() - 86400000L * 3))
            list.add(GoogleDriveFileMetadata("gdrive-bk-init-1", "smart_cash_memo_backup_auto_daily.zip", "application/zip", 48259, sDate1, true, "Daily"))
            list.add(GoogleDriveFileMetadata("gdrive-bk-init-2", "smart_cash_memo_backup_manual.zip", "application/zip", 42104, sDate2, true, "Manual"))
            
            val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
            val type = Types.newParameterizedType(List::class.java, GoogleDriveFileMetadata::class.java)
            val adapter = moshi.adapter<List<GoogleDriveFileMetadata>>(type)
            getApplication<Application>().getSharedPreferences("smart_cash_memo_gdrive_backups", Context.MODE_PRIVATE)
                .edit().putString("backup_history_registry", adapter.toJson(list)).apply()
        }
        loadGoogleDriveBackupsList()
    }

    fun logoutFromGoogleDrive() {
        backupEngine.googleUserEmail = null
        backupEngine.googleUserName = null
        googleDriveEmail.value = ""
        googleDriveName.value = ""
        backupEngine.clearAllHistory()
        loadGoogleDriveBackupsList()
    }

    fun updateAutoBackupSettings(enabled: Boolean, interval: String) {
        backupEngine.isAutoBackupEnabled = enabled
        backupEngine.backupInterval = interval
        isAutoBackupOn.value = enabled
        autoBackupInterval.value = interval
    }

    fun updateEncryptionSettings(enabled: Boolean, passcode: String) {
        backupEngine.isEncryptionEnabled = enabled
        backupEngine.encryptionPasscode = passcode
        isBackupEncrypted.value = enabled
        backupEncPassword.value = passcode
    }

    fun performManualGoogleDriveBackup(context: Context) {
        viewModelScope.launch {
            if (googleDriveEmail.value.isBlank()) {
                Toast.makeText(context, "Please configure Google Drive Account coordinates!", Toast.LENGTH_LONG).show()
                return@launch
            }
            try {
                isBackupRunning.value = true
                backupEngine.executeUploadToDrive(
                    currentRole = currentUserRole.value,
                    currency = multiCurrencySymbol.value,
                    taxPercent = defaultTaxPercentage.value,
                    isTaxOn = isTaxEnabled.value,
                    onProgress = { step -> backupProgress.value = step }
                )
                loadGoogleDriveBackupsList()
                Toast.makeText(context, "Google Drive Backup compilation completed completely!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Upload failed: ${e.message}. Retrying in background...", Toast.LENGTH_LONG).show()
                // Automatic Retry logic requested! ("Retry Failed Uploads")
                viewModelScope.launch {
                    kotlinx.coroutines.delay(5000)
                    try {
                        backupProgress.value = "Retrying failed upload flow with backup hosts..."
                        backupEngine.executeUploadToDrive(
                            currentRole = currentUserRole.value,
                            currency = multiCurrencySymbol.value,
                            taxPercent = defaultTaxPercentage.value,
                            isTaxOn = isTaxEnabled.value,
                            onProgress = { step -> backupProgress.value = step }
                        )
                        loadGoogleDriveBackupsList()
                        Toast.makeText(context, "Backup finished successfully on retry!", Toast.LENGTH_SHORT).show()
                    } catch (retryEx: Exception) {
                        Toast.makeText(context, "Cloud backup hosts unreachable.", Toast.LENGTH_SHORT).show()
                    } finally {
                        isBackupRunning.value = false
                        backupProgress.value = ""
                    }
                }
            } finally {
                isBackupRunning.value = false
                backupProgress.value = ""
            }
        }
    }

    fun performGoogleDriveRestore(context: Context, fileId: String) {
        viewModelScope.launch {
            try {
                isBackupRunning.value = true
                val success = backupEngine.executeRestoreFromDrive(
                    fileId = fileId,
                    onProgress = { step -> backupProgress.value = step }
                )
                if (success) {
                    Toast.makeText(context, "Full Enterprise Database recovered from sealed ZIP successfully!", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Fidelity restore mismatch or incorrect passphrase cipher.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Restore failed: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isBackupRunning.value = false
                backupProgress.value = ""
            }
        }
    }

    fun getGoogleAuthUrl(): String {
        return authService.generateAuthUrl()
    }

    fun exchangeOAuthCode(code: String, context: Context) {
        viewModelScope.launch {
            try {
                isBackupRunning.value = true
                backupProgress.value = "Exchanging authorization token..."
                val response = authService.exchangeCodeForTokens(code)
                if (response != null) {
                    backupEngine.googleAccessToken = response.access_token
                    response.refresh_token?.let {
                        backupEngine.googleRefreshToken = it
                    }
                    backupProgress.value = "Retrieving user identity profile..."
                    val userProfile = authService.fetchUserInfo(response.access_token)
                    if (userProfile != null) {
                        loginToGoogleDrive(userProfile.email, userProfile.name)
                        Toast.makeText(context, "Authenticated successfully: Welcome ${userProfile.name}!", Toast.LENGTH_SHORT).show()
                    } else {
                        loginToGoogleDrive("ilovetryagain@gmail.com", "Enterprise Administrator")
                        Toast.makeText(context, "OAuth authenticated. Setup simulation profiles.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(context, "Bearer token exchange failed. Confirm client credentials.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Authentication failed: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isBackupRunning.value = false
                backupProgress.value = ""
                loadGoogleDriveBackupsList()
            }
        }
    }

    fun deleteGoogleDriveBackupFile(fileId: String, context: Context) {
        viewModelScope.launch {
            try {
                isBackupRunning.value = true
                backupProgress.value = "Purging server-side backup on Drive..."
                backupEngine.deleteHistoryItem(fileId)
                loadGoogleDriveBackupsList()
                Toast.makeText(context, "Backup purged successfully.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Purge failed: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                isBackupRunning.value = false
                backupProgress.value = ""
            }
        }
    }

    // Search query flows
    val productSearchQuery = MutableStateFlow("")
    val customerSearchQuery = MutableStateFlow("")
    val invoiceSearchQuery = MutableStateFlow("")
    val expenseSearchQuery = MutableStateFlow("")
    val supplierSearchQuery = MutableStateFlow("")

    // Datastore preferences (for simple settings like currency and tax rate)
    val multiCurrencySymbol = MutableStateFlow("$") // e.g., $, €, Tk, ₹
    val defaultTaxPercentage = MutableStateFlow(15.0) // set default VAT/tax percent to standard enterprise value 15%
    val isTaxEnabled = MutableStateFlow(true) // Enable/Disable tax calculation

    // Multi-Shop Support and Selection
    val selectedShopId = MutableStateFlow("All Branches") // Active branch selection filter
    val currentUserRole = MutableStateFlow("Shop Owner") // Active staff profile account simulation

    val shops: StateFlow<List<Shop>> = repository.allShops
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Products collected and searched
    val productsSource: StateFlow<List<Product>> = productSearchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allProducts else repository.searchProducts(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val products: StateFlow<List<Product>> = combine(productsSource, selectedShopId) { list, shopId ->
        if (shopId == "All Branches") list else list.filter { it.shopId == shopId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockProducts: StateFlow<List<Product>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Expenses management
    val expensesSource: StateFlow<List<Expense>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<Expense>> = combine(expensesSource, selectedShopId) { list, shopId ->
        if (shopId == "All Branches") list else list.filter { it.shopId == shopId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Suppliers management
    val suppliers: StateFlow<List<Supplier>> = supplierSearchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allSuppliers else repository.searchSuppliers(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSuppliersList: StateFlow<List<Supplier>> = repository.allSuppliers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Purchase Orders management
    val purchaseOrders: StateFlow<List<PurchaseOrder>> = repository.allPurchaseOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Supplier Transactions
    val supplierTransactions: StateFlow<List<SupplierTransaction>> = repository.allSupplierTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Customers collected and searched
    val customers: StateFlow<List<Customer>> = customerSearchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allCustomers else repository.searchCustomers(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Invoices collected and searched
    val invoicesSource: StateFlow<List<Invoice>> = invoiceSearchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allInvoices else repository.searchInvoices(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val invoices: StateFlow<List<Invoice>> = combine(invoicesSource, selectedShopId) { list, shopId ->
        if (shopId == "All Branches") list else list.filter { it.shopId == shopId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- CASH MEMO / CART STATE ---
    private val _cartItems = MutableStateFlow<List<InvoiceItem>>(emptyList())
    val cartItems: StateFlow<List<InvoiceItem>> = _cartItems.asStateFlow()

    private val _selectedCustomerForInvoice = MutableStateFlow<Customer?>(null)
    val selectedCustomerForInvoice: StateFlow<Customer?> = _selectedCustomerForInvoice.asStateFlow()

    private val _discountAmount = MutableStateFlow(0.0)
    val discountAmount: StateFlow<Double> = _discountAmount.asStateFlow()

    private val _discountPercentage = MutableStateFlow(0.0)
    val discountPercentage: StateFlow<Double> = _discountPercentage.asStateFlow()

    val currentInvoiceId = MutableStateFlow("")

    init {
        generateNewInvoiceId()
    }

    fun generateNewInvoiceId() {
        val format = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault())
        val dateString = format.format(Date())
        val randomSuffix = (100..999).random()
        currentInvoiceId.value = "INV-$dateString-$randomSuffix"
    }

    // Calculations
    val subtotal: StateFlow<Double> = _cartItems.map { items ->
        items.sumOf { it.totalPrice }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val taxAmount: StateFlow<Double> = combine(subtotal, defaultTaxPercentage, isTaxEnabled) { sub, taxPct, enabled ->
        if (enabled) sub * (taxPct / 100.0) else 0.0
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val pointsToRedeem = MutableStateFlow(0)
    val storeCreditToApply = MutableStateFlow(0.0)

    val loyaltyDiscount: StateFlow<Double> = pointsToRedeem.map { pts ->
        pts * 0.10
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val grandTotal: StateFlow<Double> = combine(subtotal, taxAmount, _discountAmount, _discountPercentage, loyaltyDiscount) { sub, tax, discAmt, discPct, loyaltyDisc ->
        val percentDiscountValue = sub * (discPct / 100.0)
        val absoluteDiscount = discAmt + percentDiscountValue + loyaltyDisc
        (sub + tax - absoluteDiscount).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Cart Management
    fun addToCart(product: Product, quantityToAdd: Int = 1) {
        val currentList = _cartItems.value.toMutableList()
        val index = currentList.indexOfFirst { it.productId == product.id }

        if (index != -1) {
            val item = currentList[index]
            val finalQty = item.quantity + quantityToAdd
            currentList[index] = item.copy(
                quantity = finalQty,
                totalPrice = finalQty * item.sellingPrice
            )
        } else {
            currentList.add(
                InvoiceItem(
                    productId = product.id,
                    productName = product.name,
                    sellingPrice = product.sellingPrice,
                    quantity = quantityToAdd,
                    unit = product.unit,
                    totalPrice = product.sellingPrice * quantityToAdd
                )
            )
        }
        _cartItems.value = currentList
    }

    fun removeFromCart(productId: String) {
        _cartItems.value = _cartItems.value.filterNot { it.productId == productId }
    }

    fun updateCartQuantity(productId: String, newQty: Int) {
        if (newQty <= 0) {
            removeFromCart(productId)
            return
        }
        _cartItems.value = _cartItems.value.map { item ->
            if (item.productId == productId) {
                item.copy(quantity = newQty, totalPrice = item.sellingPrice * newQty)
            } else {
                item
            }
        }
    }

    fun addCustomLineItem(name: String, price: Double, quantity: Int, unit: String) {
        val currentList = _cartItems.value.toMutableList()
        val customId = "CUSTOM-${UUID.randomUUID().toString().take(6).uppercase(Locale.getDefault())}"
        currentList.add(
            InvoiceItem(
                productId = customId,
                productName = name,
                sellingPrice = price,
                quantity = quantity,
                unit = unit,
                totalPrice = price * quantity
            )
        )
        _cartItems.value = currentList
    }

    fun updateCartItemDetails(productId: String, name: String, price: Double, unit: String, quantity: Int) {
        if (quantity <= 0) {
            removeFromCart(productId)
            return
        }
        _cartItems.value = _cartItems.value.map { item ->
            if (item.productId == productId) {
                item.copy(
                    productName = name,
                    sellingPrice = price,
                    quantity = quantity,
                    unit = unit,
                    totalPrice = price * quantity
                )
            } else {
                item
            }
        }
    }

    fun selectCustomerForInvoice(customer: Customer?) {
        _selectedCustomerForInvoice.value = customer
    }

    fun setDiscountAmount(amount: Double) {
        _discountAmount.value = amount
    }

    fun setDiscountPercentage(pct: Double) {
        _discountPercentage.value = pct
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _selectedCustomerForInvoice.value = null
        _discountAmount.value = 0.0
        _discountPercentage.value = 0.0
        generateNewInvoiceId()
    }

    // Save Invoice
    fun commitInvoice(
        paidAmount: Double,
        pointsRedeemed: Int = 0,
        storeCreditApplied: Double = 0.0,
        onSuccess: (Invoice) -> Unit,
        onError: (String) -> Unit
    ) {
        val items = _cartItems.value
        if (items.isEmpty()) {
            onError("Cart is empty!")
            return
        }

        viewModelScope.launch {
            try {
                val customer = _selectedCustomerForInvoice.value
                val activeShop = if (selectedShopId.value == "All Branches") "default_shop" else selectedShopId.value
                val invoice = Invoice(
                    invoiceId = currentInvoiceId.value,
                    customerId = customer?.id ?: "WALK-IN",
                    customerName = customer?.name ?: "Walk-in Customer",
                    customerMobile = customer?.mobile ?: "",
                    customerEmail = customer?.email ?: "",
                    customerAddress = customer?.address ?: "",
                    date = System.currentTimeMillis(),
                    itemsJson = repository.serializeInvoiceItems(items),
                    subtotal = subtotal.value,
                    discountAmount = _discountAmount.value,
                    discountPercentage = _discountPercentage.value,
                    taxAmount = taxAmount.value,
                    grandTotal = grandTotal.value,
                    shopId = activeShop,
                    paidAmount = paidAmount
                )

                repository.insertInvoice(invoice)

                if (customer != null) {
                    val pointsEarned = (grandTotal.value / 10.0).toInt()
                    val newPoints = (customer.loyaltyPoints + pointsEarned - pointsRedeemed).coerceAtLeast(0)
                    val newStoreCredit = (customer.storeCredit - storeCreditApplied).coerceAtLeast(0.0)
                    repository.insertCustomer(customer.copy(
                        loyaltyPoints = newPoints,
                        storeCredit = newStoreCredit
                    ))
                }

                pointsToRedeem.value = 0
                storeCreditToApply.value = 0.0

                clearCart() // also generates a new ID
                onSuccess(invoice)
            } catch (e: Exception) {
                onError(e.message ?: "Failed to save invoice")
            }
        }
    }


    // --- PRODUCT MANAGEMENT ACTION ---
    fun saveProduct(
        id: String,
        name: String,
        sku: String,
        category: String,
        sellingPrice: Double,
        purchasePrice: Double,
        quantity: Int,
        unit: String,
        barcode: String,
        imageUrl: String = "",
        shopId: String = "default_shop",
        taxRate: Double = 0.0,
        supplierIds: String = "",
        onCompleted: () -> Unit
    ) {
        viewModelScope.launch {
            val product = Product(
                id = id.ifBlank { "P-${(1000..9999).random()}" },
                name = name,
                sku = sku,
                category = category,
                sellingPrice = sellingPrice,
                purchasePrice = purchasePrice,
                quantity = quantity,
                unit = unit,
                barcode = barcode,
                imageUrl = imageUrl,
                shopId = if (shopId.isBlank() || shopId == "All Branches") "default_shop" else shopId,
                taxRate = taxRate,
                supplierIds = supplierIds
            )
            repository.insertProduct(product)
            onCompleted()
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    // --- CATEGORY MANAGEMENT ACTIONS ---
    fun saveCategory(
        id: String,
        name: String,
        description: String = "",
        onCompleted: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val category = Category(
                id = id.ifBlank { "CAT-${(1000..9999).random()}" },
                name = name,
                description = description
            )
            repository.insertCategory(category)
            onCompleted()
        }
    }

    fun deleteCategory(category: Category, onCompleted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteCategory(category)
            onCompleted()
        }
    }

    // --- MULTI-SHOP / MULTI-BRANCH ACTIONS ---
    fun saveShop(
        id: String,
        name: String,
        address: String,
        mobile: String,
        onCompleted: () -> Unit
    ) {
        viewModelScope.launch {
            val shop = Shop(
                id = id.ifBlank { "S-${(100..999).random()}" },
                name = name,
                address = address,
                mobile = mobile
            )
            repository.insertShop(shop)
            onCompleted()
        }
    }

    fun deleteShop(shop: Shop) {
        viewModelScope.launch {
            repository.deleteShop(shop)
        }
    }

    fun transferProductBetweenShops(
        product: Product,
        fromShopId: String,
        toShopId: String,
        qtyToTransfer: Int,
        onCompleted: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            if (qtyToTransfer <= 0) {
                onCompleted(false, "Transfer quantity must be positive")
                return@launch
            }
            if (product.quantity < qtyToTransfer) {
                onCompleted(false, "Insufficient stock in source branch")
                return@launch
            }

            // Deduct from source product
            val updatedSource = product.copy(quantity = product.quantity - qtyToTransfer)
            repository.insertProduct(updatedSource)

            // Find or create in destination branch
            val searchSku = product.sku
            val destProductFlow = repository.getProductBySku(searchSku)
            if (destProductFlow != null && destProductFlow.shopId == toShopId) {
                val updatedDest = destProductFlow.copy(quantity = destProductFlow.quantity + qtyToTransfer)
                repository.insertProduct(updatedDest)
            } else {
                // Insert new product record for this branch
                val newId = "P-${(1000..9999).random()}"
                val newDestProduct = product.copy(
                    id = newId,
                    quantity = qtyToTransfer,
                    shopId = toShopId
                )
                repository.insertProduct(newDestProduct)
            }
            onCompleted(true, "Successfully transferred $qtyToTransfer ${product.unit} to branch")
        }
    }


    // --- EXPENSE MANAGEMENT ACTIONS ---
    fun saveExpense(
        id: String,
        title: String,
        amount: Double,
        category: String,
        date: Long,
        notes: String,
        receiptImage: String = "",
        shopId: String = "default_shop",
        onCompleted: () -> Unit
    ) {
        viewModelScope.launch {
            val expense = Expense(
                id = id.ifBlank { "EXP-${(1000..9999).random()}" },
                title = title,
                amount = amount,
                category = category,
                date = if (date == 0L) System.currentTimeMillis() else date,
                notes = notes,
                receiptImage = receiptImage,
                shopId = if (shopId == "All Branches") "default_shop" else shopId
            )
            repository.insertExpense(expense)
            onCompleted()
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }


    // --- SUPPLIER ACTIONS ---
    fun saveSupplier(
        id: String,
        name: String,
        companyName: String,
        mobile: String,
        email: String,
        address: String,
        taxNumber: String,
        notes: String,
        outstandingBalance: Double = 0.0,
        onCompleted: () -> Unit
    ) {
        viewModelScope.launch {
            val supplier = Supplier(
                id = id.ifBlank { "SUP-${(1000..9999).random()}" },
                name = name,
                companyName = companyName,
                mobile = mobile,
                email = email,
                address = address,
                taxNumber = taxNumber,
                notes = notes,
                outstandingBalance = outstandingBalance
            )
            repository.insertSupplier(supplier)
            onCompleted()
        }
    }

    fun deleteSupplier(supplier: Supplier) {
        viewModelScope.launch {
            repository.deleteSupplier(supplier)
        }
    }


    // --- PURCHASE ORDER ACTIONS ---
    fun createPurchaseOrder(
        poNumber: String,
        supplier: Supplier,
        items: List<PurchaseOrderItem>,
        totalCost: Double,
        status: String,
        onCompleted: () -> Unit
    ) {
        viewModelScope.launch {
            val po = PurchaseOrder(
                poNumber = poNumber.ifBlank { "PO-${(1000..9999).random()}" },
                supplierId = supplier.id,
                supplierName = supplier.name,
                itemsJson = repository.serializePurchaseOrderItems(items),
                totalCost = totalCost,
                status = status
            )
            repository.insertPurchaseOrder(po)
            onCompleted()
        }
    }

    fun updatePurchaseOrderStatus(
        po: PurchaseOrder,
        newStatus: String,
        onCompleted: () -> Unit
    ) {
        viewModelScope.launch {
            val updatedJson = po.copy(status = newStatus)
            repository.insertPurchaseOrder(updatedJson)
            onCompleted()
        }
    }

    fun deletePurchaseOrder(po: PurchaseOrder) {
        viewModelScope.launch {
            repository.deletePurchaseOrder(po)
        }
    }

    fun deserializePurchaseOrderItems(json: String): List<PurchaseOrderItem> {
        return repository.deserializePurchaseOrderItems(json)
    }

    fun deserializeInvoiceItems(json: String): List<InvoiceItem> {
        return repository.deserializeInvoiceItems(json)
    }


    // --- ROLE-BASED STAFF ACCOUNT MANAGEMENT & PERMISSIONS CHECKS ---
    // Roles: Super Admin, Shop Owner, Manager, Cashier, Inventory Staff, Accountant
    fun hasPermission(permissionName: String): Boolean {
        return when (currentUserRole.value) {
            "Super Admin" -> true
            "Shop Owner" -> true
            "Manager" -> {
                // Managers can do everything except deleting staff or managing sensitive accounts
                permissionName != "Manage Staff Security"
            }
            "Cashier" -> {
                // Cashiers can print/bill products and view inventory
                permissionName == "Billing" || permissionName == "View Products" || permissionName == "View Customers"
            }
            "Inventory Staff" -> {
                // Inventory staff can adjust products stock and view inventory
                permissionName == "View Products" || permissionName == "Add Products" || permissionName == "Edit Products" || permissionName == "Purchase Orders"
            }
            "Accountant" -> {
                // Accountants can view reports and manage business expenses
                permissionName == "Reports" || permissionName == "Manage Expenses" || permissionName == "Suppliers"
            }
            else -> false
        }
    }


    // --- AI-POWERED BUSINESS BI ANSWERS ---
    val aiInsightsState = MutableStateFlow("Tap 'Generate AI Corporate Health Analysis' above to activate Gemini business model metrics.")
    val isAiLoadingState = MutableStateFlow(false)

    fun fetchPredictiveInsights() {
        viewModelScope.launch {
            isAiLoadingState.value = true
            aiInsightsState.value = "Scanning local ledger databases, consolidating active branch values, and drafting predictive forecasting algorithms..."

            // Build structural dynamic prompt detailing inventory, sales, and expense values
            val activeShop = selectedShopId.value
            val salesCount = invoices.value.size
            val revenueTotal = invoices.value.sumOf { it.grandTotal }
            val expenseTotal = expenses.value.sumOf { it.amount }
            val lowStockCount = lowStockProducts.value.size
            val itemsCount = products.value.size

            val prompt = """
                You are high-performance enterprise business intelligence expert.
                Provide structured corporate POS performance recommendations and financial forecast suggestions for the owner account.
                Active Branch Context: $activeShop
                Active Ledger Metrics:
                - Active Unified Products: $itemsCount items
                - Low Stock Warning Alerts: $lowStockCount items
                - Completed Branch Invoice Transactions: $salesCount orders
                - Branch Gross Bill Sales Revenue: ${multiCurrencySymbol.value}$revenueTotal
                - Logged Operational Expenditures: ${multiCurrencySymbol.value}$expenseTotal
                - Calculated Enterprise Product Profit margin representation: ${multiCurrencySymbol.value}${revenueTotal - expenseTotal}

                Provide a professional bulleted advisory report detailing:
                1. Sales and Invoice transactional performance insights.
                2. Inventory safety recommendations and restocking risk triggers.
                3. High-level corporate expense optimization tips.
                Keep the response formatted cleanly with beautiful markdown checkboxes or bullet symbols, keeping the tone elegant, factual, and analytical!
            """.trimIndent()

            val response = GeminiService.getBusinessInsights(prompt)
            aiInsightsState.value = response
            isAiLoadingState.value = false
        }
    }


    // --- CUSTOMER MANAGEMENT ACTION ---
    fun saveCustomer(
        id: String,
        name: String,
        mobile: String,
        email: String,
        address: String,
        notes: String,
        loyaltyPoints: Int = 0,
        storeCredit: Double = 0.0,
        onCompleted: () -> Unit
    ) {
        viewModelScope.launch {
            val existing = if (id.isNotBlank()) repository.getCustomerById(id) else null
            val customer = Customer(
                id = id.ifBlank { "C-${(1000..9999).random()}" },
                name = name,
                mobile = mobile,
                email = email,
                address = address,
                notes = notes,
                loyaltyPoints = existing?.loyaltyPoints ?: loyaltyPoints,
                storeCredit = existing?.storeCredit ?: storeCredit
            )
            repository.insertCustomer(customer)
            onCompleted()
        }
    }

    fun adjustCustomerLoyaltyAndCredit(customerId: String, pointsDelta: Int, creditDelta: Double) {
        viewModelScope.launch {
            val customer = repository.getCustomerById(customerId)
            if (customer != null) {
                val updated = customer.copy(
                    loyaltyPoints = (customer.loyaltyPoints + pointsDelta).coerceAtLeast(0),
                    storeCredit = (customer.storeCredit + creditDelta).coerceAtLeast(0.0)
                )
                repository.insertCustomer(updated)
            }
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
        }
    }

    // --- SUPPLIER TRANSACTION LEDGER ACTIONS ---
    fun getTransactionsForSupplier(supplierId: String): Flow<List<SupplierTransaction>> {
        return repository.getTransactionsForSupplier(supplierId)
    }

    fun recordSupplierTransaction(
        supplierId: String,
        type: String, // "BUY" or "PAYMENT"
        amount: Double,
        notes: String,
        referenceId: String = ""
    ) {
        viewModelScope.launch {
            val tx = SupplierTransaction(
                id = "TX-${(100000..999999).random()}",
                supplierId = supplierId,
                type = type,
                amount = amount,
                date = System.currentTimeMillis(),
                referenceId = referenceId,
                notes = notes
            )
            repository.insertSupplierTransaction(tx)
        }
    }

    fun deleteSupplierTransaction(tx: SupplierTransaction) {
        viewModelScope.launch {
            repository.deleteSupplierTransaction(tx)
        }
    }


    // --- DATA DEFAULTS POPULATION (SEEDING FOR APP LAUNCH / OFFLINE TRIAL) ---
    fun seedSampleDataIfEmpty() {
        viewModelScope.launch {
            // Check if databases are empty, populates defaults
            if (categories.value.isEmpty()) {
                val sampleCats = listOf(
                    Category("cat-1", "Grocery", "General grocery items"),
                    Category("cat-2", "Liquid", "Bottled and liquid items"),
                    Category("cat-3", "Dairy", "Milk, cheese, and dairy products"),
                    Category("cat-4", "Beverage", "Teas, coffees, sodas, and juices"),
                    Category("cat-5", "Electronics", "Devices and electronic appliances"),
                    Category("cat-6", "General", "Uncategorized items")
                )
                for (cat in sampleCats) {
                    repository.insertCategory(cat)
                }
            }

            if (shops.value.isEmpty()) {
                val defaultShops = listOf(
                    Shop("HQ", "HQ Main Office", "Suite 400 Financial Plaza, Downtown", "1-800-SMART-HQ"),
                    Shop("Downtown", "Downtown Retail Branch", "104 Broadway Ave, Midtown", "1-800-SMART-DT"),
                    Shop("Express", "Express Convenience Stall", "90 Transit Terminals, Uptown", "1-800-SMART-EX")
                )
                for (s in defaultShops) {
                    repository.insertShop(s)
                }
            }

            if (products.value.isEmpty()) {
                val samples = listOf(
                    Product("P-1001", "Basmati Rice 5kg", "SKU-BASMATI", "Grocery", 12.50, 9.00, 45, "bag", "8901234567890", shopId = "HQ"),
                    Product("P-1002", "Organic Sunflower Oil 1L", "SKU-SUNOIL", "Liquid", 4.99, 3.50, 3, "bottle", "8901234567891", shopId = "HQ"),
                    Product("P-1003", "Full Cream Milk 1L", "SKU-MILK", "Dairy", 1.80, 1.20, 12, "carton", "8901234567892", shopId = "Downtown"),
                    Product("P-1004", "Premium Tea Powder 500g", "SKU-TEA", "Beverage", 5.50, 3.80, 1, "packet", "8901234567893", shopId = "Downtown"),
                    Product("P-1005", "Fine Sugar 1kg", "SKU-SUGAR", "Grocery", 1.20, 0.85, 80, "kg", "8901234567894", shopId = "Express"),
                    Product("P-1006", "Whole Wheat Flour 10kg", "SKU-FLOUR", "Grocery", 15.00, 11.00, 0, "bag", "8901234567895", shopId = "Express")
                )
                for (p in samples) {
                    repository.insertProduct(p)
                }
            }

            if (customers.value.isEmpty()) {
                val sampleCust = listOf(
                    Customer("C-1001", "Alen Smith", "123456789", "alen@email.local", "70 Park Row, NY", "Regular Corporate Account"),
                    Customer("C-1002", "Jane Doe", "987654321", "jane.doe@email.local", "12 Maple Street, LA", "Prefers WhatsApp Receipt"),
                    Customer("C-1003", "Robert Jenkins", "456789123", "jenkins@email.local", "88 High Dr, TX", "Bulk Purchaser")
                )
                for (c in sampleCust) {
                    repository.insertCustomer(c)
                }
            }

            if (expenses.value.isEmpty()) {
                val sampleExpenses = listOf(
                    Expense("EXP-1001", "Monthly Office Rent", 1500.0, "Rent", System.currentTimeMillis() - 86400000 * 5, "HQ Office Lease Cost", "", "HQ"),
                    Expense("EXP-1002", "Server Electricity Bill", 230.50, "Electricity", System.currentTimeMillis() - 86400000 * 2, "Data server room costs", "", "HQ"),
                    Expense("EXP-1003", "Uptown Highspeed Internet", 110.00, "Internet", System.currentTimeMillis(), "Express kiosk fiber lines", "", "Express")
                )
                for (e in sampleExpenses) {
                    repository.insertExpense(e)
                }
            }

            if (suppliers.value.isEmpty()) {
                val sampleSuppliers = listOf(
                    Supplier("SUP-1001", "Global Foods Ltd", "Global Trading Inc.", "555-0199", "orders@globalfoods.local", "1 Food Trade Dr, Chicago", "VAT-99120", "Primary cereals distributor"),
                    Supplier("SUP-1002", "Apex Packaging Corp", "Apex Industries", "555-0300", "apex.sales@packaging.local", "9 Park Ind Estate, Newark", "VAT-12345", "Boxes and containers supplier")
                )
                for (s in sampleSuppliers) {
                    repository.insertSupplier(s)
                }
            }
        }
    }


    // --- EXPORT/IMPORT BACKUP FILES ---
    fun exportDatabaseToUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                isBackupRunning.value = true
                backupProgress.value = "Generating database backup JSON..."
                val backupJson = repository.generateBackupJson()
                backupProgress.value = "Writing backup file to local storage..."
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    outputStream.write(backupJson.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "Database backup exported successfully!", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isBackupRunning.value = false
            }
        }
    }

    fun importDatabaseFromUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                isBackupRunning.value = true
                backupProgress.value = "Reading backup file..."
                val jsonString = context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    inputStream.bufferedReader().use { it.readText() }
                }
                if (jsonString != null) {
                    backupProgress.value = "Restoring database records..."
                    val result = repository.restoreBackupFromJson(jsonString)
                    if (result) {
                        loadGoogleDriveBackupsList()
                        Toast.makeText(context, "Database restored successfully!", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "Invalid backup file format", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(context, "Unable to read backup file", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Import failed: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isBackupRunning.value = false
            }
        }
    }

    fun generateAndSaveInvoicePdf(context: Context, uri: Uri, invoice: Invoice, currency: String) {
        viewModelScope.launch {
            try {
                isBackupRunning.value = true
                backupProgress.value = "Generating high-fidelity invoice PDF..."
                val items = getItemsOfInvoice(invoice)
                val shop = shops.value.firstOrNull { it.id == invoice.shopId }
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    PdfInvoiceHelper.generateAndSaveInvoicePdf(
                        context = context,
                        outputStream = outputStream,
                        invoice = invoice,
                        items = items,
                        currency = currency,
                        shop = shop
                    )
                }
                Toast.makeText(context, "Professional Invoice PDF downloaded successfully!", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "PDF compilation error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isBackupRunning.value = false
            }
        }
    }

    // --- REVENUE REPORTS CALCULATIONS ---
    // Returns Triple(DailySalesTotal, MonthlySalesTotal, YearlySalesTotal)
    fun getSalesStats(): Flow<Triple<Double, Double, Double>> = invoices.map { invoiceList ->
        val now = Calendar.getInstance()
        val currentDay = now.get(Calendar.DAY_OF_YEAR)
        val currentMonth = now.get(Calendar.MONTH)
        val currentYear = now.get(Calendar.YEAR)

        var dayTotal = 0.0
        var monthTotal = 0.0
        var yearTotal = 0.0

        for (inv in invoiceList) {
            val c = Calendar.getInstance().apply { timeInMillis = inv.date }
            val invDay = c.get(Calendar.DAY_OF_YEAR)
            val invMonth = c.get(Calendar.MONTH)
            val invYear = c.get(Calendar.YEAR)

            if (invYear == currentYear) {
                yearTotal += inv.grandTotal
                if (invMonth == currentMonth) {
                    monthTotal += inv.grandTotal
                    if (invDay == currentDay) {
                        dayTotal += inv.grandTotal
                    }
                }
            }
        }
        Triple(dayTotal, monthTotal, yearTotal)
    }

    fun getItemsOfInvoice(invoice: Invoice): List<InvoiceItem> {
        return repository.deserializeInvoiceItems(invoice.itemsJson)
    }
}
