package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@Entity(tableName = "shops")
@JsonClass(generateAdapter = true)
data class Shop(
    @PrimaryKey val id: String,
    val name: String,
    val address: String,
    val mobile: String,
    val createdDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "products")
@JsonClass(generateAdapter = true)
data class Product(
    @PrimaryKey val id: String,
    val name: String,
    val sku: String,
    val category: String,
    val sellingPrice: Double,
    val purchasePrice: Double,
    val quantity: Int,
    val unit: String,
    val barcode: String,
    val imageUrl: String = "",
    val createdDate: Long = System.currentTimeMillis(),
    val shopId: String = "default_shop",
    val taxRate: Double = 0.0, // Custom tax rate override for this product
    val supplierIds: String = "" // Comma-separated list of supplier IDs
)

@Entity(tableName = "customers")
@JsonClass(generateAdapter = true)
data class Customer(
    @PrimaryKey val id: String,
    val name: String,
    val mobile: String,
    val email: String,
    val address: String,
    val notes: String,
    val createdDate: Long = System.currentTimeMillis(),
    val loyaltyPoints: Int = 0,
    val storeCredit: Double = 0.0
)

@Entity(tableName = "invoices")
@JsonClass(generateAdapter = true)
data class Invoice(
    @PrimaryKey val invoiceId: String,
    val customerId: String,
    val customerName: String,
    val customerMobile: String,
    val customerEmail: String,
    val customerAddress: String,
    val date: Long = System.currentTimeMillis(),
    val itemsJson: String, // JSON representation of List<InvoiceItem>
    val subtotal: Double,
    val discountAmount: Double,
    val discountPercentage: Double,
    val taxAmount: Double,
    val grandTotal: Double,
    val shopId: String = "default_shop",
    val paidAmount: Double = 0.0
)

@JsonClass(generateAdapter = true)
data class InvoiceItem(
    val productId: String,
    val productName: String,
    val sellingPrice: Double,
    val quantity: Int,
    val unit: String,
    val totalPrice: Double,
    val taxRate: Double = 0.0
)

@Entity(tableName = "expenses")
@JsonClass(generateAdapter = true)
data class Expense(
    @PrimaryKey val id: String,
    val title: String,
    val amount: Double,
    val category: String,
    val date: Long = System.currentTimeMillis(),
    val notes: String,
    val receiptImage: String = "",
    val shopId: String = "default_shop"
)

@Entity(tableName = "suppliers")
@JsonClass(generateAdapter = true)
data class Supplier(
    @PrimaryKey val id: String,
    val name: String,
    val companyName: String,
    val mobile: String,
    val email: String,
    val address: String,
    val taxNumber: String,
    val notes: String,
    val outstandingBalance: Double = 0.0,
    val createdDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "purchase_orders")
@JsonClass(generateAdapter = true)
data class PurchaseOrder(
    @PrimaryKey val poNumber: String,
    val supplierId: String,
    val supplierName: String,
    val itemsJson: String, // JSON representation of List<PurchaseOrderItem>
    val totalCost: Double,
    val status: String, // Draft, Pending, Approved, Received, Cancelled
    val createdDate: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class PurchaseOrderItem(
    val productId: String,
    val productName: String,
    val sku: String,
    val costPrice: Double,
    val quantity: Int,
    val unit: String,
    val totalPrice: Double
)

@Entity(tableName = "categories")
@JsonClass(generateAdapter = true)
data class Category(
    @PrimaryKey val id: String,
    val name: String,
    val description: String = ""
)

@Entity(tableName = "supplier_transactions")
@JsonClass(generateAdapter = true)
data class SupplierTransaction(
    @PrimaryKey val id: String,
    val supplierId: String,
    val type: String, // "BUY" or "PAYMENT"
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val referenceId: String = "",
    val notes: String = ""
)

