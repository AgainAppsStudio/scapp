package com.example.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.example.data.Invoice
import com.example.data.InvoiceItem
import com.example.data.Shop
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfInvoiceHelper {

    fun generateAndSaveInvoicePdf(
        context: Context,
        outputStream: OutputStream,
        invoice: Invoice,
        items: List<InvoiceItem>,
        currency: String,
        shop: Shop?
    ) {
        val pdfDocument = PdfDocument()
        
        // A4 page size: 595 x 842 points (at 72 dpi)
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Define primary palette colors
        val primaryEmerald = 0xFF047857.toInt() // Match EmeraldDark
        val darkSlate = 0xFF1E293B.toInt()     // Match slate-800
        val lightSlate = 0xFF64748B.toInt()    // Match slate-500
        val tableHeaderBg = 0xFFF1F5F9.toInt()  // slate-100 background
        val rowAltBg = 0xFFF8FAFC.toInt()       // slate-50 background
        val borderGray = 0xFFE2E8F0.toInt()     // slate-200 border
        val white = 0xFFFFFFFF.toInt()
        
        // Setup paints
        val textPaint = Paint().apply {
            isAntiAlias = true
            color = darkSlate
        }
        
        val drawPaint = Paint().apply {
            isAntiAlias = true
        }

        // --- 1. TOP BRANDING BANNER ---
        // Top colorful accent line
        drawPaint.color = primaryEmerald
        canvas.drawRect(40f, 30f, 555f, 36f, drawPaint)

        // Brand Label
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 20f
        textPaint.color = primaryEmerald
        canvas.drawText("SMART CASH MEMO", 40f, 65f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.textSize = 9f
        textPaint.color = lightSlate
        canvas.drawText("Professional Point of Sale Invoicing", 40f, 78f, textPaint)

        // "TAX INVOICE" title top right
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 24f
        textPaint.color = darkSlate
        val taxInvoiceStr = "TAX INVOICE"
        val taxInvoiceWidth = textPaint.measureText(taxInvoiceStr)
        canvas.drawText(taxInvoiceStr, 555f - taxInvoiceWidth, 68f, textPaint)

        // --- 2. BUSINESS INFO (Left) & INVOICE META (Right) ---
        // Business info (Left)
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 11f
        textPaint.color = darkSlate
        val shopName = shop?.name ?: "Smart Cash Memo Corp"
        canvas.drawText(shopName, 40f, 115f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.textSize = 9f
        textPaint.color = lightSlate
        val shopAddress = shop?.address ?: "Central Business District, Suite 404"
        canvas.drawText(shopAddress, 40f, 130f, textPaint)
        val shopMobile = "Tel: ${shop?.mobile ?: "+1 (555) 019-2834"}"
        canvas.drawText(shopMobile, 40f, 143f, textPaint)

        // Invoice metadata (Right)
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(invoice.date))
        
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 10f
        textPaint.color = darkSlate
        val invIdLabel = "Invoice No: "
        val invIdVal = invoice.invoiceId
        val invIdValWidth = textPaint.measureText(invIdVal)
        canvas.drawText(invIdVal, 555f - invIdValWidth, 115f, textPaint)
        
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.color = lightSlate
        val invIdLabelWidth = textPaint.measureText(invIdLabel)
        canvas.drawText(invIdLabel, 555f - invIdValWidth - invIdLabelWidth, 115f, textPaint)

        val dateLabel = "Date Issued: "
        val dateValWidth = textPaint.measureText(dateStr)
        canvas.drawText(dateStr, 555f - dateValWidth, 130f, textPaint)
        val dateLabelWidth = textPaint.measureText(dateLabel)
        canvas.drawText(dateLabel, 555f - dateValWidth - dateLabelWidth, 130f, textPaint)

        // Payment status badge
        val isPaid = invoice.paidAmount >= invoice.grandTotal
        val statusText = if (isPaid) "FULLY PAID" else "BALANCE DUE"
        val badgeBgColor = if (isPaid) 0xFFE6F4EA.toInt() else 0xFFFCE8E6.toInt()
        val badgeTextColor = if (isPaid) 0xFF137333.toInt() else 0xFFC5221F.toInt()

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 9f
        val badgeTextWidth = textPaint.measureText(statusText)
        val badgeWidth = badgeTextWidth + 16f
        val badgeHeight = 18f
        val badgeLeft = 555f - badgeWidth
        val badgeTop = 145f

        drawPaint.color = badgeBgColor
        canvas.drawRoundRect(RectF(badgeLeft, badgeTop, 555f, badgeTop + badgeHeight), 4f, 4f, drawPaint)

        textPaint.color = badgeTextColor
        canvas.drawText(statusText, badgeLeft + 8f, badgeTop + 12f, textPaint)

        // Divider
        drawPaint.color = borderGray
        canvas.drawLine(40f, 180f, 555f, 180f, drawPaint)

        // --- 3. CUSTOMER INFO (BILL TO) ---
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 10f
        textPaint.color = primaryEmerald
        canvas.drawText("BILL TO:", 40f, 205f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 12f
        textPaint.color = darkSlate
        canvas.drawText(invoice.customerName, 40f, 222f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.textSize = 9f
        textPaint.color = lightSlate
        val customerContact = "Phone: ${invoice.customerMobile}" + if (invoice.customerEmail.isNotEmpty()) " | Email: ${invoice.customerEmail}" else ""
        canvas.drawText(customerContact, 40f, 237f, textPaint)
        
        if (invoice.customerAddress.isNotEmpty()) {
            canvas.drawText("Address: ${invoice.customerAddress}", 40f, 250f, textPaint)
        }

        // --- 4. PRODUCTS LINE ITEMS TABLE ---
        val tableTop = 275f
        val headerHeight = 22f
        val rowHeight = 24f

        // Table Header Background Row
        drawPaint.color = tableHeaderBg
        canvas.drawRoundRect(RectF(40f, tableTop, 555f, tableTop + headerHeight), 4f, 4f, drawPaint)

        // Header Labels
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 9f
        textPaint.color = darkSlate
        
        canvas.drawText("Item / Description", 48f, tableTop + 14f, textPaint)
        
        val priceHeaderStr = "Unit Price"
        val priceHeaderWidth = textPaint.measureText(priceHeaderStr)
        canvas.drawText(priceHeaderStr, 380f - priceHeaderWidth / 2f, tableTop + 14f, textPaint)
        
        val qtyHeaderStr = "Qty"
        val qtyHeaderWidth = textPaint.measureText(qtyHeaderStr)
        canvas.drawText(qtyHeaderStr, 450f - qtyHeaderWidth / 2f, tableTop + 14f, textPaint)

        val totalHeaderStr = "Total Price"
        val totalHeaderWidth = textPaint.measureText(totalHeaderStr)
        canvas.drawText(totalHeaderStr, 545f - totalHeaderWidth, tableTop + 14f, textPaint)

        // Table rows loop
        var currentY = tableTop + headerHeight
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.textSize = 10f

        for (i in items.indices) {
            val item = items[i]
            val rowY = currentY + rowHeight * i
            
            // Alternating backgrounds
            if (i % 2 == 1) {
                drawPaint.color = rowAltBg
                canvas.drawRect(40f, rowY, 555f, rowY + rowHeight, drawPaint)
            }

            // Draw clean gray horizontal separator lines
            drawPaint.color = borderGray
            canvas.drawLine(40f, rowY + rowHeight, 555f, rowY + rowHeight, drawPaint)

            textPaint.color = darkSlate
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            // Truncate name beautifully if it exceeds space
            val truncatedName = truncateText(item.productName, textPaint, 240f)
            canvas.drawText(truncatedName, 48f, rowY + 16f, textPaint)

            // Price column
            val priceStr = "$currency${String.format("%.2f", item.sellingPrice)}"
            val priceWidth = textPaint.measureText(priceStr)
            canvas.drawText(priceStr, 380f - priceWidth / 2f, rowY + 16f, textPaint)

            // Qty column
            val qtyStr = "${item.quantity} ${item.unit}"
            val qtyWidth = textPaint.measureText(qtyStr)
            canvas.drawText(qtyStr, 450f - qtyWidth / 2f, rowY + 16f, textPaint)

            // Total column
            val itemTotalStr = "$currency${String.format("%.2f", item.totalPrice)}"
            val itemTotalWidth = textPaint.measureText(itemTotalStr)
            canvas.drawText(itemTotalStr, 545f - itemTotalWidth, rowY + 16f, textPaint)
        }

        // --- 5. BILLING SUMMARY STATS PANEL ---
        val tableBottomY = currentY + rowHeight * items.size
        var summaryY = tableBottomY + 15f

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.textSize = 10f
        textPaint.color = lightSlate

        // Subtotal row
        canvas.drawText("Subtotal:", 360f, summaryY, textPaint)
        val subtotalStr = "$currency${String.format("%.2f", invoice.subtotal)}"
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.color = darkSlate
        canvas.drawText(subtotalStr, 545f - textPaint.measureText(subtotalStr), summaryY, textPaint)

        // Discount row
        summaryY += 18f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.color = lightSlate
        val discountPercentageLabel = if (invoice.discountPercentage > 0) "Discount (${invoice.discountPercentage}%):" else "Discount:"
        canvas.drawText(discountPercentageLabel, 360f, summaryY, textPaint)
        val absoluteDisc = (invoice.subtotal * (invoice.discountPercentage / 100)) + invoice.discountAmount
        val discountStr = "-$currency${String.format("%.2f", absoluteDisc)}"
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.color = 0xFFC5221F.toInt() // Reddish text
        canvas.drawText(discountStr, 545f - textPaint.measureText(discountStr), summaryY, textPaint)

        // VAT / Tax row
        summaryY += 18f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.color = lightSlate
        canvas.drawText("VAT Tax:", 360f, summaryY, textPaint)
        val taxStr = "+$currency${String.format("%.2f", invoice.taxAmount)}"
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.color = darkSlate
        canvas.drawText(taxStr, 545f - textPaint.measureText(taxStr), summaryY, textPaint)

        // GRAND TOTAL Highlight box
        summaryY += 12f
        drawPaint.color = primaryEmerald
        canvas.drawRoundRect(RectF(350f, summaryY, 555f, summaryY + 32f), 6f, 6f, drawPaint)

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 11f
        textPaint.color = white
        canvas.drawText("GRAND TOTAL", 362f, summaryY + 20f, textPaint)

        val grandTotalStr = "$currency${String.format("%.2f", invoice.grandTotal)}"
        canvas.drawText(grandTotalStr, 545f - textPaint.measureText(grandTotalStr), summaryY + 20f, textPaint)

        // Payment detailed rows below highlight
        summaryY += 48f
        textPaint.textSize = 10f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.color = lightSlate
        canvas.drawText("Amount Paid:", 360f, summaryY, textPaint)
        
        val paidStr = "$currency${String.format("%.2f", invoice.paidAmount)}"
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.color = darkSlate
        canvas.drawText(paidStr, 545f - textPaint.measureText(paidStr), summaryY, textPaint)

        val dueAmount = (invoice.grandTotal - invoice.paidAmount).coerceAtLeast(0.0)
        if (dueAmount > 0) {
            summaryY += 18f
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textPaint.color = 0xFFC5221F.toInt() // Reddish
            canvas.drawText("Remaining Due:", 360f, summaryY, textPaint)
            val dueStr = "$currency${String.format("%.2f", dueAmount)}"
            canvas.drawText(dueStr, 545f - textPaint.measureText(dueStr), summaryY, textPaint)
        }

        // --- 6. PAGE FOOTER WITH AUDIT AND THANK YOU ---
        val footerY = 770f
        
        // Draw thin footer border line
        drawPaint.color = borderGray
        canvas.drawLine(40f, footerY, 555f, footerY, drawPaint)

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
        textPaint.textSize = 8f
        textPaint.color = lightSlate
        val termsStr = "Terms & Conditions: Returns or exchanges are accepted within 7 days with original tax receipt. "
        canvas.drawText(termsStr, 40f, footerY + 16f, textPaint)
        val signatureStr = "This is a computer-generated invoice and requires no physical signature."
        canvas.drawText(signatureStr, 40f, footerY + 28f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 11f
        textPaint.color = primaryEmerald
        val thankYouStr = "Thank you for your business!"
        val thankYouWidth = textPaint.measureText(thankYouStr)
        canvas.drawText(thankYouStr, 297.5f - thankYouWidth / 2f, footerY + 52f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.textSize = 8f
        textPaint.color = lightSlate
        canvas.drawText("Page 1 of 1", 555f - textPaint.measureText("Page 1 of 1"), footerY + 52f, textPaint)

        pdfDocument.finishPage(page)
        pdfDocument.writeTo(outputStream)
        pdfDocument.close()
    }

    private fun truncateText(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var truncated = text
        while (truncated.isNotEmpty() && paint.measureText("$truncated...") > maxWidth) {
            truncated = truncated.dropLast(1)
        }
        return if (truncated.isNotEmpty()) "$truncated..." else ""
    }
}
