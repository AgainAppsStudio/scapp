package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldActive = Color(0xFF10B981)
val EmeraldDark = Color(0xFF047857)
val EmeraldLight = Color(0xFFD1FAE5)

val DarkBlue = Color(0xFF1E3A8A)
val DarkBlueDark = Color(0xFF172554)
val DarkBlueLight = Color(0xFFDBEAFE)

val DarkGrayBg = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val LightGrayBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)

val OutOfStockRed = Color(0xFFEF4444)
val WarningOrange = Color(0xFFF59E0B)
val InfoBlue = Color(0xFF3B82F6)

